CREATE OR REPLACE PACKAGE BODY depks_dedtlron_custom AS
      /*-----------------------------------------------------------------------------------------------------
      **
      ** File Name  : depks_dedtlron_custom.sql
      **
      ** Module     : Data Entry
      **
      ** This source is part of the Oracle FLEXCUBE Software Product.
      ** Copyright � 2012 - 2017 , Oracle and/or its affiliates.  All rights reserved
      **
      **
      ** No part of this work may be reproduced, stored in a retrieval system, adopted
      ** or transmitted in any form or by any means, electronic, mechanical,
      ** photographic, graphic, optic recording or otherwise, translated in any
      ** language or computer language, without the prior written permission of
      ** Oracle and/or its affiliates.
      **
      ** Oracle Financial Services Software Limited.
      ** Oracle Park, Off Western Express Highway,
      ** Goregaon (East),
      ** Mumbai - 400 063, India
      ** India
      -------------------------------------------------------------------------------------------------------
              
      ** Modfied By           : Rajesh Kumar J
      ** Modified On          : 07-JAN-2013
      ** Modified Reason      : Changes added to populate the data for internal and external remarks.
      ** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20
              
      ** Modfied By           : Girish L
      ** Modified On          : 10-JAN-2013
      ** Modified Reason      : Added validation to chech whether ralted customer is inputed or not.
      ** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3
              
      ** Modfied By           : Arpitha H K
      ** Modified On          : 20-DEC-2012
      ** Modified Reason      : Changes added to pouplate the data into new custom tables
      ** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8
              
      ** Modfied By           : Rajesh Kumar J
      ** Modified On          : 12-FEB-2013
      ** Modified Reason      : Separate Charge and Tax Payment Account for Teller Transactions.
      ** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20
              
      ** Modfied By           : Mekhala
      ** Modified On          : 13-FEB-2013
      ** Modified Reason      : Teller Entry - Display of Additional Details.
      ** Search String        : FS_FCUBS12.0.0.1CitiDDA_Vol4 Tag7
              
      ** Modfied By           : Sohini Makar
      ** Modified On          : 01-Mar-2013
      ** Modified Reason      : Threshold for cash in - cash out for automatic authorization
      ** Search String        : FCUBS CITI Release FS_FCUBS12.0.0.1CitiDDA_Vol5 Threshold for cash in - cash out for automatic authorization  - #2441
              
      ** Modfied By           : Rajesh Kumar J
      ** Modified On          : 22-MAR-2013
      ** Modified Reason      : Separate Charge and Tax Payment Account for Teller Transactions.
      ** Search String        : FCUBS CITI Release 12.0.0.1.0 Vol4 Tag5
              
              
      ** Modified By         : Joby M
      ** Modified On         : 03-Apr-2013
      ** Modified Reason     : Float Account Processing - TED Manual Instructions processing
      ** Search String       : FCUBS CITI Release 12.0.0.1.0 FS Vol6 Tag3 - Instructions processing
              
              
      SFR Number             : FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes
      Changed By             : Ankur Omar
      Change Description     : User profile level Input and Authorization Limit setup
      Search String          : FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6
              
      ** Modified By         : Girish L
      ** Modified On         : 03-May-2013
      ** Modified Reason     : Added validation to check Default Walkin Customer at branch Level.
      ** Search String       : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 - SFR-NO-177
              
      ** Modfied By           : Rajesh Kumar J
      ** Modified On          : 13-MAY-2013
      ** Modified Reason      : Related customer mandatory check.
      ** Search String        : FCUBS12.0.1.7.0 CITI Vol4 Tag3 IUT3 SFR#186
              
      ** Modfied By           : Revathi S
      ** Modified On          : 16-MAY-2013
      ** Modified Reason      : Value Date should be global application date
      ** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#278
              
      ** Modfied By           : Rajesh Kumar J
      ** Modified On          : 21-MAY-2013
      ** Modified Reason      : Not able to save as, event seq no is coming as null.
      ** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#353
              
      ** Modfied By           : Revathi S
      ** Modified On          : 21-MAY-2013
      ** Modified Reason      : Added select statement to query detb_tc_detail_extgbl
      ** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#343
              
      ** Modfied By           : Revathi S
      ** Modified On          : 21-MAY-2013
      ** Modified Reason      : Commented IF condition of TC Product
      ** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#341
              
      ** Changed On           : 22-May-2013
      ** Changed By           : Rajesh Kumar J
      ** Change Description   : Internal and external remarks.
      ** Search string        : FCUBS12.0.1.7.0 CITI Vol4 Tag20 IUT3 SFR#292
              
      ** Changed On           : 23-May-2013
      ** Changed By           : Rajesh Kumar J
      ** Change Description   : code moved to post process from post upload db.
      ** Search string        : FCUBS12.0.1.7.0 CITI Vol4 Tag20 IUT3 SFR#292
              
      ** Changed On           : 24-May-2013
      ** Changed By           : Rajesh Kumar J
      ** Change Description   : Txn allowed to save with rel cust as null, before authorising the change 'rel cust mandatory' to NO.
      ** Search string        : FCUBS12.0.1.7.0 CITI Vol4 Tag3 IUT3 SFR#402
              
      ** Modified By          : Joby M
      ** Modified On          : 24-May-2013
      ** Modified Reason      : Modifications to round amount fields since transfer out amount can go beyond currency precision
                                if rounding rules are not maintained for IC tax/interest liquidations
      ** Search String        : FCUBS12.0.1.7.0 CITI Vol6 Tag3 ITR SFR#412 Float Account processing
               
      ** Modfied By           : Ankur Omar
      ** Modified On          : 27-MAY-2013
      ** Modified Reason      : Related customer mandatory check.
      ** Search String        : FCUBS12.0.1.7.0 CITI Vol4 Tag3 IUT3 SFR#418 
      
      ** Modfied By           : Revathi S
      ** Modified On          : 05-june-2013
      ** Modified Reason      : Reverse function call has been added
      ** Search String        : FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#19 CashLetter Processing  changes
               
      ** Modfied By           : Sohini Makar
      ** Modified On          : 10-June-2013
      ** Modified Reason      : Related customer validation issues.
      ** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 #ITR2 sfr 83
            
      ** Modfied By           : Rajesh Kumar J
      ** Modified On          : 10-June-2013
      ** Modified Reason      : Recon issues.
      ** Search String        : FCUBS12.0.1.7.0 CITI Vol4 Tag20 IUT3 SFR#105   
            
      ** Modfied By           : Revathi S
      ** Modified On          : 12-june-2013
      ** Modified Reason      : Kernel reverse has been skipped for cashletter product
      ** Search String        : FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#116 CashLetter Processing  changes
             
      ** Modified By          : Asha G R
      ** Modified Date        : 14-Aug-2013
      ** Modification reason  : Manual Posting for Journal entries
      ** Search String        : FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 
            
      ** Modfied By           : Santosh Kumar Savanur
      ** Modified On          : 06-FEB-2014
      ** Modified Reason      : Account Hierarchy Changes
      ** Search String        : FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5
                   
      Modfied By              : Anjani
      Modified On             : 25 APR 2014
      Modified Reason         : Changes done for changing the referenced package ifpks_otat_gen_extgbl to ifpks_eca_extgbl 
      Search String           : FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag14 Code Review Changes
                
      ** Modfied By           : Siva
      ** Modified On          : 19-MAY-2014
      ** Modified Reason      : Partial Cheque Payment changes
      ** Search String        : FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4
                 
      ** Modified On          : 03-JUN-2014
      ** Modified Reason      : Made changes to default txn-amount as original-amt if check-stauts is 'N'
      ** Search String        : FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 - review changes

      ** Modified On          : 11-JUN-2014
      ** Modified Reason      : Code Formatting changes
      ** Search String        : FCUBS12.0.1.7CITIDDA Rel4

	** Modfied By           : Ats 
	** Modified On          : 26-May-2017
	** Modified Reason      : PCR AB277 - Teller Balance Changes
	** Search String        : CITI_FC12_R5_SUPP SIT1 SFR##### changes
	
  ** Modfied By           : Debasish
  ** Modified On          : 15 FEB 2018
  ** Modified Reason      : Changes done as part of "Affiliates V3" to validate "Reserve for Account before Authorisation" 
  ** Search String        : FCUBS12.0.1.7CITIDDA Affiliates V3 Changes	
      -------------------------------------------------------------------------------------------------------
      */

      --FCUBS CITI Release 12.0.0.1.0 FS Vol6 Tag3 - Instructions processing Changes Starts
      TYPE typ_rec_offset_det IS RECORD(
            offset_ilv            VARCHAR2(1),
            offset_account_branch detbs_teller_master.offset_account_branch%TYPE,
            offset_account        detbs_teller_master.offset_account%TYPE,
            offset_ccy            detbs_teller_master.offset_ccy%TYPE,
            offset_amount         detbs_teller_master.offset_amount%TYPE);
      pkg_rec_offset_det typ_rec_offset_det;
      --FCUBS CITI Release 12.0.0.1.0 FS Vol6 Tag3 - Instructions processing Changes Ends

      PROCEDURE dbg(p_msg VARCHAR2) IS
            l_msg VARCHAR2(32767);
      BEGIN
            l_msg := 'depks_dedtlron_Custom ==>' || p_msg;
            debug.pr_debug('DE', l_msg);
      END dbg;

      PROCEDURE pr_log_error(p_function_id IN VARCHAR2,
                             p_source      VARCHAR2,
                             p_err_code    VARCHAR2,
                             p_err_params  VARCHAR2) IS
      BEGIN
            cspks_req_utils.pr_log_error(p_source,
                                         p_function_id,
                                         p_err_code,
                                         p_err_params);
      END pr_log_error;
      PROCEDURE pr_skip_handler(p_stage IN VARCHAR2) IS
      BEGIN
            dbg('In Pr_Skip_Handler..');
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 STARTS
      
            IF depks_dedtlron_main.fn_get_original_action IN ('LIQUIDATE') AND
               p_stage = 'POSTPROCESS' THEN
                  depks_dedtlron_main.pr_set_skip_kernel;
            END IF;
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 ENDS
		--CITI_FC12_R5_SUPP SIT1 SFR##### changes starts
		IF depks_dedtlron_main.fn_get_original_action IN ('POP_AVLAMTDTL')
		THEN
			dbg('ats In Pr_Skip_Handler..');
			IF p_stage IN(	'PREUNLOCK','POSTUNLOCK'
							,'PREQRY','POSTQRY'
							,'PRESUBSYSPKP','POSTSUBSYSPKP'
							,'PREENRICH','POSTENRICH'
							,'POSTDFLT'
							,'PREUPLD','POSTUPLD'
							,'PREPROCESS','POSTPROCESS'
							,'PREQRY','POSTQRY'
			) 
			THEN
				depks_dedtlron_main.pr_set_skip_kernel;
			END IF;
            END IF;
		--CITI_FC12_R5_SUPP SIT1 SFR##### changes ends
            --FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#116 CashLetter Processing  changes starts
            /* --FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#19 CashLetter Processing  changes starts
             IF depks_dedtlron_main.fn_get_original_action IN ('REVERSE') AND
                   p_stage = 'POSTPROCESS' THEN
                  depks_dedtlron_main.pr_set_skip_kernel;
                END IF;
              --FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#19 CashLetter Processing  changes ends
            --FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#116 CashLetter Processing  changes ends
            */
      END pr_skip_handler;

      --FCUBS CITI Release FS_FCUBS12.0.0.1CitiDDA_Vol5 Threshold for cash in - cash out for automatic authorization  - #2441: starts
      FUNCTION fn_threshold(p_source           IN VARCHAR2,
                            p_product          IN VARCHAR2,
                            p_source_operation IN VARCHAR2,
                            p_function_id      IN VARCHAR2,
                            p_action_code      IN VARCHAR2,
                            p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                            p_err_code         IN OUT VARCHAR2,
                            p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN;

      FUNCTION fn_mesg_gen_on_auth(pref_no   VARCHAR2,
                                   pesn      NUMBER,
                                   p_errcode IN OUT VARCHAR2,
                                   p_params  IN OUT VARCHAR2) RETURN BOOLEAN IS
            l_msgs_rows NUMBER;
            from_dcn    mstbs_dly_msg_out.dcn%TYPE;
            l_app_date  DATE := global.application_date;
      BEGIN
            dbg('In Fn_Mesg_Gen_On_Auth..');
            BEGIN
                  SELECT COUNT(*)
                  INTO   l_msgs_rows
                  FROM   mstbs_msg_handoff
                  WHERE  reference_no = pref_no
                  AND    processed_flag = 'N';
                  dbg('l_Msgs_Rows' || l_msgs_rows);
            
                  IF l_msgs_rows > 0 
                  THEN
                        SELECT MIN(dcn)
                        INTO   from_dcn
                        FROM   mstbs_msg_handoff
                        WHERE  reference_no = pref_no
                        AND    processed_flag = 'N';
                  
                        UPDATE mstbs_dly_msg_out
                        SET    hold_status = 'Y',
                               auth_stat = 'U',
                               maker_id = global.user_id,
                               maker_dt_stamp = l_app_date
                        WHERE  reference_no = pref_no
                        AND    processed_flag = 'N';
                        
                        dbg('Calling Mspkss_Msc.Fn_Con_Gen_Msg..');
                        IF NOT mspkss_msc.fn_con_gen_msg(pref_no, pesn, 'N') 
                        THEN
                              dbg('Failed In Mspkss_Msc.Fn_Con_Gen_Msg..');
                              NULL;
                        END IF;
                  END IF;
            EXCEPTION
                  WHEN no_data_found THEN
                        dbg('No Valid Data Found In Mstbs_Msg_Handoff For Contract Reference' || pref_no);
                        p_errcode := 'LD-UPL-118';
                        p_params  := 'Mstbs_Msg_Handoff~';
                        ovpkss.pr_appendtbl(p_errcode, p_params);
                        RETURN FALSE;
                  WHEN OTHERS THEN
                        dbg('In when Others While Selectin From Mstbs_Msg_Handoff' || SQLERRM);
                        p_errcode := 'LD-UPL-100';
                        p_params  := 'Selecting From Mstbs_Msg_Handoff~';
                        ovpkss.pr_appendtbl(p_errcode, p_params);
                        RETURN FALSE;
            END;
            dbg('Returning True From Fn_Mesg_Gen_On_Auth..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  dbg('In When Others Of Fn_Mesg_Gen_On_Auth' || SQLERRM);
                  dbg('Failed To Auto Generate Messages..');
                  p_errcode := 'MS-AUGEN02';
                  p_params  := '';
                  ovpkss.pr_appendtbl(p_errcode, p_params);
                  RETURN FALSE;
      END fn_mesg_gen_on_auth;
      --FCUBS CITI Release FS_FCUBS12.0.0.1CitiDDA_Vol5 Threshold for cash in - cash out for automatic authorization  - #2441: ends

      --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 Changes Starts
      FUNCTION fn_partial_pay_enabled RETURN BOOLEAN IS
      BEGIN
            RETURN cspkss_feature.fn_installed('PARTCHKPAY', Global.current_branch);
      END fn_partial_pay_enabled;
      --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 Changes Ends

      FUNCTION fn_post_build_type_structure(p_source           IN VARCHAR2,
                                            p_source_operation IN VARCHAR2,
                                            p_function_id      IN VARCHAR2,
                                            p_action_code      IN VARCHAR2,
                                            p_child_function   IN VARCHAR2,
                                            p_addl_info        IN cspks_req_global.ty_addl_info,
                                            p_dedtlron         IN OUT depks_dedtlron_main.ty_dedtlron,
                                            p_err_code         IN OUT VARCHAR2,
                                            p_err_params       IN OUT VARCHAR2)
            RETURN BOOLEAN IS
      BEGIN
      
            dbg('In Fn_Post_Build_Type_Structure..');
      
            dbg('Returning Success From Fn_Post_Build_Type_Structure..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedtlron_Custom.Fn_Post_Build_Type_Structure ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_build_type_structure;

      FUNCTION fn_pre_check_mandatory(p_source           IN VARCHAR2,
                                      p_source_operation IN VARCHAR2,
                                      p_function_id      IN VARCHAR2,
                                      p_action_code      IN VARCHAR2,
                                      p_child_function   IN VARCHAR2,
                                      p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL',
                                      p_dedtlron         IN OUT depks_dedtlron_main.ty_dedtlron,
                                      p_err_code         IN OUT VARCHAR2,
                                      p_err_params       IN OUT VARCHAR2)
            RETURN BOOLEAN IS
      BEGIN
      
            dbg('In Fn_Pre_Check_Mandatory..');
            
            --FCUBS CITI Release 12.0.0.1.0 FS Vol6 Tag3 - Instructions processing Changes Starts
            dbg('float Product:' ||
                p_dedtlron.v_detb_teller_master_extgbl.float_product);
            IF p_action_code IN (cspks_req_global.p_new, cspks_req_global.p_copy) 
            THEN
                  IF nvl(p_dedtlron.v_detb_teller_master_extgbl.float_product, 'N') = 'N' 
                  THEN
                        p_dedtlron.v_detb_teller_master_extgbl.float_direction := NULL;
                  END IF;
            END IF;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol6 Tag3 - Instructions processing Changes Ends
            dbg('Returning  Success From Fn_Pre_Check_Mandatory..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**','In When Others of depks_dedtlron_Custom.Fn_Pre_Check_Mandatory ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_check_mandatory;

      FUNCTION fn_post_check_mandatory(p_source           IN VARCHAR2,
                                       p_source_operation IN VARCHAR2,
                                       p_function_id      IN VARCHAR2,
                                       p_action_code      IN VARCHAR2,
                                       p_child_function   IN VARCHAR2,
                                       p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL',
                                       p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                                       p_err_code         IN OUT VARCHAR2,
                                       p_err_params       IN OUT VARCHAR2)
            RETURN BOOLEAN IS
      BEGIN
            dbg('In Fn_Post_Check_Mandatory..');
      
            --FCUBS CITI Release 12.0.0.1.0 Vol4 Tag5 STARTS
            IF p_dedtlron.v_detbs_teller_master.charge_account = 'A' 
            THEN
                  IF p_dedtlron.v_detb_teller_master_extgbl.other_account IS NULL OR
                     p_dedtlron.v_detb_teller_master_extgbl.other_branch IS NULL OR
                     p_dedtlron.v_detb_teller_master_extgbl.other_ccy IS NULL 
                  THEN
                        dbg('Other account number is mandatory');
                        p_err_code   := 'DE-JAC01';
                        p_err_params := NULL;
                        RETURN FALSE;
                  END IF;
            END IF;
            --FCUBS CITI Release 12.0.0.1.0 Vol4 Tag5 ENDS
      
            dbg('Returning Success From Fn_Post_Check_Mandatory..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**', 'In When Others of depks_dedtlron_Custom.Fn_Post_Check_Mandatory ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_check_mandatory;

      FUNCTION fn_pre_default_and_validate(p_source           IN VARCHAR2,
                                           p_source_operation IN VARCHAR2,
                                           p_function_id      IN VARCHAR2,
                                           p_action_code      IN VARCHAR2,
                                           p_child_function   IN VARCHAR2,
                                           p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                                           p_prev_dedtlron    IN OUT depks_dedtlron_main.ty_dedtlron,
                                           p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                                           p_err_code         IN OUT VARCHAR2,
                                           p_err_params       IN OUT VARCHAR2)
            RETURN BOOLEAN IS
      BEGIN
            dbg('In Fn_Pre_Default_And_Validate..');
      
            smpks.g_tb_cluster_data('MODULE_ID') := 'DE'; ----FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth LimiT
      
            -- FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5 Changes Starts
            acpkss_acc_hierarchy_extgbl.g_consider_for_acc_hier := 'Y';
            -- FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5 Changes Ends   
      
            dbg('Returning Success From Fn_Pre_Default_And_Validate..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedtlron_Custom.Fn_Pre_Default_And_Validate ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_default_and_validate;

      FUNCTION fn_post_default_and_validate(p_source           IN VARCHAR2,
                                            p_source_operation IN VARCHAR2,
                                            p_function_id      IN VARCHAR2,
                                            p_action_code      IN VARCHAR2,
                                            p_child_function   IN VARCHAR2,
                                            p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                                            p_prev_dedtlron    IN OUT depks_dedtlron_main.ty_dedtlron,
                                            p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                                            p_err_code         IN OUT VARCHAR2,
                                            p_err_params       IN OUT VARCHAR2)
            RETURN BOOLEAN IS
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 Starts
            l_de_prod_ext detms_product_master_extgbl%ROWTYPE;
            l_value_date  DATE;
            l_return_flag BOOLEAN;
            l_retval      CHAR(1);
            l_type        cstbs_contract.product_type%TYPE;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 Ends
            --FCUBS CITI Release 12.0.0.1.0 FS Vol6 Tag3 - Instructions processing Changes Starts
            l_rec_instr    cstms_float_instr_extgbl%ROWTYPE;
            l_acc_rec      sttbs_account%ROWTYPE;
            l_error_code   VARCHAR2(12);
            l_error_params VARCHAR2(255);
            l_rate         cytms_rates.mid_rate%TYPE;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol6 Tag3 - Instructions processing Changes Ends
            l_count NUMBER; --FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6
            v_flag  CHAR(1); -- FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6
            --  l_fn_call_id      NUMBER; -- FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6
            l_tb_cluster_data     global.ty_tb_cluster_data; -- FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6
            walkin_cust           VARCHAR2(01); --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 - SFR-NO-177
            l_rel_cust_mandat     sttms_branch_extgbl.related_cust_mandatory%TYPE; --FCUBS12.0.1.7.0 CITI Vol4 Tag3 IUT3 SFR#186
            l_latest_event_seq_no cstbs_contract.latest_event_seq_no%TYPE; --FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#116 CashLetter Processing  changes
            
            --CITI_FC12_R5_SUPP SIT1 SFR##### changes starts           
            
            l_Cust_Account		Sttms_Cust_Account%ROWTYPE;
            l_Cust_Acc_Extgbl		Sttms_Cust_Account_Extgbl%ROWTYPE;
            l_Acc_Bal_Tov		Sttms_Account_Bal_Tov%ROWTYPE;
            l_Accnet_Mast_Extgbl	Sttms_Accnet_Master_Extgbl%ROWTYPE;            
            
		l_Float_Track_Reqd    	VARCHAR2(1);
		l_Float_Mapping_Exists	BOOLEAN;
		l_Netting_Exists		BOOLEAN;
		l_Temp_Bal       		NUMBER := 0; 
		l_Custom_Data    		global.ty_tb_custom_data;
		l_Netting_Structure    	Ifpks_Eca_Extgbl.Ty_Stdacnet;
		
		l_Debit_Account		Sttms_Cust_Account.Cust_Ac_No%TYPE;
		l_Tot_Net_Adv     	Sttms_Cust_Account.Acy_Avl_Bal%TYPE;
		l_Tot_Net_Adv_Dol 	Sttms_Cust_Account.Acy_Avl_Bal%TYPE;
		l_Dol_Amount     		Sttms_Cust_Account.Acy_Avl_Bal%TYPE;
    		l_Acy_Avl_Bal    		Sttms_Cust_Account.Acy_Avl_Bal%TYPE;
    		l_Float_Balance  		Sttms_Cust_Account.Acy_Avl_Bal%TYPE;
    		l_Ac_Tol_Avl_Bal 		Sttms_Cust_Account.Acy_Avl_Bal%TYPE;
    		l_Uncol_Dr_Float 		Sttms_Cust_Account_Extgbl.Acy_Uncol_Dr%TYPE := 0;
		l_Uncol_Dr_Dda   		Sttms_Cust_Account_Extgbl.Acy_Uncol_Dr%TYPE := 0;		
		l_Branch     		Sttms_Float_Mapping_Extgbl.Linked_Ac_Branch%TYPE;
    		l_Account    		Sttms_Float_Mapping_Extgbl.Linked_Ac_No%TYPE;
    		l_Float_Mapping_Rec    	Sttms_Float_Mapping_Extgbl%ROWTYPE;
		l_Float_Brn      		Sttms_Float_Mapping_Extgbl.Ac_Branch%TYPE;
		l_Float_Acc      		Sttms_Float_Mapping_Extgbl.float_ac_no%TYPE;
    		l_Accls_Flt_Rec 		Sttms_Accls_Flt_Extgbl%ROWTYPE; 
    		l_Netting_Bal 		Sttms_Accnet_Master_Extgbl.Netting_Balance%TYPE;
    		l_Adv_Amount 		Cltbs_Acc_Apps_Mast_Extgbl.Adv_Limit_Amount%TYPE;
    		l_Ac_Adv_Amt     		Cltbs_Acc_Apps_Mast_Extgbl.Adv_Limit_Amount%TYPE;
    		
    		
		--CITI_FC12_R5_SUPP SIT1 SFR##### changes ends
      BEGIN
      
            dbg('In Fn_Post_Default_And_Validate..');
      
            -- FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 starts	
      
            dbg('p_Action_Code ----> ' || p_action_code);
            --CITI_FC12_R5_SUPP SIT1 SFR##### changes starts
            IF p_action_code IN ('POP_AVLAMTDTL')
            THEN
               p_wrk_dedtlron   := p_dedtlron;
               
			   IF p_wrk_dedtlron.v_detbs_teller_master.Txn_Drcr IS NOT NULL
			   THEN
					IF p_wrk_dedtlron.v_detbs_teller_master.Txn_Drcr =  'D'
					THEN
						l_Debit_Account	:= p_wrk_dedtlron.v_detbs_teller_master.Txn_Account;
					ELSE
						l_Debit_Account	:=  p_wrk_dedtlron.v_detbs_teller_master.offset_account;
					END IF;
					
					Dbg('l_Debit_Account >>' ||l_Debit_Account);
					IF l_Debit_Account IS NOT NULL
					THEN
						BEGIN 
							SELECT * 
							INTO 	l_Cust_Account
							FROM	Sttms_Cust_Account
							WHERE	Cust_Ac_no	= l_Debit_Account;
						EXCEPTION
						WHEN OTHERS THEN
							Dbg('Failed in selecting accoutn details'||SQLERRM);
							RETURN TRUE;--no valid customer accoutn
						END;
						Dbg('Account_Class '||l_Cust_Account.Account_Class);
						
						BEGIN 
							SELECT * 
							INTO 	l_Cust_Acc_Extgbl
							FROM	Sttms_Cust_Account_Extgbl
							WHERE	Cust_Ac_no	= l_Debit_Account;
						EXCEPTION
						WHEN OTHERS THEN
							Dbg('Failed in selecting accoutn details'||SQLERRM);
							RETURN FALSE;--no valid customer accoutn
						END;
						Dbg('Extgbl acy_uncol_dr '||l_Cust_Acc_Extgbl.Acy_Uncol_Dr);
						
						BEGIN 
							SELECT * 
							INTO 	l_Acc_Bal_Tov
							FROM	Sttms_Account_Bal_Tov
							WHERE	Cust_Ac_no	= l_Debit_Account;
						EXCEPTION
						WHEN OTHERS THEN
							Dbg('Failed in selecting accoutn details'||SQLERRM);
							RETURN FALSE;--no valid customer accoutn
						END;
						Dbg('Cash Table Acy_Avl_bal '||l_Acc_Bal_Tov.acy_Avl_bal);
						--l_acy_avl_bal := abs(l_Acc_Bal_Tov.acy_Avl_bal);--to change;
						l_acy_avl_bal :=  l_Acc_Bal_Tov.acy_Avl_bal;--to change;
						
						IF NOT cvpkss_utils_extgbl.Get_Accls_Flt_Dtl(	l_Cust_Account.Account_Class,
																		l_Accls_Flt_Rec) 
						THEN
							dbg('Could not get flt detail record');
						END IF;
						
						l_Float_Track_Reqd	:= NVL(l_Accls_Flt_Rec.Float_Track_Reqd, 'N');
						Dbg('l_Float_Track_Reqd >> '||l_Float_Track_Reqd);
						
						IF l_Float_Track_Reqd = 'Y' 
						THEN
							l_Float_Mapping_Exists := stpks_cash_utils.fn_resolve_float_mapping(	l_Cust_Account.branch_code,
																									l_Cust_Account.cust_ac_no,
																									l_Float_Mapping_Rec);

							IF l_Float_Mapping_Exists
							THEN
								Dbg('Mapping Exists');
								l_branch  := l_Float_Mapping_Rec.linked_ac_branch;
								l_account := l_Float_Mapping_Rec.linked_ac_no;

								IF NVL(l_Accls_Flt_Rec.Allow_Dda_Ac_Util, 'N') = 'Y' 
								THEN
									l_Netting_Exists := stpks_cash_utils.fn_resolve_netting_structure(	l_branch,
																										l_account,
																										l_netting_structure);
								END IF;
								
								l_uncol_dr_float := l_Cust_Acc_Extgbl.acy_uncol_dr; 
								l_uncol_dr_dda   := stpks_cash_utils.fn_get_uncoll_debit(	l_branch,
																							l_account,
																							l_netting_structure); 
							ELSE
								Dbg('Mapping does not Exists');
								l_branch         := l_Cust_Account.branch_code;
								l_account        := l_Cust_Account.cust_ac_no;
								l_uncol_dr_float := l_Cust_Acc_Extgbl.acy_uncol_dr;
								l_uncol_dr_dda   := 0; 
							END IF;	
							l_Temp_Bal := LEAST(	NVL(	CASE	SIGN(	NVL(l_acy_avl_bal, 0))
															WHEN 	-1 
															THEN
																-1 * l_uncol_dr_float
															ELSE
																l_acy_avl_bal - l_uncol_dr_float
															END
														, 0),
													0);
							l_netting_bal := NVL((l_Netting_Structure.v_sttm_accnet_master_extgbl.Netting_Balance - l_uncol_dr_dda + l_Temp_Bal),0);							
						ELSE
							l_branch         := l_Cust_Account.branch_code;
							l_account        := l_Cust_Account.cust_ac_no;
							l_netting_exists := stpks_cash_utils.fn_resolve_netting_structure(	l_branch,
																								l_account,
																								l_netting_structure);
							BEGIN
								SELECT ac_branch, float_Ac_no
								INTO	l_float_brn, l_float_acc
								FROM	sttms_float_mapping_extgbl
								WHERE	linked_ac_branch	= l_Cust_Account.branch_code
								AND	linked_ac_no		= l_Cust_Account.cust_ac_no
								AND 	float_type = 'P'
								AND 	global.application_date BETWEEN start_date AND expiry_date
								AND 	record_stat = 'O'
								AND 	auth_stat = 'A'
								AND 	status = 'A'; 

								IF NOT acpks_misc.fn_getavlbal(l_float_brn,
																l_float_acc,
																l_float_balance,
																'N')
								THEN
									Dbg('Did not Calculate Balances Properly. Returning 0');
									l_float_balance	:= 0;
								END IF;
							EXCEPTION
							WHEN OTHERS THEN
								dbg('Unable to fetch float payment account=>' || SQLERRM);
								l_float_balance := 0;
							END;
							l_uncol_dr_dda  := stpks_cash_utils.fn_get_uncoll_debit(	l_branch,
																						l_account,
																						l_netting_structure); 
																						
							l_uncol_dr_float	:= stpks_cash_utils.fn_get_uncoll_debit(	l_float_brn,
																						l_float_acc,
																						NULL);
																						
							l_Temp_Bal := LEAST(	NVL(	CASE SIGN(NVL(l_float_balance, 0))
															WHEN 	-1 
															THEN
																-1 * l_uncol_dr_float
															ELSE
																l_float_balance - l_uncol_dr_float
															END,
														0),
													0);
							l_netting_bal 	:= NVL((l_netting_structure.v_sttm_accnet_master_extgbl.netting_balance - l_uncol_dr_dda + l_Temp_Bal), 0);
							
							l_float_balance	:= l_float_balance - l_uncol_dr_float;
						END IF;
						dbg('l_uncol_dr_float=>' || l_uncol_dr_float);
						dbg('l_uncol_dr_dda=>' || l_uncol_dr_dda);
						dbg('l_Temp_Bal=>' || l_Temp_Bal);	
						l_adv_amount := NVL(stpks_cash_utils.fn_get_adv_amount(l_branch,
						                                                           l_account,
						                                                           l_netting_structure),
                       						0);
						
						l_ac_adv_amt 	:= NVL(	stpks_cash_utils.fn_get_adv_amount(	l_Cust_Account.branch_code,
																					l_Cust_Account.cust_ac_no,
																					NULL),
												0);
												
						l_ac_tol_avl_bal := l_acy_avl_bal + l_ac_adv_amt - l_Cust_Acc_Extgbl.acy_uncol_dr;
						dbg('l_ac_tol_avl_bal=>' || l_ac_tol_avl_bal);
						--30-May-2017 Chnages starts
						/*
						l_custom_data('AC_CCY')	:= l_Cust_Account.ccy; 
						
						IF NOT stpks_cash_utils.fn_get_Eca_Amount(	l_branch,
														l_account,
														l_custom_data,
														p_err_code,
														p_err_params)
						THEN
							l_dol_amount := 0;
						ELSE
							IF l_custom_data.EXISTS('ENT-AFT-AVL-USD-AMT')
							THEN
								l_dol_amount := TO_NUMBER(l_custom_data('ENT-AFT-AVL-USD-AMT'));							
							ELSE
								l_dol_amount := 0;
							END IF;
						END IF;
						*/--30-May-2017 Chnages ends
						Dbg('l_acy_avl_bal '||l_acy_avl_bal
							||'l_uncol_dr_float '||l_uncol_dr_float
							||'l_netting_bal '||l_netting_bal
							||'l_adv_amount '||l_adv_amount
							||'l_dol_amount '||l_dol_amount
							||'l_dol_amount '||l_dol_amount
							);
						
						IF l_float_track_reqd = 'Y' 
						THEN
							Dbg('Float tracking Reqd');
							l_tot_net_adv 	:= GREATEST(	(l_acy_avl_bal - l_uncol_dr_float), 0) + l_netting_bal + l_adv_amount; 
							--l_tot_net_adv_dol := GREATEST(l_tot_net_adv, 0) + l_dol_amount; --30-May-2017 Chnages
						ELSE
							IF l_netting_exists 
							THEN
								Dbg('Netting Exists');
								l_tot_net_adv 		:= l_netting_bal + l_adv_amount;
								--l_tot_net_adv_dol 	:= GREATEST(l_tot_net_adv, 0) + l_dol_amount;--30-May-2017 Chnages
							ELSE
								l_tot_net_adv 		:= l_acy_avl_bal - l_uncol_dr_dda + l_adv_amount;
								--l_tot_net_adv_dol 	:= GREATEST(l_tot_net_adv, 0) + l_dol_amount;--30-May-2017 Chnages
							END IF;-- nettting  exists
						END IF;--float tracking reqd
						Dbg('l_tot_net_adv '||l_tot_net_adv);
						--Dbg('l_tot_net_adv dol'||l_tot_net_adv_dol);
						--30-May-2017 Chnages starts
						/*
						p_wrk_dedtlron.v_cstb_ui_columns.num_FIELd1 := l_tot_net_adv;
						p_wrk_dedtlron.v_cstb_ui_columns.num_FIELd2 := l_tot_net_adv_dol;
						*/
						IF l_netting_exists 
						THEN
							Dbg('Netting Exists');
							p_wrk_dedtlron.v_cstb_ui_columns.NUM_FIELD1 := l_netting_bal;
						ELSE 
							/*
								if netting structure is not present the available balance should
								be dr account available balance  - uncollected debits
							*/
							p_wrk_dedtlron.v_cstb_ui_columns.NUM_FIELD1 := l_acy_avl_bal  - l_Cust_Acc_Extgbl.acy_uncol_dr;--31-May-2017 Changes 
															
						END IF ;
						p_wrk_dedtlron.v_cstb_ui_columns.NUM_FIELD2 := l_tot_net_adv;
						Dbg('Available Balance >> '||p_wrk_dedtlron.v_cstb_ui_columns.NUM_FIELD1);
						Dbg('Available Balance with limits >> '||p_wrk_dedtlron.v_cstb_ui_columns.NUM_FIELD2);
						--30-May-2017 Changes ends
					ELSE
						RETURN TRUE;--no dr account
					END IF;
				ELSE
					RETURN TRUE;-- no drcr indicator
				END IF;
            END IF;
			--CITI_FC12_R5_SUPP SIT1 SFR##### changes ends
			
            --FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#116 CashLetter Processing  changes starts
            IF p_action_code IN (cspks_req_global.p_delete) 
            THEN
                  SELECT nvl(latest_event_seq_no, 1)
                  INTO   l_latest_event_seq_no
                  FROM   cstb_contract
                  WHERE  contract_ReF_no = p_wrk_dedtlron.v_detbs_teller_master.reference_no;
                         
                  IF l_latest_event_seq_no > 1 
                  THEN
                        p_err_code := 'DEL-01;';
                        RETURN FALSE;
                  END IF;
            END IF;
            --FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#116 CashLetter Processing  changes ends
            IF p_action_code IN (cspks_req_global.p_new,
                                 cspks_req_global.p_modify,
                                 cspks_req_global.p_amend) 
            THEN
                  dbg('Entered in New Modify Amend Condition');
                  dbg('Setting v_flag = I');
                  v_flag := 'I';
            ELSIF p_action_code = cspks_req_global.p_auth 
            THEN
                  dbg('Entered in Auth Condition');
                  dbg('Setting v_flag = A');
                  v_flag := 'A';
            END IF;
      
            dbg('JRn count is ' || l_count);
      
            dbg(' p_wrk_dedtlron.v_detbs_teller_master-->> TXN_currency' ||
                p_wrk_dedtlron.v_detbs_teller_master.txn_ccy);
            dbg(' p_wrk_dedtlron.v_detbs_teller_master)-->> TXN_amount' ||
                p_wrk_dedtlron.v_detbs_teller_master.txn_amount);
      
            --l_fn_call_id := 1;
            l_tb_cluster_data('MODULE_ID') := 'DE';
      
            IF p_wrk_dedtlron.v_detbs_teller_master.txn_ccy IS NOT NULL 
            THEN
                  IF NOT smpks.fn_limits_validate(v_flag,
                                                  p_wrk_dedtlron.v_detbs_teller_master.txn_ccy,
                                                  p_wrk_dedtlron.v_detbs_teller_master.txn_amount,
                                                  global.user_id,
                                                  global.current_branch,
                                                  p_err_code,
                                                  p_err_params) 
                  THEN
                        dbg('Failed in smpks.fn_limits_validate');
                        RETURN FALSE;
                  ELSE
                        dbg('Returning Success From Fn_Post_Default_And_Validate');
                  END IF;
            
            END IF;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit (End)
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 Starts
            IF p_action_code IN (cspks_req_global.p_new, cspks_req_global.p_copy) 
            THEN
                  p_wrk_dedtlron.v_cstbs_contract__log.product_code        := p_wrk_dedtlron.v_detbs_teller_master.product_code;
                  p_wrk_dedtlron.v_cstbs_contract__log.book_date           := p_wrk_dedtlron.v_detbs_teller_master.booking_date;
                  p_wrk_dedtlron.v_cstbs_contract__log.serial_no           := substr(p_wrk_dedtlron.v_detbs_teller_master.reference_no, 13, 4);
                  p_wrk_dedtlron.v_cstbs_contract__log.latest_version_no   := 1;
                  p_wrk_dedtlron.v_cstbs_contract__log.latest_event_seq_no := 1;
                  p_wrk_dedtlron.v_cstbs_contract__log.contract_status     := 'A';
                  p_wrk_dedtlron.v_cstbs_contract__log.auth_status         := 'U';
                  p_wrk_dedtlron.v_cstbs_contract__log.counterparty        := p_wrk_dedtlron.v_detbs_teller_master.rel_customer;
                  p_wrk_dedtlron.v_cstbs_contract__log.curr_event_code     := 'INIT';
                  p_wrk_dedtlron.v_cstbs_contract__log.module_code         := 'DE';
                  p_wrk_dedtlron.v_cstbs_contract__log.contract_ccy        := p_wrk_dedtlron.v_detbs_teller_master.txn_ccy;
            
                  IF p_wrk_dedtlron.v_detbs_teller_master.txn_cash = 'Y' OR
                     p_wrk_dedtlron.v_detbs_teller_master.offset_cash = 'Y' 
                  THEN
                        l_type := 'C';
                  ELSE
                        l_type := 'O';
                  END IF;
            
                  p_wrk_dedtlron.v_cstbs_contract__log.product_type      := l_type;
                  p_wrk_dedtlron.v_cstbs_contract__log.latest_event_date := global.application_date;
            
                  BEGIN
                        SELECT *
                        INTO   l_de_prod_ext
                        FROM   detms_product_master_extgbl
                        WHERE  product_code = p_wrk_dedtlron.v_detbs_teller_master.product_code;
                  EXCEPTION
                        WHEN no_data_found THEN
                              dbg('Not a Cash letter product..');
                              p_err_code := 'DE-TLR145';
                              RETURN FALSE;
                  END;
            
                  dbg('Cash letter product pref~' ||
                      l_de_prod_ext.tc_product || '~' ||
                      l_de_prod_ext.tc_holiday || '~');
                  --Assigning nostro acc
                  IF nvl(l_de_prod_ext.tc_product, 'N') = 'Y' 
                  THEN
                        --This should be updated from js level
                        p_wrk_dedtlron.v_detb_teller_master_extgbl.reference_no := p_wrk_dedtlron.v_detbs_teller_master.reference_no;
                        p_wrk_dedtlron.v_detb_teller_master_extgbl.evnt_seq_no  := p_wrk_dedtlron.v_detbs_teller_master.evnt_seq_no;
                  
                        debug.pr_debug('DE', 'Nostro acc~' || p_wrk_dedtlron.v_detb_teller_master_extgbl.nostro_acct || '~');
                        --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#343 starts
                        IF p_wrk_dedtlron.v_detb_teller_master_extgbl.nostro_acct IS NULL 
                        THEN
                              p_err_code := 'DE-TLR153;';
                              RETURN FALSE;
                        END IF;
                        --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#343 ends
                        IF l_de_prod_ext.tc_holiday = 'C' 
                        THEN
                              debug.pr_debug('DE',
                                             'Calculating val date with ccy calendar');
                              l_value_date := cepks_date.fn_getworkingday('CCY',
                                                                          p_wrk_dedtlron.v_detbs_teller_master.txn_ccy,
                                                                          global.application_date,
                                                                          'N',
                                                                          nvl(l_de_prod_ext.tc_available_days, 0));
                              debug.pr_debug('DE', 'the ccy val date is ' || l_value_date);
                        
                              l_return_flag := cepkss_date.fn_isholiday('LCL',
                                                                        global.current_branch,
                                                                        l_value_date,
                                                                        l_retval);
                              debug.pr_debug('DE', 'the ccy value date for branch is ' || l_retval);
                        
                              IF l_retval = 'H' THEN
                                    debug.pr_debug('DE', 'ccy value date is branch holiday');
                              
                                    l_value_date := cepkss_date.fn_getworkingday('LCL',
                                                                                 global.current_branch,
                                                                                 l_value_date,
                                                                                 'N',
                                                                                 1);
                                    debug.pr_debug('DE', 'brn val date fro holiday ccy is ' || l_value_date);
                              END IF;
                        ELSE
                              debug.pr_debug('DE', 'Calculating val date with branch calendar');
                              l_value_date := cepkss_date.fn_getworkingday('LCL',
                                                                           global.current_branch,
                                                                           global.application_date,
                                                                           'N',
                                                                           nvl(l_de_prod_ext.tc_available_days, 0));
                        END IF;
                        debug.pr_debug('DE', 'final value date is ' || l_value_date);
                        p_wrk_dedtlron.v_detbs_teller_master.value_date := l_value_date;
                  
                  END IF;
                  dbg('Returning Success From Fn_Post_Default_And_Validate');
            
                  --FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit(End)
            
            END IF;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 Ends
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 #ITR2 sfr 83: starts
            Dbg('Calling depks_services_extgbl.Fn_Validate_rel_cust_mand');
            IF NOT
                depks_services_extgbl.Fn_Validate_rel_cust_mand(GLOBAL.current_branch,
                                                                p_dedtlron.v_detbs_teller_master.rel_customer,
                                                                p_Action_Code,
                                                                p_Err_Code,
                                                                p_Err_Params) 
            THEN
                  Dbg('Failed in depks_services_extgbl.Fn_Validate_rel_cust_mand');
                  pr_log_error(p_function_id,
                               p_source,
                               p_Err_Code,
                               p_Err_Params);
            END IF;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 #ITR2 sfr 83: ends
            --FCUBS CITI Release 12.0.0.1.0 FS Vol6 Tag3 - Instructions processing Changes Starts
            IF p_action_code IN (cspks_req_global.p_new,
                                 cspks_req_global.p_delete,
                                 cspks_req_global.p_copy,
                                 cspks_req_global.p_liquidate,
                                 cspks_req_global.p_reverse) AND
               nvl(p_dedtlron.v_detb_teller_master_extgbl.float_product, 'N') = 'Y' 
            THEN
                  IF NOT stpkss_float_utils_extgbl.fn_get_instr_details(p_wrk_dedtlron.v_detbs_teller_master.txn_branch,
                                                                        p_wrk_dedtlron.v_detbs_teller_master.txn_account,
                                                                        p_wrk_dedtlron.v_detbs_teller_master.offset_account_branch,
                                                                        p_wrk_dedtlron.v_detbs_teller_master.offset_account,
                                                                        p_wrk_dedtlron.v_detbs_teller_master.reference_no,
                                                                        p_wrk_dedtlron.v_detbs_teller_master.evnt_seq_no,
                                                                        p_wrk_dedtlron.v_detbs_teller_master.txn_drcr,
                                                                        l_rec_instr,
                                                                        l_error_code,
                                                                        l_error_params) 
                  THEN
                        dbg('Float Instruction Details not maintained');
                  END IF;
                  pkg_rec_offset_det.offset_ilv := nvl(l_rec_instr.ilv_entry_reqd,
                                                       'N');
                  IF pkg_rec_offset_det.offset_ilv = 'Y' AND
                     nvl(p_wrk_dedtlron.v_detb_teller_master_extgbl.float_product, 'N') = 'Y' 
                  THEN
                        pkg_rec_offset_det.offset_account_branch := p_wrk_dedtlron.v_detbs_teller_master.offset_account_branch;
                        pkg_rec_offset_det.offset_account        := p_wrk_dedtlron.v_detbs_teller_master.offset_account;
                        pkg_rec_offset_det.offset_ccy            := p_wrk_dedtlron.v_detbs_teller_master.offset_ccy;
                        pkg_rec_offset_det.offset_amount         := p_wrk_dedtlron.v_detbs_teller_master.offset_amount;
                        IF NOT cvpks_utils.get_sttb_acc(l_rec_instr.cr_acc_br,
                                                        l_rec_instr.cr_account,
                                                        l_acc_rec) 
                        THEN
                              dbg('Unable to GET float account details');
                              ovpkss.pr_appendtbl('ST-FTFR-002', '');
                        END IF;
                        dbg('l_acc_rec.ac_gl_no:' || l_acc_rec.ac_gl_no);
                        p_wrk_dedtlron.v_detbs_teller_master.offset_account_branch := nvl(l_acc_rec.branch_code,
                                                                                          p_wrk_dedtlron.v_detbs_teller_master.txn_branch);
                        p_wrk_dedtlron.v_detbs_teller_master.offset_account        := l_acc_rec.ac_gl_no;
                        p_wrk_dedtlron.v_detbs_teller_master.offset_ccy            := nvl(l_acc_rec.ac_gl_ccy,
                                                                                          p_wrk_dedtlron.v_detbs_teller_master.txn_ccy);
                        IF p_wrk_dedtlron.v_detbs_teller_master.txn_ccy <>
                           p_wrk_dedtlron.v_detbs_teller_master.offset_ccy 
                        THEN
                              IF NOT cypkss.fn_amt1_to_amt2(p_wrk_dedtlron.v_detbs_teller_master.txn_branch,
                                                            p_wrk_dedtlron.v_detbs_teller_master.txn_ccy,
                                                            p_wrk_dedtlron.v_detbs_teller_master.offset_ccy,
                                                            p_wrk_dedtlron.v_detbs_teller_master.txn_amount,
                                                            'Y',
                                                            p_wrk_dedtlron.v_detbs_teller_master.offset_amount,
                                                            l_rate,
                                                            l_error_code) 
                              THEN
                                    dbg('Failed in converting transfer out amt');
                                    ovpkss.pr_appendtbl(l_error_code, '');
                                    RETURN FALSE;
                              END IF;
                        END IF;
                  END IF;
            END IF;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol6 Tag3 - Instructions processing Changes Ends
            
            --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 Changes Starts
            IF p_action_code IN (cspks_req_global.p_New, cspks_req_global.p_Modify)
            THEN
                 SELECT count(*)
                 INTO   l_count
                 FROM   catbs_check_util_extgbl a
                 WHERE  a.branch = p_wrk_dedtlron.v_detbs_teller_master.txn_branch
                 AND    a.account = p_wrk_dedtlron.v_detbs_teller_master.txn_account
                 AND    a.check_no = p_wrk_dedtlron.v_detbs_teller_master.instrument_no
                 AND    a.auth_stat = 'U'
                 AND    a.once_auth = 'Y';
                 
                 Dbg('l_count in catbs_check_util_extgbl: '||l_count);
                 IF l_count > 0
                 THEN
                       Dbg('Original claim amount is in unauthorized status');
                       p_err_code   := 'CA-EXT-07';
                       RETURN FALSE;
                 END IF;
            END IF;
            --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 Changes Ends
            dbg('Returning Success From Fn_Post_Default_And_Validate');
      
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedtlron_Custom.Fn_Post_Default_And_Validate ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_default_and_validate;

      FUNCTION fn_pre_resolve_ref_numbers(p_source           IN VARCHAR2,
                                          p_source_operation IN VARCHAR2,
                                          p_function_id      IN VARCHAR2,
                                          p_action_code      IN VARCHAR2,
                                          p_dedtlron         IN OUT depks_dedtlron_main.ty_dedtlron,
                                          p_err_code         IN OUT VARCHAR2,
                                          p_err_params       IN OUT VARCHAR2)
            RETURN BOOLEAN IS
      BEGIN
            dbg('In Fn_Pre_Resolve_Ref_Numbers..');
      
            dbg('Returning Success From Fn_Pre_Resolve_Ref_Numbers');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**', 'In When Others of depks_dedtlron_Main.Fn_Pre_Resolve_Ref_Numbers ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_resolve_ref_numbers;
      
      FUNCTION fn_post_resolve_ref_numbers(p_source           IN VARCHAR2,
                                           p_source_operation IN VARCHAR2,
                                           p_function_id      IN VARCHAR2,
                                           p_action_code      IN VARCHAR2,
                                           p_dedtlron         IN OUT depks_dedtlron_main.ty_dedtlron,
                                           p_err_code         IN OUT VARCHAR2,
                                           p_err_params       IN OUT VARCHAR2)
            RETURN BOOLEAN IS
      BEGIN
            dbg('In Fn_Post_Resolve_Ref_Numbers..');
      
            dbg('Returning Success From Fn_Post_Resolve_Ref_Numbers..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**', 'In When others of depks_dedtlron_Main.Fn_Post_Resolve_Ref_Numbers ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_resolve_ref_numbers;
      
      FUNCTION fn_pre_product_default(p_source           IN VARCHAR2,
                                      p_source_operation IN VARCHAR2,
                                      p_function_id      IN VARCHAR2,
                                      p_action_code      IN VARCHAR2,
                                      p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                                      p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                                      p_err_code         IN OUT VARCHAR2,
                                      p_err_params       IN OUT VARCHAR2)
            RETURN BOOLEAN IS
      BEGIN
            dbg('In Fn_Pre_Product_Default..');
      
            dbg('Returning Success From Fn_Pre_Product_Default..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**', 'In When Others of depks_dedtlron_Custom.Fn_Pre_Product_Default ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_product_default;

      FUNCTION fn_post_product_default(p_source           IN VARCHAR2,
                                       p_source_operation IN VARCHAR2,
                                       p_function_id      IN VARCHAR2,
                                       p_action_code      IN VARCHAR2,
                                       p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                                       p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                                       p_err_code         IN OUT VARCHAR2,
                                       p_err_params       IN OUT VARCHAR2)
            RETURN BOOLEAN IS
      BEGIN
            dbg('In Fn_Post_Product_Default..');
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol6 Tag3 - Instructions processing Changes Starts
            BEGIN
                  SELECT nvl(float_product, 'N')
                  INTO   p_wrk_dedtlron.v_detb_teller_master_extgbl.float_product
                  FROM   detms_product_master_extgbl
                  WHERE  product_code = p_dedtlron.v_detbs_teller_master.product_code;
                  dbg('Float Product is = ' || p_wrk_dedtlron.v_detb_teller_master_extgbl.float_product);
            EXCEPTION
                  WHEN no_data_found THEN
                        dbg('In NDF');
                        p_wrk_dedtlron.v_detb_teller_master_extgbl.float_product := 'N';
            END;
            
            IF p_wrk_dedtlron.v_detb_teller_master_extgbl.float_product = 'N' 
            THEN
                  p_wrk_dedtlron.v_detb_teller_master_extgbl.float_direction := '';
            ELSE
                  p_wrk_dedtlron.v_detb_teller_master_extgbl.float_direction := 'R';
            END IF;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol6 Tag3 - Instructions processing Changes Ends
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 starts
            dbg('p_action_code' || p_action_code);
            IF p_action_code = 'PRDDFLT' 
            THEN
                  BEGIN
                        debug.pr_debug('DE',
                                       'Picking TC_PRODUCT from product parameters::' ||
                                       p_wrk_dedtlron.v_detb_teller_master_extgbl.tc_product || '~');
                        SELECT tc_product
                        INTO   p_wrk_dedtlron.v_detb_teller_master_extgbl.tc_product
                        FROM   detms_product_master_extgbl
                        WHERE  product_code = p_wrk_dedtlron.v_detbs_teller_master.product_code;
                        debug.pr_debug('DE',
                                       'Picking TC_PRODUCT from product parameters::' ||
                                       p_wrk_dedtlron.v_detb_teller_master_extgbl.tc_product || '~');
                  EXCEPTION
                        WHEN no_data_found THEN
                              ovpkss.pr_appendtbl('DE-TLR145', '');
                              debug.pr_debug('DE', 'Product code does not have cash letter parameter maint');
                  END;
            
                  --Currently Nostro acc maint is branch product wise
            
                  dbg('Cash letter product pref~' || p_wrk_dedtlron.v_detb_teller_master_extgbl.tc_product || '~');
                  --Assigning nostro acc
                  IF nvl(p_wrk_dedtlron.v_detb_teller_master_extgbl.tc_product, 'N') = 'Y' 
                  THEN
                        --This should be updated from js
                        p_wrk_dedtlron.v_detb_teller_master_extgbl.reference_no := p_wrk_dedtlron.v_detbs_teller_master.reference_no;
                        p_wrk_dedtlron.v_detb_teller_master_extgbl.evnt_seq_no  := p_wrk_dedtlron.v_detbs_teller_master.evnt_seq_no;
                  
                        BEGIN
                              debug.pr_debug('DE',
                                             'Picking nostro account from branch parameters for current branch~' ||
                                             p_wrk_dedtlron.v_detbs_teller_master.product_code || '~' ||
                                             global.current_branch || '~');
                        
                              SELECT nostro_acc
                              INTO   p_wrk_dedtlron.v_detb_teller_master_extgbl.nostro_acct
                              FROM   detms_cl_preferences_extgbl
                              WHERE  product_code = p_wrk_dedtlron.v_detbs_teller_master.product_code
                              AND    branch_code = global.current_branch
                              AND    auth_stat = 'A'
                              AND    record_stat = 'O';
                        
                        EXCEPTION
                              WHEN no_data_found THEN
                                    BEGIN
                                          debug.pr_debug('DE', 'Picking Nostro account from branch parameters for ALL branches');
                                    
                                          SELECT nostro_acc
                                          INTO   p_wrk_dedtlron.v_detb_teller_master_extgbl.nostro_acct
                                          FROM   detms_cl_preferences_extgbl
                                          WHERE  product_code = p_wrk_dedtlron.v_detbs_teller_master.product_code
                                          AND    branch_code = 'ALL'
                                          AND    auth_stat = 'A'
                                          AND    record_stat = 'O';
                                    EXCEPTION
                                          WHEN no_data_found THEN
                                                debug.pr_debug('DE', 'Product code does not have branch parameter maint');
                                    END;
                        END;
                  END IF;
            END IF;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8  Ends
      
            --FCUBS CITI Release 12.0.0.1.0 Vol4 Tag5 starts
            BEGIN
                  SELECT nvl(default_chg_coll_from, 'T')
                  INTO   p_wrk_dedtlron.v_detbs_teller_master.charge_account
                  FROM   detms_product_master
                  WHERE  product_code = p_dedtlron.v_detbs_teller_master.product_code;
                  dbg('chg collectd frm ' ||  p_wrk_dedtlron.v_detb_teller_master_extgbl.float_product);
            EXCEPTION
                  WHEN no_data_found THEN
                        dbg('In NDF');
                        p_wrk_dedtlron.v_detbs_teller_master.charge_account := 'T';
            END;
            --FCUBS CITI Release 12.0.0.1.0 Vol4 Tag5 ends
      
            --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 Changes Starts
            IF fn_partial_pay_enabled 
            THEN
                  p_wrk_dedtlron.v_cstb_ui_columns.CHAR_FIELD13 := 'Y';
            ELSE
                  p_wrk_dedtlron.v_cstb_ui_columns.CHAR_FIELD13 := 'N';
            END IF;
            dbg('Partial pay enabled: ' || p_wrk_dedtlron.v_cstb_ui_columns.CHAR_FIELD13);
            --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 Changes Ends
      
            dbg('Returning Success From Fn_Post_Product_Default..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedtlron_Custom.Fn_Post_Product_Default ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_product_default;

      FUNCTION fn_pre_unlock(p_source           IN VARCHAR2,
                             p_source_operation IN VARCHAR2,
                             p_function_id      IN VARCHAR2,
                             p_action_code      IN OUT VARCHAR2,
                             p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                             p_err_code         IN OUT VARCHAR2,
                             p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
      BEGIN
            dbg('In Fn_Pre_Unlock..');
      
            dbg('Returning Success From Fn_Pre_Unlock..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedtlron_Custom.Fn_Pre_Unlock ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_unlock;

      FUNCTION fn_post_unlock(p_source           IN VARCHAR2,
                              p_source_operation IN VARCHAR2,
                              p_function_id      IN VARCHAR2,
                              p_action_code      IN OUT VARCHAR2,
                              p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                              p_err_code         IN OUT VARCHAR2,
                              p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
      BEGIN
            dbg('In Fn_Post_Unlock');
      
            dbg('Returning Success From Fn_Post_Unlock..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedtlron_Custom.Fn_Post_Unlock ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_unlock;

      FUNCTION fn_pre_subsys_pickup(p_source           IN VARCHAR2,
                                    p_source_operation IN VARCHAR2,
                                    p_function_id      IN VARCHAR2,
                                    p_action_code      IN VARCHAR2,
                                    p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                                    p_prev_dedtlron    IN OUT depks_dedtlron_main.ty_dedtlron,
                                    p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                                    p_err_code         IN OUT VARCHAR2,
                                    p_err_params       IN OUT VARCHAR2)
            RETURN BOOLEAN IS
      BEGIN
            dbg('In Fn_Pre_Subsys_Pickup..');
            --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 Changes Starts
            Dbg('instrument_no: ' || p_dedtlron.v_detbs_teller_master.instrument_no);
            Dbg('txn_amount: ' || p_dedtlron.v_detbs_teller_master.txn_amount);
            Dbg('original_amt: ' || p_dedtlron.v_catb_check_util_extgbl.original_amt);
            Dbg('maker_id: ' || p_dedtlron.v_detbs_teller_master.maker_id);
            Dbg('maker_dt_stamp: ' || p_dedtlron.v_detbs_teller_master.maker_dt_stamp);
      
            IF p_action_code IN (cspks_req_global.p_New, cspks_req_global.p_Modify) AND
               p_dedtlron.v_detbs_teller_master.instrument_no IS NOT NULL AND
               p_dedtlron.v_catb_check_util_extgbl.original_amt IS NOT NULL 
            THEN
                  IF nvl(p_dedtlron.v_catb_check_util_extgbl.original_amt,0) =
                     p_dedtlron.v_detbs_teller_master.txn_amount 
                  THEN
                        Dbg('original_amt = txn_amount');
                        pr_log_error(p_function_id,p_source,'CA-EXT-06',null);
                  ELSIF nvl(p_dedtlron.v_catb_check_util_extgbl.original_amt,0) <
                     p_dedtlron.v_detbs_teller_master.txn_amount 
                  THEN
                        Dbg('Original amount cannot be less than Transaction amount');
                        p_err_code := 'CA-EXT-04';
                        RETURN FALSE;	
                  ELSE
                        Dbg('original_amt > txn_amount');
                        IF NOT cvpkss_utils_extgbl.fn_ins_orig_chq_amt(p_dedtlron.v_detbs_teller_master.txn_branch,
                                                                       p_dedtlron.v_detbs_teller_master.txn_account,
                                                                       p_dedtlron.v_detbs_teller_master.instrument_no,
                                                                       p_wrk_dedtlron.v_catb_check_util_extgbl.original_amt,
                                                                       p_dedtlron.v_detbs_teller_master.maker_id,
                                                                       p_dedtlron.v_detbs_teller_master.maker_dt_stamp,
                                                                       'U',
                                                                       p_err_code) --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 - review changes
                        THEN
                              Dbg('Failed to insert original claim amount');
                              RETURN FALSE; --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 - review changes
                        END IF;
                  END IF;
            END IF;
            --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 Changes ends
            dbg('Returning Success From Fn_Pre_Subsys_Pickup..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**','In When Others of depks_dedtlron_Custom.Fn_Pre_Subsys_Pickup ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_subsys_pickup;

      FUNCTION fn_post_subsys_pickup(p_source           IN VARCHAR2,
                                     p_source_operation IN VARCHAR2,
                                     p_function_id      IN VARCHAR2,
                                     p_action_code      IN VARCHAR2,
                                     p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                                     p_prev_dedtlron    IN OUT depks_dedtlron_main.ty_dedtlron,
                                     p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                                     p_err_code         IN OUT VARCHAR2,
                                     p_err_params       IN OUT VARCHAR2)
            RETURN BOOLEAN IS
      BEGIN
            dbg('In Fn_Post_Subsys_Pickup..');
      
            dbg('Returning Success From Fn_Post_Subsys_Pickup..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**','In When Others of depks_dedtlron_Custom.Fn_Post_Subsys_Pickup ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_subsys_pickup;

      FUNCTION fn_pre_enrich(p_source           IN VARCHAR2,
                             p_source_operation IN VARCHAR2,
                             p_function_id      IN VARCHAR2,
                             p_action_code      IN VARCHAR2,
                             p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                             p_prev_dedtlron    IN OUT depks_dedtlron_main.ty_dedtlron,
                             p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                             p_err_code         IN OUT VARCHAR2,
                             p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
      BEGIN
            dbg('In Fn_Pre_Enrich..');
      
            dbg('Returning Success From Fn_Pre_Enrich..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**','In When Others of depks_dedtlron_Custom.Fn_Pre_Enrich ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_enrich;

      FUNCTION fn_post_enrich(p_source           IN VARCHAR2,
                              p_source_operation IN VARCHAR2,
                              p_function_id      IN VARCHAR2,
                              p_action_code      IN VARCHAR2,
                              p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                              p_prev_dedtlron    IN OUT depks_dedtlron_main.ty_dedtlron,
                              p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                              p_err_code         IN OUT VARCHAR2,
                              p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
      BEGIN
            dbg('In Fn_Post_Enrich..');
      
            dbg('Returning Success From Fn_Post_Enrich..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**','In When Others of depks_dedtlron_Custom.Fn_Post_Enrich ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_enrich;

      FUNCTION fn_pre_upload_db(p_source           IN VARCHAR2,
                                p_source_operation IN VARCHAR2,
                                p_function_id      IN VARCHAR2,
                                p_action_code      IN VARCHAR2,
                                p_child_function   IN VARCHAR2,
                                p_multi_trip_id    IN VARCHAR2,
                                p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                                p_prev_dedtlron    IN depks_dedtlron_main.ty_dedtlron,
                                p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                                p_err_code         IN OUT VARCHAR2,
                                p_err_params       IN OUT VARCHAR2)
            RETURN BOOLEAN IS
            --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes strts
            l_count       number;
            l_txn_id      iftb_eca_req_dtl_extgbl.unique_txn_id%TYPE;
            l_trn_branch  sttm_branch.branch_code%TYPE;
            l_sttmbrn_gbl cvpkss_utils_extgbl.typ_sttmbrn_gbl;
            l_eca_flag    sttm_branch_extgbl.eca_flag%TYPE;
            --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends
      BEGIN
            dbg('In Fn_Pre_Upload_Db..');
            --FCUBS12.0.1.7.0 CITI Vol4 Tag3 IUT3 SFR#402 starts
            IF p_dedtlron.v_detbs_teller_master.rel_customer IS NULL THEN
                  p_wrk_dedtlron.v_detbs_teller_master.rel_customer := NULL;
            END IF;
            --FCUBS12.0.1.7.0 CITI Vol4 Tag3 IUT3 SFR#402 ends
      
            --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes strts
            l_trn_branch := global.current_branch;
            dbg('Calling cvpks_utils_extgbl.get_sttm_brn for getting branch level ECA flag value');
            cvpks_utils_extgbl.get_sttm_brn(l_trn_branch, l_sttmbrn_gbl);
            Dbg('ECA Flag value for the branch is: ' || l_sttmbrn_gbl.sttm_brn_extgblrec.eca_flag);
            l_eca_flag := NVL(l_sttmbrn_gbl.sttm_brn_extgblRec.eca_flag,'N');
      
            IF p_action_code = cspks_req_global.p_delete AND l_eca_flag IN ('F', 'L') 
            THEN
                  dbg('Action Code ' || p_action_code);
                  BEGIN
                        SELECT max(unique_txn_id)
                        INTO   l_txn_id
                        FROM   iftb_eca_req_dtl_extgbl
                        WHERE  fcc_process_ref_no = p_wrk_dedtlron.v_detbs_teller_master.reference_no
                        AND    original_number = p_wrk_dedtlron.v_detbs_teller_master.reference_no
                        AND    eca_status <> 'D';
                  EXCEPTION
                        WHEN OTHERS THEN
                              dbg('In WOT of ' || SQLERRM);
                  END;
                  dbg('unique_txn_id is ' || l_txn_id);
            
                  BEGIN
                        UPDATE iftb_eca_req_dtl_extgbl
                        SET    eca_status = 'D'
                        WHERE  unique_txn_id = l_txn_id;
                  EXCEPTION
                        WHEN OTHERS THEN
                              dbg('Error while updating.. ' || SQLERRM);
                  END;
            
            END IF;
            --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends
            
            --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 Changes Starts
            IF p_action_code IN (cspks_req_global.p_New, cspks_req_global.p_Modify) AND
               (p_dedtlron.v_detbs_teller_master.instrument_no IS NULL OR
               p_dedtlron.v_catb_check_util_extgbl.original_amt IS NULL)
            THEN
                  p_wrk_dedtlron.v_detb_teller_master_extgbl.PARTIAL_PAY_REASON := null;
            END IF;
            --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 Changes Ends
            
            dbg('Returning Success From Fn_Pre_Upload_Db..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**', 'In When Others of depks_dedtlron_Custom.Fn_Pre_Upload_Db ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_upload_db;

      FUNCTION fn_post_upload_db(p_source           IN VARCHAR2,
                                 p_source_operation IN VARCHAR2,
                                 p_function_id      IN VARCHAR2,
                                 p_action_code      IN VARCHAR2,
                                 p_child_function   IN VARCHAR2,
                                 p_multi_trip_id    IN VARCHAR2,
                                 p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                                 p_prev_dedtlron    IN depks_dedtlron_main.ty_dedtlron,
                                 p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                                 p_err_code         IN OUT VARCHAR2,
                                 p_err_params       IN OUT VARCHAR2)
            RETURN BOOLEAN IS
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 Starts
            l_count      NUMBER := 0;
            l_ins_count  NUMBER := 0;
            l_upd_count  NUMBER := 0;
            l_del_count  NUMBER := 0;
            l_wrk_count  NUMBER := 0;
            l_prev_count NUMBER := 0;
            l_rec_found  BOOLEAN := FALSE;
      
            i_v_detb_tc_detail_extgbl depks_dedtlron_main.ty_tb_v_detb_tc_detail_extgbl;
            u_v_detb_tc_detail_extgbl depks_dedtlron_main.ty_tb_v_detb_tc_detail_extgbl;
            d_v_detb_tc_detail_extgbl depks_dedtlron_main.ty_tb_v_detb_tc_detail_extgbl;
      
            l_prod_master_extgbl detms_product_master_extgbl%ROWTYPE;
            l_check_amount       detbs_tc_detail_extgbl.check_amount%TYPE;
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 Ends
      
            --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes for updating iftbs_otat_details_extgbl status on Del strts
            l_ot_at_tk_ref iftbs_otat_details_extgbl.otat_tkt_ref%TYPE;
            l_auth_stat    VARCHAR2(1);
            l_rej_code     NUMBER := 1;
            l_called_from  varchar2(10) := 'AUTHORIZE';
            l_action_code  VARCHAR2(5) := 'D';
            l_auth_id      varchar2(10) := global.user_id;
            l_otat_status  iftbs_otat_details_extgbl.status%TYPE;
            l_msg          varchar2(500);
            --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends     
      BEGIN
            dbg('In Fn_Post_Upload_Db..');
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 Starts
            IF p_action_code = cspks_req_global.p_new 
            THEN
                  dbg('Inserting Into DETB_TELLER_MASTER_EXTGBL..');
                  BEGIN
                        --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#353 starts
                        p_wrk_dedtlron.v_detb_teller_master_extgbl.reference_no := p_wrk_dedtlron.v_detbs_teller_master.reference_no;
                        p_wrk_dedtlron.v_detb_teller_master_extgbl.evnt_seq_no  := p_wrk_dedtlron.v_detbs_teller_master.evnt_seq_no;
                        --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#353 ends
                  
                        IF p_wrk_dedtlron.v_detb_teller_master_extgbl.reference_no IS NOT NULL AND
                           p_wrk_dedtlron.v_detb_teller_master_extgbl.evnt_seq_no IS NOT NULL 
                        THEN
                              dbg('Record Sent..');
                              INSERT INTO detbs_teller_master_extgbl
                              VALUES p_wrk_dedtlron.v_detb_teller_master_extgbl;
                        END IF;
                        --FCUBS CITI Release 12.0.0.1.0 Vol4 Tag5 STARTS
                        IF p_dedtlron.v_detbs_teller_master.charge_account = 'A' 
                        THEN
                              global_custom_extgbl.g_teller_other_account     := TRUE;
                              global_custom_extgbl.g_teller_other_account_fid := p_function_id;
                        END IF;
                        --FCUBS CITI Release 12.0.0.1.0 Vol4 Tag5 ends
                  EXCEPTION
                        WHEN OTHERS THEN
                              dbg('Failed In Insert intoDETB_TELLER_MASTER_EXTGBL..');
                              dbg(SQLERRM);
                              p_err_code   := 'ST-UPLD-001';
                              p_err_params := '@DETB_TELLER_MASTER_EXTGBL';
                              RETURN FALSE;
                  END;
            
                  dbg('Inserting Into DETB_TC_DETAIL_EXTGBL..');
            
                  BEGIN
                        l_count := p_wrk_dedtlron.v_detb_tc_detail_extgbl.COUNT;
                        FORALL l_index IN 1 .. l_count
                              INSERT INTO detbs_tc_detail_extgbl
                              VALUES p_wrk_dedtlron.v_detb_tc_detail_extgbl
                                    (l_index);
                  EXCEPTION
                        WHEN OTHERS THEN
                              dbg('Failed In Insert intoDETB_TC_DETAIL_EXTGBL..');
                              dbg(SQLERRM);
                              p_err_code   := 'ST-UPLD-001';
                              p_err_params := '@DETB_TC_DETAIL_EXTGBL';
                              RETURN FALSE;
                  END;
            
                  dbg(' Populate detbs_tc_tracers table');
            
                  -- IF l_prod_master_extgbl.tc_product = 'Y' THEN FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#341
                  BEGIN
                        SELECT *
                        INTO   l_prod_master_extgbl
                        FROM   detms_product_master_extgbl
                        WHERE  product_code = p_wrk_dedtlron.v_detbs_teller_master.product_code;
                  
                  EXCEPTION
                        WHEN OTHERS THEN
                              dbg('problem here');
                              p_err_code   := 'DE-TLR147';
                              p_err_params := '@detms_product_master_extgbl';
                  END;
                  
                  IF l_prod_master_extgbl.tc_product = 'Y' 
                  THEN
                        --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#341
                        IF l_prod_master_extgbl.tc_tracer_required = 'R' 
                        THEN
                              IF NOT depkss_cashletter_extgbl.fn_populate_tracer(p_wrk_dedtlron) 
                              THEN
                                    dbg('Failed In Insert into DETB_TC_DETAIL_EXTGBL..' || SQLERRM);
                                    p_err_code   := 'ST-UPLD-001';
                                    p_err_params := '@DETBS_TC_TRACERS_EXTGBL';
                                    RETURN FALSE;
                              END IF;
                        END IF;
                  END IF;
            ELSIF p_action_code = cspks_req_global.p_modify 
            THEN
                  IF p_wrk_dedtlron.v_detb_teller_master_extgbl.reference_no IS NOT NULL AND
                     p_wrk_dedtlron.v_detb_teller_master_extgbl.evnt_seq_no IS NOT NULL 
                  THEN
                        dbg('Record Sent..');
                        dbg('Updating Single Record Node :  DETB_TELLER_MASTER_EXTGBL..');
                        BEGIN
                              UPDATE detbs_teller_master_extgbl
                              SET    nostro_acct       = p_wrk_dedtlron.v_detb_teller_master_extgbl.nostro_acct,
                                     tc_offset_ccy     = p_wrk_dedtlron.v_detb_teller_master_extgbl.tc_offset_ccy,
                                     by_order_of_1     = p_wrk_dedtlron.v_detb_teller_master_extgbl.by_order_of_1,
                                     by_order_of_2     = p_wrk_dedtlron.v_detb_teller_master_extgbl.by_order_of_2,
                                     by_order_of_3     = p_wrk_dedtlron.v_detb_teller_master_extgbl.by_order_of_3,
                                     mail_to_1         = p_wrk_dedtlron.v_detb_teller_master_extgbl.mail_to_1,
                                     mail_to_2         = p_wrk_dedtlron.v_detb_teller_master_extgbl.mail_to_2,
                                     mail_to_3         = p_wrk_dedtlron.v_detb_teller_master_extgbl.mail_to_3,
                                     mail_to_4         = p_wrk_dedtlron.v_detb_teller_master_extgbl.mail_to_4,
                                     payment_details_1 = p_wrk_dedtlron.v_detb_teller_master_extgbl.payment_details_1,
                                     payment_details_2 = p_wrk_dedtlron.v_detb_teller_master_extgbl.payment_details_2,
                                     payment_details_3 = p_wrk_dedtlron.v_detb_teller_master_extgbl.payment_details_3,
                                     payment_details_4 = p_wrk_dedtlron.v_detb_teller_master_extgbl.payment_details_4,
                                     drawn_on          = p_wrk_dedtlron.v_detb_teller_master_extgbl.drawn_on,
                                     --FCUBS CITI Release 12.0.0.1.0 Vol4 Tag5 STARTS
                                     internal_remarks = p_wrk_dedtlron.v_detb_teller_master_extgbl.internal_remarks,
                                     external_remarks = p_wrk_dedtlron.v_detb_teller_master_extgbl.external_remarks,
                                     other_account    = p_wrk_dedtlron.v_detb_teller_master_extgbl.other_account,
                                     other_branch     = p_wrk_dedtlron.v_detb_teller_master_extgbl.other_branch,
                                     other_ccy        = p_wrk_dedtlron.v_detb_teller_master_extgbl.other_ccy
                              --FCUBS CITI Release 12.0.0.1.0 Vol4 Tag5 ENDS
                              WHERE  reference_no = p_wrk_dedtlron.v_detb_teller_master_extgbl.reference_no
                              AND    evnt_seq_no = p_wrk_dedtlron.v_detb_teller_master_extgbl.evnt_seq_no;
                        EXCEPTION
                              WHEN OTHERS THEN
                                    dbg('Failed in Insert Into DETB_TELLER_MASTER_EXTGBL..');
                                    dbg(SQLERRM);
                                    p_err_code   := 'ST-UPLD-001';
                                    p_err_params := '@DETB_TELLER_MASTER_EXTGBL';
                                    RETURN FALSE;
                        END;
                        
                        IF SQL%ROWCOUNT = 0 
                        THEN
                              BEGIN
                                    INSERT INTO detbs_teller_master_extgbl
                                    VALUES p_wrk_dedtlron.v_detb_teller_master_extgbl;
                              EXCEPTION
                                    WHEN OTHERS THEN
                                          dbg('Failed in Insert Into DETB_TELLER_MASTER_EXTGBL..');
                                          dbg(SQLERRM);
                                          p_err_code   := 'ST-UPLD-001';
                                          p_err_params := '@DETB_TELLER_MASTER_EXTGBL';
                                          RETURN FALSE;
                              END;
                        END IF;
                  ELSE
                        dbg('Check If The Record Is Already Present for  DETB_TELLER_MASTER_EXTGBL. .');
                        IF p_prev_dedtlron.v_detb_teller_master_extgbl.reference_no IS NOT NULL OR
                           p_prev_dedtlron.v_detb_teller_master_extgbl.evnt_seq_no IS NOT NULL 
                        THEN
                              dbg('Prev Data Exists And Not Sent For  DETB_TELLER_MASTER_EXTGBL. Delete the Existing Record.');
                              DELETE detbs_teller_master_extgbl
                              WHERE  reference_no = p_prev_dedtlron.v_detb_teller_master_extgbl.reference_no
                              AND    evnt_seq_no = p_prev_dedtlron.v_detb_teller_master_extgbl.evnt_seq_no;
                        END IF;
                  END IF;
            
                  dbg('Preapring Delete Types for  DETB_TC_DETAIL_EXTGBL..');
            
                  l_wrk_count := p_wrk_dedtlron.v_detb_tc_detail_extgbl.COUNT;
            
                  l_prev_count := p_prev_dedtlron.v_detb_tc_detail_extgbl.COUNT;
            
                  IF l_prev_count > 0 
                  THEN
                        FOR l_index1 IN 1 .. l_prev_count 
                        LOOP
                              l_rec_found := FALSE;
                              IF l_wrk_count > 0 
                              THEN
                                    FOR l_index IN 1 .. l_wrk_count 
                                    LOOP
                                          IF (nvl(p_wrk_dedtlron.v_detb_tc_detail_extgbl(l_index).check_no,'@') =
                                             nvl(p_prev_dedtlron.v_detb_tc_detail_extgbl(l_index1).check_no,'@')) 
                                          THEN
                                                dbg('Record Has Been Found.Update Case..');
                                                l_rec_found := TRUE;
                                                EXIT;
                                          END IF;
                                    END LOOP;
                              END IF;
                              IF NOT l_rec_found 
                              THEN
                                    dbg('Record is Deleted...');
                                    d_v_detb_tc_detail_extgbl(d_v_detb_tc_detail_extgbl.COUNT + 1) := p_prev_dedtlron.v_detb_tc_detail_extgbl(l_index1);
                              END IF;
                        END LOOP;
                  END IF;
            
                  l_del_count := d_v_detb_tc_detail_extgbl.COUNT;
            
                  dbg('Records Deleted  :' || l_del_count);
            
                  IF l_del_count > 0 
                  THEN
                        FOR l_index IN 1 .. l_del_count 
                        LOOP
                              dbg('Deleting Record...');
                              DELETE detbs_tc_detail_extgbl
                              WHERE  contract_ref_no = d_v_detb_tc_detail_extgbl(l_index).contract_ref_no
                              AND    check_no = d_v_detb_tc_detail_extgbl(l_index).check_no;
                        END LOOP;
                  END IF;
                  l_ins_count := i_v_detb_tc_detail_extgbl.COUNT;
                  dbg('New Records Added  :' || l_ins_count);
                  BEGIN
                        l_count := i_v_detb_tc_detail_extgbl.COUNT;
                        FORALL l_index IN 1 .. l_count
                              INSERT INTO detbs_tc_detail_extgbl
                              VALUES i_v_detb_tc_detail_extgbl(l_index);
                  EXCEPTION
                        WHEN OTHERS THEN
                              dbg('Failed in Insert IntoDETB_TC_DETAIL_EXTGBL..');
                              dbg(SQLERRM);
                              p_err_code   := 'ST-UPLD-001';
                              p_err_params := '@DETB_TC_DETAIL_EXTGBL';
                              RETURN FALSE;
                  END;
                  l_upd_count := u_v_detb_tc_detail_extgbl.COUNT;
                  dbg('Records Modified  :' || l_upd_count);
                  IF l_upd_count > 0 
                  THEN
                        FOR l_index IN 1 .. l_upd_count 
                        LOOP
                              dbg('Updating The  Record...');
                              BEGIN
                                    UPDATE detbs_tc_detail_extgbl
                                    SET    check_amount = u_v_detb_tc_detail_extgbl(l_index).check_amount,
                                           check_ccy = u_v_detb_tc_detail_extgbl(l_index).check_ccy,
                                           esn = u_v_detb_tc_detail_extgbl(l_index).esn
                                    WHERE  contract_ref_no = u_v_detb_tc_detail_extgbl(l_index).contract_ref_no
                                    AND    check_no = u_v_detb_tc_detail_extgbl(l_index).check_no;
                              EXCEPTION
                                    WHEN OTHERS THEN
                                          dbg('Failed in Updating DETB_TC_DETAIL_EXTGBL..');
                                          dbg(SQLERRM);
                                          p_err_code   := 'ST-UPLD-001';
                                          p_err_params := '@DETB_TC_DETAIL_EXTGBL';
                                          RETURN FALSE;
                              END;
                        END LOOP;
                  END IF;
            
            ELSIF p_action_code = cspks_req_global.p_delete 
            THEN
                  dbg('Action Code ' || p_action_code);
                  dbg('Deleting The Data..');
            
                  DELETE detbs_tc_detail_extgbl
                  WHERE  contract_ref_no = p_wrk_dedtlron.v_detbs_teller_master.reference_no;
            
                  DELETE detbs_teller_master_extgbl
                  WHERE  reference_no = p_wrk_dedtlron.v_detbs_teller_master.reference_no
                  --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 STARTS
                  AND    evnt_seq_no = p_wrk_dedtlron.v_detbs_teller_master.evnt_seq_no;
                  --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 ENDS
                  
                  DELETE detbs_tc_tracers_extgbl
                  WHERE  contract_ref_no = p_wrk_dedtlron.v_detbs_teller_master.reference_no;
                  
                  --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes for updating iftbs_otat_details_extgbl status on Del
                  dbg('Action Code ' || p_action_code);
            
                  BEGIN
                        SELECT otat_tkt_ref, status
                        INTO   l_ot_at_tk_ref, l_otat_status
                        FROM   iftbs_otat_details_extgbl
                        WHERE  external_ref_no = p_wrk_dedtlron.v_detbs_teller_master.reference_no
                        AND    status <> 'D';
                  EXCEPTION
                        WHEN no_data_found THEN
                              DEBUG.pr_debug('IF', 'Record not found in iftbs_otat_details_extgbl');
                              l_ot_at_tk_ref := NULL;
                              l_otat_status  := NULL;
                        WHEN OTHERS THEN
                              dbg('In WOT..' || SQLERRM);
                              l_otat_status  := NULL;
                              l_ot_at_tk_ref := NULL;
                  END;
            
                  IF l_otat_status = 'P' 
                  THEN
                        --FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag14 Code Review Changes start
                        /*IF NOT ifpks_otat_gen_extgbl.fn_ot_appr_reject
                                    (
                                    l_ot_at_tk_ref
                                    ,l_action_code
                                    ,l_rej_code
                                    ,p_err_params
                                    ,l_auth_id
                                    ,l_called_from
                                    ,p_err_code
                                    ,p_err_params
                                    )
                        THEN
                          dbg('Failed while updating the OT tickets '||l_ot_at_tk_ref||'~'||p_wrk_dedtlron.v_detbs_teller_master.reference_no);
                          p_err_code := 'IFACPOST064';
                          p_err_params := SQLERRM;
                              Ovpkss.Pr_Appendtbl(p_err_code, p_err_params);
                          RETURN FALSE;
                        END IF;*/
                        IF NOT ifpks_eca_extgbl.fn_ot_appr_reject(l_ot_at_tk_ref,
                                                                  l_action_code,
                                                                  l_rej_code,
                                                                  p_err_params,
                                                                  l_auth_id,
                                                                  l_called_from,
                                                                  p_err_code,
                                                                  p_err_params) 
                        THEN
                              dbg('Failed while updating the OT tickets ' || l_ot_at_tk_ref || '~' ||
                                  p_wrk_dedtlron.v_detbs_teller_master.reference_no);
                              p_err_code   := 'IFACPOST064';
                              p_err_params := SQLERRM;
                              Ovpkss.Pr_Appendtbl(p_err_code, p_err_params);
                              RETURN FALSE;
                        END IF;
                        --FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag14 Code Review Changes end
                  END IF;
                  ---FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends           
            END IF;
      
            IF nvl(l_prod_master_extgbl.tc_product, 'N') = 'Y' 
            THEN
                  SELECT SUM(check_amount)
                  INTO   l_check_amount
                  FROM   detbs_tc_detail_extgbl
                  WHERE  contract_ref_no = p_wrk_dedtlron.v_detbs_teller_master.reference_no;
            
                  dbg(' DE cl check amount -->' || l_check_amount);
            
                  IF nvl(l_check_amount, 0) <> p_wrk_dedtlron.v_detbs_teller_master.txn_amount 
                  THEN
                        dbg('Transaction amount and Total cheque amount should be equal');
                        p_err_code   := 'ST-ATC-001';
                        p_err_params := NULL;
                        RETURN FALSE;
                  END IF;
            END IF;
      
            dbg('Start calling for reversal p_Action_Code' || p_action_code);
            dbg('Start calling for reversalCspks_Req_Global.p_reverse' || cspks_req_global.p_reverse);
      
            IF p_action_code = cspks_req_global.p_reverse 
            THEN
                  dbg(' i am going populate advice');
                  IF NOT depks_cashletter_extgbl.fn_populate_advice(p_wrk_dedtlron.v_detbs_teller_master.product_code,
                                                                    p_wrk_dedtlron.v_detbs_teller_master.evnt_seq_no + 1,
                                                                    p_wrk_dedtlron.v_detbs_teller_master.reference_no,
                                                                    'REVR') 
                  THEN
                        dbg('failed in depkss_teller.fn_populate_advice');
                        RETURN FALSE;
                  END IF;
            
            END IF;
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 Ends
      
            --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 - review changes starts
            IF p_action_code = cspks_req_global.p_delete AND
               p_wrk_dedtlron.v_detbs_teller_master.instrument_no IS NOT NULL 
            THEN
                  SELECT count(*)
                  INTO   l_count
                  FROM   catbs_check_util_extgbl a
                  WHERE  a.branch = p_wrk_dedtlron.v_detbs_teller_master.txn_branch
                  AND    a.account = p_wrk_dedtlron.v_detbs_teller_master.txn_account
                  AND    a.check_no = p_wrk_dedtlron.v_detbs_teller_master.instrument_no
                  AND    nvl(a.auth_stat, 'U') = 'U'
                  AND    nvl(a.once_auth, 'N') = 'N';
                  Dbg('l_count: ' || l_count);
            
                  IF l_count > 0 
                  THEN
                        Dbg('Deleting original claim amount');
                  
                        DELETE catbs_check_util_extgbl a
                        WHERE  a.branch = p_wrk_dedtlron.v_detbs_teller_master.txn_branch
                        AND    a.account = p_wrk_dedtlron.v_detbs_teller_master.txn_account
                        AND    a.check_no = p_wrk_dedtlron.v_detbs_teller_master.instrument_no;
                  END IF;
            END IF;
            --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 - review changes ends
      
            dbg('Returning Success From Fn_Post_Upload_Db..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**', 'In When Others of depks_dedtlron_Custom.Fn_Post_Upload_Db ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_upload_db;

      FUNCTION fn_pre_process(p_source           IN VARCHAR2,
                              p_source_operation IN VARCHAR2,
                              p_function_id      IN VARCHAR2,
                              p_action_code      IN VARCHAR2,
                              p_child_function   IN VARCHAR2,
                              p_multi_trip_id    IN VARCHAR2,
                              p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                              p_prev_dedtlron    IN depks_dedtlron_main.ty_dedtlron,
                              p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                              p_err_code         IN OUT VARCHAR2,
                              p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
      BEGIN
            dbg('In Fn_Pre_Process..');
            --FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#116 CashLetter Processing  changes starts
            dbg('Cash letter product pref~' || p_wrk_dedtlron.v_detb_teller_master_extgbl.tc_product || '~');
      
            IF nvl(p_wrk_dedtlron.v_detb_teller_master_extgbl.tc_product, 'N') = 'Y' 
            THEN
                  IF depks_dedtlron_main.fn_get_original_action IN ('REVERSE') 
                  THEN
                        DBG('Skip Kernel Reverse');
                        depks_dedtlron_main.pr_set_skip_kernel;
                  END IF;
            ENd IF;
            --FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#116 CashLetter Processing  changes ends
      
            dbg('Returning Success From Fn_Pre_Process..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**', 'In When Others of depks_dedtlron_Custom.Fn_Pre_Process ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_process;
      --FS_FCUBS12.0.0.1CitiDDA_Vol4 Tag7 starts
      FUNCTION fn_addition_information(p_brn        VARCHAR2,
                                       p_cust_ac_no VARCHAR2,
                                       p_customer   VARCHAR2,
                                       p_err        IN OUT VARCHAR2,
                                       p_param      IN OUT VARCHAR2)
            RETURN BOOLEAN IS
            l_avl_bal          sttms_cust_account.acy_avl_bal%TYPE;
            l_mis_1            gltms_mis_code.mis_code%TYPE;
            l_sweep_account    sttms_cust_account.cust_ac_no%TYPE;
            l_ccy              cytms_ccy_defn.ccy_code%TYPE;
            pkg_acc_status     VARCHAR2(1000);
            l_acc_cust_acct    sttbs_account%ROWTYPE;
            l_acc_officer_code sttm_customer_extgbl.account_officer_code%TYPE;
            l_si_exists        CHAR(1);
      BEGIN
            dbg('In fn_addition_information..');
            FOR c1 IN (SELECT contract_ref_no,
                              dr_account,
                              cr_account,
                              dr_acc_ccy,
                              cr_acc_ccy
                       FROM   sitb_contract_master a, sitbs_instruction b
                       WHERE  a.instruction_no = b.instruction_no
                       AND    version_no = latest_version_no
                       AND    ((dr_acc_br = p_brn AND dr_account = p_cust_ac_no) OR
                              (cr_acc_br = p_brn AND cr_account = p_cust_ac_no))) 
            LOOP
                  l_si_exists := 'Y';
                  IF p_cust_ac_no = c1.cr_account 
                  THEN
                        l_sweep_account := nvl(c1.dr_account, 'NULL');
                        l_ccy           := c1.dr_acc_ccy;
                        IF NOT acpkss_misc.fn_getavlbal(p_brn,
                                                        c1.dr_account,
                                                        l_avl_bal) 
                        THEN
                              RETURN FALSE;
                        END IF;
                  ELSE
                        l_sweep_account := nvl(c1.cr_account, 'NULL');
                        l_ccy           := c1.cr_acc_ccy;
                        IF NOT acpkss_misc.fn_getavlbal(p_brn,
                                                        c1.cr_account,
                                                        l_avl_bal) 
                        THEN
                              RETURN FALSE;
                        END IF;
                  END IF;
            END LOOP;
            -------------------------------------------------------------------------------
      
            dbg('p_customer..' || p_customer);
            pkg_acc_status := NULL;
            dbg('SI exists' || l_si_exists);
            ----------------------------------------------------------------
            BEGIN
                  SELECT account_officer_code
                  INTO   l_acc_officer_code
                  FROM   sttm_customer_extgbl
                  WHERE  customer_no = p_customer;
                  dbg('Account officer code' || l_acc_officer_code);
            EXCEPTION
                  WHEN no_data_found THEN
                        l_acc_officer_code := 'NULL';
            END;
      
            ---------------------------------------------------------------------------
            IF NOT cvpks_utils.get_sttb_acc(p_brn,
                                            p_cust_ac_no,
                                            l_acc_cust_acct) 
            THEN
                  dbg('Failed to get account record');
                  RETURN FALSE;
            END IF;
      
            IF l_acc_cust_acct.ac_stat_no_cr = 'Y' 
            THEN
                  pkg_acc_status := 'No Credit Allowed ';
            END IF;
            IF l_acc_cust_acct.ac_stat_no_dr = 'Y' 
            THEN
                  pkg_acc_status := pkg_acc_status || 'No Debit Allowed';
            END IF;
            IF l_acc_cust_acct.ac_stat_frozen = 'Y' 
            THEN
                  pkg_acc_status := pkg_acc_status || 'Frozen';
            END IF;
            IF l_acc_cust_acct.ac_stat_dormant = 'Y' 
            THEN
                  pkg_acc_status := pkg_acc_status || 'Dormant';
            END IF;
      
            debug.pr_debug('AC', 'l_Acc_cust_acct.AC_STAT_STOP_PAY : ' ||
                           l_acc_cust_acct.ac_stat_stop_pay);
            IF l_acc_cust_acct.ac_stat_stop_pay = 'Y' 
            THEN
                  pkg_acc_status := pkg_acc_status || 'Stop Payment';
            END IF;
            IF pkg_acc_status IS NULL 
            THEN
                  pkg_acc_status := pkg_acc_status || 'Normal';
            END IF;
      
            debug.pr_debug('AC', 'pkg_acc_status : ' || pkg_acc_status);
            debug.pr_debug('AC', 'l_sweep_account..' || l_sweep_account);
            debug.pr_debug('AC', 'l_avl_bal..' || l_avl_bal);
      
            p_err   := p_err || 'AC-OVD020;';
            p_param := p_param || l_acc_officer_code || '~' ||
                       l_sweep_account || '~' ||
                       ltrim(rtrim((csfns_format_amt(l_ccy, l_avl_bal)))) || '~' ||
                       pkg_acc_status || '~';
      
            debug.pr_debug('AC','p_param in fn_addition_information..' || p_param);
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**', 'In When Others of depks_dedtlron_Custom.fn_addition_information ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err   := 'ST-OTHR-001';
                  p_param := NULL;
                  RETURN FALSE;
      END fn_addition_information;
      --FS_FCUBS12.0.0.1CitiDDA_Vol4 Tag7 ends

      FUNCTION fn_post_process(p_source           IN VARCHAR2,
                               p_source_operation IN VARCHAR2,
                               p_function_id      IN VARCHAR2,
                               p_action_code      IN VARCHAR2,
                               p_child_function   IN VARCHAR2,
                               p_multi_trip_id    IN VARCHAR2,
                               p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                               p_prev_dedtlron    IN depks_dedtlron_main.ty_dedtlron,
                               p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                               p_err_code         IN OUT VARCHAR2,
                               p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
      
            --FS_FCUBS12.0.0.1CitiDDA_Vol4 Tag7 starts
            l_ovd_exists     VARCHAR2(1);
            l_errparams      VARCHAR2(2000) := NULL;
            l_ovd_params     VARCHAR2(255) := NULL;
            l_custom_ovd_msg sttm_branch_extgbl.custom_ovd_message%TYPE;
            --FS_FCUBS12.0.0.1CitiDDA_Vol4 Tag7 ends
      
            --FCUBS12.0.1.7.0 CITI Vol4 Tag20 IUT3 SFR#292 starts
            l_internal_remarks actbs_recon_details_extgbl.internal_remarks%TYPE;
            l_external_remarks actbs_recon_details_extgbl.internal_remarks%TYPE;
            --FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#19 CashLetter Processing  changes starts
            l_auto_auth_allowed varchar2(1);
            l_authflag          char;
            --FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#19 CashLetter Processing  changes ends
            
            l_account_class sttm_cust_account.account_class%type;    -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes
      
            CURSOR v_recon_master IS
                  SELECT *
                  FROM   actbs_recon_master
                  WHERE  branch = p_wrk_dedtlron.v_detbs_teller_master.branch_code
                  AND    ref_no = p_wrk_dedtlron.v_detbs_teller_master.reference_no;
                  
            CURSOR v_recon_details(p_branch  VARCHAR2,
                                   p_account VARCHAR2,
                                   p_ccy     VARCHAR2,
                                   p_reconno VARCHAR2,
                                   p_refno   VARCHAR2) IS
                  SELECT *
                  FROM   actbs_recon_details
                  WHERE  branch = p_branch
                  AND    account = p_account
                  AND    ccy = p_ccy
                  AND    reconno = p_reconno
                  AND    ref_no = p_refno;
            --FCUBS12.0.1.7.0 CITI Vol4 Tag20 IUT3 SFR#292 ends
      
      BEGIN
            dbg('In Fn_Post_Process..');
            --FCUBS CITI Release 12.0.0.1.0 FS Vol6 Tag3 - Instructions processing Changes Starts
            IF p_action_code IN (cspks_req_global.p_new,
                                 cspks_req_global.p_delete,
                                 cspks_req_global.p_copy,
                                 cspks_req_global.p_liquidate,
                                 cspks_req_global.p_reverse) AND
               nvl(p_dedtlron.v_detb_teller_master_extgbl.float_product,'N') = 'Y' 
            THEN
                  IF pkg_rec_offset_det.offset_ilv = 'Y' AND
                     pkg_rec_offset_det.offset_account IS NOT NULL AND
                     nvl(p_wrk_dedtlron.v_detb_teller_master_extgbl.float_product, 'N') = 'Y' 
                  THEN
                        UPDATE detbs_teller_master dem
                        SET    offset_ccy = pkg_rec_offset_det.offset_ccy,
                               offset_amount = pkg_rec_offset_det.offset_amount,
                               offset_account = pkg_rec_offset_det.offset_account,
                               offset_account_branch = pkg_rec_offset_det.offset_account_branch
                        WHERE  reference_no = p_wrk_dedtlron.v_detbs_teller_master.reference_no
                        AND    evnt_seq_no = p_wrk_dedtlron.v_detbs_teller_master.evnt_seq_no;
                  END IF;
            END IF;
      
            pkg_rec_offset_det.offset_ilv := 'N';
            --FCUBS CITI Release 12.0.0.1.0 FS Vol6 Tag3 - Instructions processing Changes Ends
      
            --FS_FCUBS12.0.0.1CitiDDA_Vol4 Tag7 starts
            BEGIN
                  SELECT PARAMETERS
                  INTO   l_ovd_params
                  FROM   cstb_contract_ovd
                  WHERE  err_code = 'AC-OVD02'
                  AND    contract_ref_no = p_wrk_dedtlron.v_detbs_teller_master.reference_no;
                  l_ovd_exists := 'Y';
                  p_err_params := l_ovd_params;
            EXCEPTION
                  WHEN no_data_found THEN
                        l_ovd_exists := 'N';
            END;
            dbg('Ovd doesnt Exist' || l_ovd_exists);
      
            BEGIN
                  SELECT nvl(custom_ovd_message, 'N')
                  INTO   l_custom_ovd_msg
                  FROM   sttm_branch_extgbl
                  WHERE  branch_code = global.current_branch;
            
                  dbg('l_custom_ovd_msg@@' || l_custom_ovd_msg);
            EXCEPTION
                  WHEN OTHERS THEN
                        l_custom_ovd_msg := 'N';
            END;
            dbg('custom_ovd_msg##' || l_custom_ovd_msg);
      
            IF l_ovd_exists = 'Y' AND l_custom_ovd_msg = 'Y' 
            THEN
                  IF p_action_code IN ('NEW', 'MODIFY') 
                  THEN
                        IF (p_wrk_dedtlron.v_detbs_teller_master.txn_drcr = 'D' AND
                           p_wrk_dedtlron.v_detbs_teller_master.txn_amount > 0) OR
                           (p_wrk_dedtlron.v_detbs_teller_master.txn_drcr <> 'C' AND
                           p_wrk_dedtlron.v_detbs_teller_master.txn_amount < 0) 
                        THEN
                              IF NOT fn_addition_information(p_wrk_dedtlron.v_detbs_teller_master.txn_branch,
                                                             p_wrk_dedtlron.v_detbs_teller_master.txn_account,
                                                             p_wrk_dedtlron.v_detbs_teller_master.rel_customer,
                                                             p_err_code,
                                                             p_err_params) 
                              THEN
                                    dbg('failed in fn_addition_information..');
                                    RETURN FALSE;
                              END IF;
                        END IF;
                        IF (p_wrk_dedtlron.v_detbs_teller_master.txn_drcr <> 'D' AND
                           p_wrk_dedtlron.v_detbs_teller_master.offset_amount > 0) OR
                           (p_wrk_dedtlron.v_detbs_teller_master.txn_drcr = 'D' AND
                           p_wrk_dedtlron.v_detbs_teller_master.offset_amount < 0) 
                        THEN
                              IF NOT fn_addition_information(p_wrk_dedtlron.v_detbs_teller_master.offset_account_branch,
                                                             p_wrk_dedtlron.v_detbs_teller_master.offset_account,
                                                             p_wrk_dedtlron.v_detbs_teller_master.rel_customer,
                                                             p_err_code,
                                                             p_err_params) 
                              THEN
                                    dbg('failed in fn_addition_information..');
                                    RETURN FALSE;
                              END IF;
                        END IF;
                        dbg('p_err_params fn_addition_information..' || p_err_params);
                        pr_log_error(p_function_id,
                                     p_source,
                                     p_err_code,
                                     p_err_params);
                  END IF;
            END IF;
            --FS_FCUBS12.0.0.1CitiDDA_Vol4 Tag7 ends
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 Starts
      
            dbg('Action code -->' || p_action_code);
      
            IF p_action_code = 'LIQUIDATE' 
            THEN
                  dbg('Start processing liquidation');
                  dbg('Cash letter product pref~' || p_wrk_dedtlron.v_detb_teller_master_extgbl.tc_product || '~');
            
                  IF nvl(p_wrk_dedtlron.v_detb_teller_master_extgbl.tc_product, 'N') = 'Y' 
                  THEN
                        IF NOT depkss_cashletter_extgbl.fn_tc_liqd(p_wrk_dedtlron.v_detbs_teller_master.reference_no,
                                                                   --  p_wrk_dedtlron.v_detbs_teller_master.value_date,    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#278
                                                                   to_date(global.application_date), --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#278
                                                                   p_wrk_dedtlron.v_detbs_teller_master.txn_amount,
                                                                   global.lcy,
                                                                   --p_wrk_dedtlron.v_detbs_teller_master.maker_id, -- FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#19 CashLetter Processing  changes 
                                                                   global.user_ID,
                                                                   'O',
                                                                   p_err_code,
                                                                   p_err_params) 
                        THEN
                              dbg('Returned false from depkss_cashletter_extgbl.fn_tc_liqd_rejt~' || p_err_code || '~' || SQLERRM);
                              IF p_err_code IS NOT NULL 
                              THEN
                                    ovpkss.pr_appendtbl(p_err_code, p_err_params);
                              END IF;
                              dbg('Returning false from the function depks_dedtlron_utils_custom fn_process..' || SQLERRM);
                              RETURN FALSE;
                        END IF;
                        ovpks.gl_tblerror.DELETE;
                        RETURN TRUE;
                  END IF;
                  --FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#19 CashLetter Processing  changes starts
            ELSIF p_action_code = 'REVERSE' 
            THEN
                  dbg('p_action_code  ' || p_action_code);
                  dbg('Start processing liquidation');
                  dbg('Cash letter product pref~' || p_wrk_dedtlron.v_detb_teller_master_extgbl.tc_product || '~');
            
                  IF nvl(p_wrk_dedtlron.v_detb_teller_master_extgbl.tc_product, 'N') = 'Y' 
                  THEN
                        IF NOT smpkss.fn_check_auto_auth(GLOBAL.USER_ID,
                                                         'dedtlron',
                                                         global.current_branch) 
                        THEN
                              l_auto_auth_allowed := 'N';
                              l_authflag          := 'N';
                              dbg('AUTO AUTH IS NOT ALLOWED');
                        ELSE
                              dbg('AUTO AUTH IS ALLOWED');
                              l_authflag          := 'A';
                              l_auto_auth_allowed := 'Y';
                        END IF;
                  
                        IF l_auto_auth_allowed = 'Y' 
                        THEN
                              dbg('ITS GOING TO AUTO AUTHORISE NOW');
                        END IF;
                  
                        IF NOT depkss_dedtlron_utils.fn_getbranchcond(p_wrk_dedtlron,
                                                                      p_err_code,
                                                                      p_err_params) 
                        THEN
                              return false;
                        END IF;
                  
                        IF NOT depkss_cashletter_extgbl.fn_teller_reverse(p_wrk_dedtlron.v_detbs_teller_master.reference_no,
                                                                          global.user_ID,
                                                                          p_dedtlron.v_devws_batch_master.BATCH_NO,
                                                                          P_WRK_dedtlron.v_detbs_teller_master.curr_no,
                                                                          to_date(global.application_date),
                                                                          global.lcy,
                                                                          l_authflag,
                                                                          'M',
                                                                          p_wrk_dedtlron.v_vw_parameters.prm_denotrack_reqd,
                                                                          p_err_code,
                                                                          p_err_params) 
                        THEN
                              dbg('Failed in depkss_cashletter_extgbl.fn_teller_reverse  ' || p_err_code || '~' || SQLERRM);
                              IF p_err_code IS NOT NULL 
                              THEN
                                    ovpkss.pr_appendtbl(p_err_code, p_err_params);
                              END IF;
                              dbg('Returning false from the function depks_dedtlron_utils_custom fn_process..' || SQLERRM);
                              RETURN FALSE;
                        END IF;
                  END IF;
                  --FCUBS12.0.1.7.0 CITI Vol4 Tag8 ITR2 SFR#19 CashLetter Processing  changes ends    
                  dbg('after entry  before auth  ' || p_err_code || '~' || p_err_params);
            ELSIF p_action_code = 'PRELIQ' 
            THEN
                  dbg('No need to do the liquidation for this action code');
                  RETURN TRUE;
            END IF;
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 Ends
            --FCUBS CITI Release FS_FCUBS12.0.0.1CitiDDA_Vol5 Threshold for cash in - cash out for automatic authorization  - #2441: starts
            IF p_action_code IN (cspks_req_global.p_new, cspks_req_global.p_copy) 
            THEN
                  dbg('Calling Fn_Threshold');
                  IF NOT fn_threshold(p_source,
                                      p_wrk_dedtlron.v_detbs_teller_master.product_code,
                                      p_source_operation,
                                      'DEDTLRON',
                                      p_action_code,
                                      p_wrk_dedtlron,
                                      p_err_code,
                                      p_err_params) 
                  THEN
                        dbg('Failed in Fn_Threshold');
                        RETURN FALSE;
                  END IF;
            END IF;
            --FCUBS CITI Release FS_FCUBS12.0.0.1CitiDDA_Vol5 Threshold for cash in - cash out for automatic authorization  - #2441: ends
      
            --FCUBS12.0.1.7.0 CITI Vol4 Tag20 IUT3 SFR#292 starts
            IF p_action_code = cspks_req_global.p_new 
            THEN
                  dbg('recon entry started');
            
                  FOR i IN v_recon_master 
                  LOOP
                        IF i.ref_no = p_wrk_dedtlron.v_detbs_teller_master.reference_no AND
                           i.branch = p_wrk_dedtlron.v_detbs_teller_master.branch_code AND
                           i.account = p_wrk_dedtlron.v_detbs_teller_master.txn_account AND
                           i.ccy = p_wrk_dedtlron.v_detbs_teller_master.offset_ccy 
                        THEN
                              IF p_wrk_dedtlron.v_detbs_teller_master.reference_no = p_wrk_dedtlron.v_detb_teller_master_extgbl.reference_no AND
                                 p_wrk_dedtlron.v_detbs_teller_master.evnt_seq_no = p_wrk_dedtlron.v_detb_teller_master_extgbl.evnt_seq_no 
                              THEN
                                    l_internal_remarks := p_wrk_dedtlron.v_detb_teller_master_extgbl.internal_remarks;
                                    l_external_remarks := p_wrk_dedtlron.v_detb_teller_master_extgbl.external_remarks;
                              END IF;
                        
                              ----FCUBS12.0.1.7.0 CITI Vol4 Tag20 IUT3 SFR#105 starts
                              dbg('recon no ' || i.reconno || '~' ||
                                  i.branch || '~' || i.account || '~' ||
                                  i.ccy || '~' || l_internal_remarks || '~' ||
                                  l_external_remarks);
                              IF i.reconno IS NOT NULL 
                              THEN
                                    begin
                                          --FCUBS12.0.1.7.0 CITI Vol4 Tag20 IUT3 SFR#105 end
                                          INSERT INTO actbs_recon_master_extgbl
                                                (branch,
                                                 account,
                                                 reconno,
                                                 ccy,
                                                 internal_remarks,
                                                 external_remarks)
                                          VALUES
                                                (i.branch,
                                                 i.account,
                                                 i.reconno,
                                                 i.ccy,
                                                 l_internal_remarks,
                                                 l_external_remarks);
                                    
                                          --FCUBS12.0.1.7.0 CITI Vol4 Tag20 IUT3 SFR#105 starts   
                                    exception
                                          when others then
                                                dbg('error during insert ' || sqlerrm);
                                    end;
                              END IF; --FCUBS12.0.1.7.0 CITI Vol4 Tag20 IUT3 SFR#105 ends
                        END IF;
                  END LOOP;
            
                  FOR i IN v_recon_master 
                  LOOP
                        FOR j IN v_recon_details(i.branch,
                                                 i.account,
                                                 i.ccy,
                                                 i.reconno,
                                                 i.ref_no) 
                        LOOP
                              IF j.ref_no = p_wrk_dedtlron.v_detb_teller_master_extgbl.reference_no AND
                                 j.event_seq_no = p_wrk_dedtlron.v_detb_teller_master_extgbl.evnt_seq_no 
                              THEN
                                    l_internal_remarks := p_wrk_dedtlron.v_detb_teller_master_extgbl.internal_remarks;
                                    l_external_remarks := p_wrk_dedtlron.v_detb_teller_master_extgbl.external_remarks;
                              END IF;
                        
                              IF j.reconno IS NOT NULL 
                              THEN
                                    --FCUBS12.0.1.7.0 CITI Vol4 Tag20 IUT3 SFR#105
                                    begin
                                          INSERT INTO actb_recon_details_extgbl
                                                (branch,
                                                 account,
                                                 ccy,
                                                 serno,
                                                 reconno,
                                                 ref_no,
                                                 event_seq_no,
                                                 amount,
                                                 external_remarks,
                                                 internal_remarks)
                                          VALUES
                                                (j.branch,
                                                 j.account,
                                                 j.ccy,
                                                 j.serno,
                                                 j.reconno,
                                                 j.ref_no,
                                                 j.event_seq_no,
                                                 j.amount,
                                                 l_external_remarks,
                                                 l_internal_remarks);
                                          --FCUBS12.0.1.7.0 CITI Vol4 Tag20 IUT3 SFR#105 starts   
                                    exception
                                          when others then
                                                dbg('error during insert ' ||
                                                    sqlerrm);
                                    end;
                              END IF; --FCUBS12.0.1.7.0 CITI Vol4 Tag20 IUT3 SFR#105 ends
                        END LOOP;
                  END LOOP;
            END IF;
            --FCUBS12.0.1.7.0 CITI Vol4 Tag20 IUT3 SFR#292 ends
    -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Starts
      BEGIN
        DBG('p_dedtlron.v_detbs_teller_master(indx).txn_account : ' || p_dedtlron.v_detbs_teller_master
            .txn_account);
        select account_Class
          into l_account_class
          from sttm_cust_Account a
         where cust_Ac_no = p_dedtlron.v_detbs_teller_master
              .txn_account
              and a.branch_code = p_dedtlron.v_detbs_teller_master.txn_branch
              and record_stat = 'O' and auth_stat = 'A'
	      and exists (select 1 from sttb_account b where ac_or_gl = 'A' and b.ac_gl_no = a.cust_ac_no);
        dbg('Account Class : ' || l_account_Class);
      IF instr(cvpks_utils_extgbl.fn_get_param_value('GWPAGEE_ACCCLASS_LST'),
               l_Account_class) > 0 AND p_dedtlron.v_detbs_teller_master.txn_drcr = 'D' THEN
	insert into DETBS_RESERVE_DTL_EXTGBL
	  (SYSTEM_ID,
	   DATETIMESTAMP,
	   MSG_REG,
	   MSG_TYPE,
	   ACCOUNT,
	   REFERENCE_NO,
	   VALUE_DT,
	   AMOUNT,
	   RESPONSE)
        values
          ('102',
           to_char(sysdate,'YYYYMMDDHHMISS'),
           '0',
           'INT1002',
           p_dedtlron.v_detbs_teller_master.txn_account,
           p_dedtlron.v_detbs_teller_master.reference_no,
           to_char(p_dedtlron.v_detbs_teller_master.value_date,'YYYYMMDDHHMISS'),
           p_dedtlron.v_detbs_teller_master.txn_amount,
           null);
        dbg('Inserted to DE ECA Table ');
        commit;   

      END IF;        
      EXCEPTION
        WHEN Others THEn
          dbg('Account Class Not Found ' || sqlerrm);
      END;
    

    
    -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Ends
      
            dbg('Returning Success From Fn_Post_Process..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedtlron_Custom.Fn_Post_Process ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_process;

      FUNCTION fn_pre_query(p_source           IN VARCHAR2,
                            p_source_operation IN VARCHAR2,
                            p_function_id      IN VARCHAR2,
                            p_action_code      IN VARCHAR2,
                            p_child_function   IN VARCHAR2,
                            p_full_data        IN VARCHAR2 DEFAULT 'Y',
                            p_with_lock        IN VARCHAR2 DEFAULT 'N',
                            p_qrydata_reqd     IN VARCHAR2,
                            p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                            p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                            p_err_code         IN OUT VARCHAR2,
                            p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
      BEGIN
            dbg('In Fn_Pre_Query..');
      
            dbg('Returning Success From Fn_Pre_Query..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedtlron_Custom.Fn_Pre_Query ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_query;

      FUNCTION fn_post_query(p_source           IN VARCHAR2,
                             p_source_operation IN VARCHAR2,
                             p_function_id      IN VARCHAR2,
                             p_action_code      IN VARCHAR2,
                             p_child_function   IN VARCHAR2,
                             p_full_data        IN VARCHAR2 DEFAULT 'Y',
                             p_with_lock        IN VARCHAR2 DEFAULT 'N',
                             p_qrydata_reqd     IN VARCHAR2,
                             p_dedtlron         IN depks_dedtlron_main.ty_dedtlron,
                             p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                             p_err_code         IN OUT VARCHAR2,
                             p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 STARTS
            CURSOR c_v_acvws_all_ac_entries IS
                  SELECT *
                  FROM   acvw_all_ac_entries
                  WHERE  trn_ref_no = p_wrk_dedtlron.v_detbs_teller_master.reference_no;
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 ENDS
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 STARTS
            CURSOR c_v_tell_extgbl IS
                  SELECT *
                  FROM   detbs_teller_master_extgbl
                  WHERE  reference_no = p_wrk_dedtlron.v_detbs_teller_master.reference_no;
      
            c2 c_v_tell_extgbl%ROWTYPE;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 ENDS
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#343 starts
            CURSOR c_v_detb_tc_detail_extgbl IS
                  SELECT *
                  FROM   detb_tc_detail_extgbl
                  WHERE  contract_ref_no = p_wrk_dedtlron.v_detbs_teller_master.reference_no;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#343 ends
      
            l_amount    detbs_teller_master.txn_amount%TYPE; --FCUBS12.0.1.7.0 CITI Vol6 Tag3 ITR SFR#412 Float Account processing Changes
            l_claim_amt Number; --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 Changes
      BEGIN
      
            dbg('In Fn_Post_Query');
            dbg('Nostro acc' || p_wrk_dedtlron.v_detb_teller_master_extgbl.nostro_acct);
            dbg('Nostro acc' || p_dedtlron.v_detb_teller_master_extgbl.nostro_acct);
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 STARTS
            IF nvl(p_with_lock, 'N') = 'N' 
            THEN
                  IF p_action_code NOT IN (cspks_service.p_copy,
                                           'PRD_DFLT',
                                           'SIG_DFLT',
                                           'DEFAULT_DENOM_T',
                                           'DEFAULT_DENOM_O',
                                           'AMT_COMP') -- FCUBS_11.3.0_P01_FCUBS_11.2_IMP_47 - Added AMT_COMP
                  THEN
                        dbg('Get the Record For :CSTBS_CONTRACT_EVENT_ADVICE');
                  
                        dbg('Get the Record For :ACVWS_ALL_AC_ENTRIES');
                  
                        p_wrk_dedtlron.v_acvws_all_ac_entries.DELETE;
                  
                        OPEN c_v_acvws_all_ac_entries;
                        LOOP
                        
                              FETCH c_v_acvws_all_ac_entries BULK COLLECT
                                    INTO p_wrk_dedtlron.v_acvws_all_ac_entries;
                        
                              EXIT WHEN c_v_acvws_all_ac_entries%NOTFOUND;
                        
                        END LOOP;
                  
                        CLOSE c_v_acvws_all_ac_entries;
                  END IF;
            END IF;
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 ENDS
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#278 starts
            IF p_action_code NOT IN (cspks_service.p_copy,
                                     'PRD_DFLT',
                                     'SIG_DFLT',
                                     'DEFAULT_DENOM_T',
                                     'DEFAULT_DENOM_O',
                                     'AMT_COMP') 
            THEN
                  --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 STARTS
                  OPEN c_v_tell_extgbl;
                  LOOP
                        FETCH c_v_tell_extgbl
                              INTO c2;
                        p_wrk_dedtlron.v_detb_teller_master_extgbl := c2;
                        EXIT WHEN c_v_tell_extgbl%NOTFOUND;
                  END LOOP;
                  CLOSE c_v_tell_extgbl;
                  --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 ENDS
                  --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#343 starts
                  OPEN c_v_detb_tc_detail_extgbl;
                  LOOP
                        FETCH c_v_detb_tc_detail_extgbl BULK COLLECT
                              INTO p_wrk_dedtlron.v_detb_tc_detail_extgbl;
                        EXIT WHEN c_v_detb_tc_detail_extgbl%NOTFOUND;
                  END LOOP;
                  CLOSE c_v_detb_tc_detail_extgbl;
            
                  --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#343 ends
            END IF;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag8 CashLetter Processing ITR SFR#278 ends
      
            --FCUBS12.0.1.7.0 CITI Vol6 Tag3 ITR SFR#412 Float Account processing Changes Starts
            IF nvl(p_wrk_dedtlron.v_detb_teller_master_extgbl.float_product,'N') = 'Y' 
            THEN
                  dbg('Inside amount rounding for float transfer out products');
                  dbg('txn_amount~' || p_wrk_dedtlron.v_detbs_teller_master.txn_amount);
                  dbg('txn_short_ovg_amount~' || p_wrk_dedtlron.v_detbs_teller_master.txn_short_ovg_amount);
                  dbg('offset_amount~' || p_wrk_dedtlron.v_detbs_teller_master.offset_amount);
                  dbg('offset_short_ovg_amount~' || p_wrk_dedtlron.v_detbs_teller_master.offset_short_ovg_amount);
                  dbg('lcy_amount~' || p_wrk_dedtlron.v_detbs_teller_master.lcy_amount);
                  dbg('charge_base_amt~' || p_wrk_dedtlron.v_detbs_teller_master.charge_base_amt);
                  dbg('net_amount~' || p_wrk_dedtlron.v_detbs_teller_master.net_amount);
                  dbg('total_tax~' || p_wrk_dedtlron.v_detbs_teller_master.total_tax);
                  dbg('total_charges~' || p_wrk_dedtlron.v_detbs_teller_master.total_charges);
                  dbg('ofs_user_amt~' || p_wrk_dedtlron.v_detbs_teller_master.ofs_user_amt);
                  dbg('ofs_disp_amt~' || p_wrk_dedtlron.v_detbs_teller_master.ofs_disp_amt);
                  IF nvl(p_wrk_dedtlron.v_detbs_teller_master.txn_amount, 0) <> 0 
                  THEN
                        IF NOT cypkss.fn_amt_round(p_wrk_dedtlron.v_detbs_teller_master.txn_ccy,
                                                   p_wrk_dedtlron.v_detbs_teller_master.txn_amount,
                                                   l_amount) 
                        THEN
                              dbg('Rounding failed for txn_amount');
                        ELSE
                              dbg('txn_amount after rounding~' || l_amount);
                              p_wrk_dedtlron.v_detbs_teller_master.txn_amount := l_amount;
                        END IF;
                  END IF;
            
                  IF nvl(p_wrk_dedtlron.v_detbs_teller_master.txn_short_ovg_amount,0) <> 0 
                  THEN
                        IF NOT cypkss.fn_amt_round(p_wrk_dedtlron.v_detbs_teller_master.txn_ccy,
                                                   p_wrk_dedtlron.v_detbs_teller_master.txn_short_ovg_amount,
                                                   l_amount) 
                        THEN
                              dbg('Rounding failed for txn_short_ovg_amount');
                        ELSE
                              dbg('txn_short_ovg_amount after rounding~' ||
                                  l_amount);
                              p_wrk_dedtlron.v_detbs_teller_master.txn_short_ovg_amount := l_amount;
                        END IF;
                  END IF;
                  IF nvl(p_wrk_dedtlron.v_detbs_teller_master.offset_amount, 0) <> 0 
                  THEN
                        IF NOT cypkss.fn_amt_round(p_wrk_dedtlron.v_detbs_teller_master.offset_ccy,
                                                   p_wrk_dedtlron.v_detbs_teller_master.offset_amount,
                                                   l_amount) 
                        THEN
                              dbg('Rounding failed for offset_amount');
                        ELSE
                              dbg('offset_amount after rounding~' ||
                                  l_amount);
                              p_wrk_dedtlron.v_detbs_teller_master.offset_amount := l_amount;
                        END IF;
                  END IF;
                  IF nvl(p_wrk_dedtlron.v_detbs_teller_master.offset_short_ovg_amount,0) <> 0 
                  THEN
                        IF NOT cypkss.fn_amt_round(p_wrk_dedtlron.v_detbs_teller_master.offset_ccy,
                                                   p_wrk_dedtlron.v_detbs_teller_master.offset_short_ovg_amount,
                                                   l_amount) 
                        THEN
                              dbg('Rounding failed for offset_short_ovg_amount');
                        ELSE
                              dbg('offset_short_ovg_amount after rounding~' ||l_amount);
                              p_wrk_dedtlron.v_detbs_teller_master.offset_short_ovg_amount := l_amount;
                        END IF;
                  END IF;
                  IF nvl(p_wrk_dedtlron.v_detbs_teller_master.lcy_amount, 0) <> 0 
                  THEN
                        IF NOT cypkss.fn_amt_round(global.lcy,
                                                   p_wrk_dedtlron.v_detbs_teller_master.lcy_amount,
                                                   l_amount) 
                        THEN
                              dbg('Rounding failed for lcy_amount');
                        ELSE
                              dbg('lcy_amount after rounding~' || l_amount);
                              p_wrk_dedtlron.v_detbs_teller_master.lcy_amount := l_amount;
                        END IF;
                  END IF;
                  IF nvl(p_wrk_dedtlron.v_detbs_teller_master.charge_base_amt,0) <> 0 
                  THEN
                        IF NOT cypkss.fn_amt_round(p_wrk_dedtlron.v_detbs_teller_master.txn_ccy,
                                                   p_wrk_dedtlron.v_detbs_teller_master.charge_base_amt,
                                                   l_amount) 
                        THEN
                              dbg('Rounding failed for charge_base_amt');
                        ELSE
                              dbg('charge_base_amt after rounding~' ||
                                  l_amount);
                              p_wrk_dedtlron.v_detbs_teller_master.charge_base_amt := l_amount;
                        END IF;
                  END IF;
            
                  IF nvl(p_wrk_dedtlron.v_detbs_teller_master.net_amount, 0) <> 0 
                  THEN
                        IF NOT cypkss.fn_amt_round(p_wrk_dedtlron.v_detbs_teller_master.txn_ccy,
                                                   p_wrk_dedtlron.v_detbs_teller_master.net_amount,
                                                   l_amount) 
                        THEN
                              dbg('Rounding failed for net_amount');
                        ELSE
                              dbg('net_amount after rounding~' || l_amount);
                              p_wrk_dedtlron.v_detbs_teller_master.net_amount := l_amount;
                        END IF;
                  END IF;
                  IF nvl(p_wrk_dedtlron.v_detbs_teller_master.total_tax, 0) <> 0 
                  THEN
                        IF NOT cypkss.fn_amt_round(p_wrk_dedtlron.v_detbs_teller_master.txn_ccy,
                                                   p_wrk_dedtlron.v_detbs_teller_master.total_tax,
                                                   l_amount) 
                        THEN
                              dbg('Rounding failed for total_tax');
                        ELSE
                              dbg('total_tax after rounding~' || l_amount);
                              p_wrk_dedtlron.v_detbs_teller_master.total_tax := l_amount;
                        END IF;
                  END IF;
                  IF nvl(p_wrk_dedtlron.v_detbs_teller_master.total_charges,0) <> 0 
                  THEN
                        IF NOT cypkss.fn_amt_round(p_wrk_dedtlron.v_detbs_teller_master.txn_ccy,
                                                   p_wrk_dedtlron.v_detbs_teller_master.total_charges,
                                                   l_amount) 
                        THEN
                              dbg('Rounding failed for total_charges');
                        ELSE
                              dbg('total_charges after rounding~' ||l_amount);
                              p_wrk_dedtlron.v_detbs_teller_master.total_charges := l_amount;
                        END IF;
                  END IF;
                  IF nvl(p_wrk_dedtlron.v_detbs_teller_master.ofs_user_amt,0) <> 0 
                  THEN
                        IF NOT cypkss.fn_amt_round(p_wrk_dedtlron.v_detbs_teller_master.offset_ccy,
                                                   p_wrk_dedtlron.v_detbs_teller_master.ofs_user_amt,
                                                   l_amount) 
                        THEN
                              dbg('Rounding failed for ofs_user_amt');
                        ELSE
                              dbg('ofs_user_amt after rounding~' ||l_amount);
                              p_wrk_dedtlron.v_detbs_teller_master.ofs_user_amt := l_amount;
                        END IF;
                  END IF;
                  IF nvl(p_wrk_dedtlron.v_detbs_teller_master.ofs_disp_amt,0) <> 0 
                  THEN
                        IF NOT cypkss.fn_amt_round(p_wrk_dedtlron.v_detbs_teller_master.offset_ccy,
                                                   p_wrk_dedtlron.v_detbs_teller_master.ofs_disp_amt,
                                                   l_amount) 
                        THEN
                              dbg('Rounding failed for ofs_disp_amt');
                        ELSE
                              dbg('ofs_disp_amt after rounding~' ||l_amount);
                              p_wrk_dedtlron.v_detbs_teller_master.ofs_disp_amt := l_amount;
                        END IF;
                  END IF;
            END IF;
            --FCUBS12.0.1.7.0 CITI Vol6 Tag3 ITR SFR#412 Float Account processing Changes Ends
      
            --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 Changes Starts
            dbg('2.action code is: ' || p_Action_Code);
            IF p_Action_Code IN ('EXECUTEQUERY', 'AMT_COMP') AND
               fn_partial_pay_enabled AND
               p_wrk_dedtlron.v_detbs_teller_master.instrument_no IS NOT NULL 
            THEN
                  p_wrk_dedtlron.v_catb_check_util_extgbl.BRANCH   := p_wrk_dedtlron.v_detbs_teller_master.txn_branch;
                  p_wrk_dedtlron.v_catb_check_util_extgbl.ACCOUNT  := p_wrk_dedtlron.v_detbs_teller_master.txn_account;
                  p_wrk_dedtlron.v_catb_check_util_extgbl.CHECK_NO := p_wrk_dedtlron.v_detbs_teller_master.instrument_no;
            
                  dbg('BRANCH: ' || p_wrk_dedtlron.v_catb_check_util_extgbl.BRANCH);
                  dbg('ACCOUNT: ' || p_wrk_dedtlron.v_catb_check_util_extgbl.ACCOUNT);
                  dbg('CHECK_NO: ' || p_wrk_dedtlron.v_catb_check_util_extgbl.CHECK_NO);
            
                  IF NOT cvpkss_utils_extgbl.fn_get_claim_amount(p_wrk_dedtlron.v_catb_check_util_extgbl.BRANCH,
                                                                p_wrk_dedtlron.v_catb_check_util_extgbl.ACCOUNT,
                                                                p_wrk_dedtlron.v_catb_check_util_extgbl.CHECK_NO,
                                                                p_wrk_dedtlron.v_catb_check_util_extgbl.original_amt,
                                                                l_claim_amt) 
                  THEN
                        Dbg('Failed to get claim amount');
                  END IF;
            
                  IF p_Action_Code = 'AMT_COMP' 
                  THEN
                        --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 - review changes starts
                        IF p_wrk_dedtlron.v_catb_check_util_extgbl.original_amt IS NULL 
                        THEN
                              p_wrk_dedtlron.v_cstb_ui_columns.CHAR_FIELD12 := NULL;
                        ELSE
                              p_wrk_dedtlron.v_cstb_ui_columns.CHAR_FIELD12 := l_claim_amt;
                        END IF;
                        --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 - review changes ends
                  END IF;
            
                  Dbg('original_amt: ' || p_wrk_dedtlron.v_catb_check_util_extgbl.original_amt);
                  Dbg('claim amout: ' || p_wrk_dedtlron.v_cstb_ui_columns.CHAR_FIELD12);
            END IF;
            --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 Changes Ends
            dbg('Returning Success From Fn_Post_Query..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**', 'In When Others of depks_dedtlron_Custom.Fn_Post_Query ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_query;

      --FCUBS CITI Release FS_FCUBS12.0.0.1CitiDDA_Vol5 Threshold for cash in - cash out for automatic authorization  - #2441: starts
      FUNCTION fn_threshold(p_source           IN VARCHAR2,
                            p_product          IN VARCHAR2,
                            p_source_operation IN VARCHAR2,
                            p_function_id      IN VARCHAR2,
                            p_action_code      IN VARCHAR2,
                            p_wrk_dedtlron     IN OUT depks_dedtlron_main.ty_dedtlron,
                            p_err_code         IN OUT VARCHAR2,
                            p_err_params       IN OUT VARCHAR2) RETURN BOOLEAN IS
            l_auto_auth     detm_product_master_extgbl.auto_auth_req%TYPE;
            l_threshold_amt detm_product_master_extgbl.threshold_amt%TYPE;
            l_threshold_ccy detm_product_master_extgbl.threshhold_ccy%TYPE;
            l_rate          cytms_rates.mid_rate%TYPE;
            l_amt           detm_product_master_extgbl.threshold_amt%TYPE := '0';
            l_dedtlaut      depks_dedtlaut_main.ty_dedtlaut;
      BEGIN
            dbg('Inside Fn_Threshold..');
            BEGIN
                  SELECT auto_auth_req, threshold_amt, threshhold_ccy
                  INTO   l_auto_auth, l_threshold_amt, l_threshold_ccy
                  FROM   detm_product_master_extgbl
                  WHERE  product_code = p_product;
            
            EXCEPTION
                  WHEN no_data_found THEN
                        dbg('there is no record for the selected product code in detm_product_master_extgbl..');
                        l_auto_auth     := 'N';
                        l_threshold_ccy := NULL;
                        l_threshold_amt := NULL;
            END;
      
            IF l_auto_auth = 'Y' 
            THEN
                  IF l_threshold_ccy <> p_wrk_dedtlron.v_detbs_teller_master.txn_ccy 
                  THEN
                        IF NOT cypks.fn_amt1_to_amt2(p_wrk_dedtlron.v_detbs_teller_master.txn_branch,
                                                     p_wrk_dedtlron.v_detbs_teller_master.txn_ccy,
                                                     l_threshold_ccy,
                                                     p_wrk_dedtlron.v_detbs_teller_master.txn_amount,
                                                     'N',
                                                     l_amt,
                                                     l_rate,
                                                     p_err_code) 
                        THEN
                              dbg('failed in getting the transaction amount in product currency');
                              RETURN FALSE;
                        END IF;
                  
                  ELSE
                        l_amt := p_wrk_dedtlron.v_detbs_teller_master.txn_amount;
                  END IF;
                  dbg('Entered transaction amount is: ' || l_amt);
                  dbg('the threshold amount is: ' || l_threshold_amt);
            
                  IF l_amt <= l_threshold_amt 
                  THEN
                        dbg('Calling fn_teller_auth from depkss_teller..');
                        IF NOT depkss_teller.fn_teller_auth(global.current_branch,
                                                            p_wrk_dedtlron.v_detbs_teller_master.batch_no,
                                                            p_wrk_dedtlron.v_detbs_teller_master.reference_no,
                                                            p_wrk_dedtlron.v_detbs_teller_master.evnt_seq_no,
                                                            'SYSTEM',
                                                            'M',
                                                            to_date(global.application_date),
                                                            global.lcy,
                                                            p_err_code,
                                                            p_err_params) 
                        THEN
                              dbg('Failed in depkss_teller.fn_teller_auth');
                              RETURN FALSE;
                        END IF;
                  
                        IF NOT smpkss.fn_limits_validate('A',
                                                         p_wrk_dedtlron.v_detbs_teller_master.txn_ccy,
                                                         p_wrk_dedtlron.v_detbs_teller_master.txn_amount,
                                                         'SYSTEM',
                                                         global.current_branch,
                                                         p_err_code,
                                                         p_err_params) 
                        THEN
                              dbg('Failed in Smpkss.fn_limits_validate');
                              RETURN FALSE;
                        END IF;
                  
                        IF NOT fn_mesg_gen_on_auth(p_wrk_dedtlron.v_detbs_teller_master.reference_no,
                                                   p_wrk_dedtlron.v_detbs_teller_master.evnt_seq_no,
                                                   p_err_code,
                                                   p_err_params) 
                        THEN
                              p_err_code   := 'IF-MSC010';
                              p_err_params := '';
                              pr_log_error(p_function_id,
                                           p_source,
                                           p_err_code,
                                           p_err_params);
                        END IF;
                        p_err_code   := 'DE-APND-01';
                        p_err_params := '';
                        dbg('Doing an append Table');
                        ovpkss.pr_appendtbl(p_err_code, p_err_params);
                  ELSE
                        dbg('Transaction amount is more than the threshold amount maintained for the product');
                        dbg('Manual authorization required');
                  END IF;
            END IF;
            dbg('Returning success from Fn_Threshold..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**', 'In When Others of Fn_Main ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
            
      END fn_threshold;
      --FCUBS CITI Release FS_FCUBS12.0.0.1CitiDDA_Vol5 Threshold for cash in - cash out for automatic authorization  - #2441: ends
END depks_dedtlron_custom;
/
