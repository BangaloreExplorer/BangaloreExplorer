-- [AUTO COMMENT] 2014-12-11 16:53:34 - artf201827 : Fix for QC#233/QC#347/QC#357/QC#363
-- [AUTO COMMENT] 2014-07-14 23:15:58 - CASH Code MERGE with consulting patchsets R4-Lot5 and FCUBS_12.0.71.2.6
-- [AUTO COMMENT] 2014-02-03 12:42:03 - R3 CASH CODE MERGE WITH CONSULTING
CREATE OR REPLACE PACKAGE BODY depks_dedjnlon_custom AS
      /*-----------------------------------------------------------------------------------------------------
         **
         ** File Name  : depks_dedjnlon_custom.sql
         **
         ** Module     : Data Entry
         **
         ** This source is part of the Oracle FLEXCUBE Software System and is copyrighted by Oracle Financial Services Software Limited.
         **
         **
         ** All rights reserved. No part of this work may be reproduced, stored in a retrieval system,
         ** adopted or transmitted in any form or by any means, electronic, mechanical, photographic,
         ** graphic, optic recording or otherwise, translated in any language or computer language,
         ** without the prior written permission of Oracle Financial Services Software Limited.
         **
         ** Oracle Financial Services Software Limited.
         ** 10-11, SDF I, SEEPZ, Andheri (East),
         ** Mumbai - 400 096.
         ** India
         ** Copyright � 2008 - 2013 Oracle Financial Services Software Limited. All rights reserved.
         -------------------------------------------------------------------------------------------------------
         CHANGE HISTORY
      
         SFR Number         :  FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes
         Changed By          :  Maheboob Pasha Kazi
         Change Description :  User profile level Input and Authorization Limit setup
         Search String :  FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit
      
         ** Modfied By           : Rajesh Kumar J
         ** Modified On          : 07-JAN-2013
         ** Modified Reason      : Changes added to populate the data for internal and external remarks.
         ** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20
      
         ** Modfied By           : Girish L
         ** Modified On          : 10-JAN-2013
         ** Modified Reason      : Changes added to populate reated customer no and customer name.
         ** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3
      
         ** Modfied By           : Venkata Anjani
         ** Modified On          : 18-FEB-2013
         ** Modified Reason      : Changes added to add override in Journal Entry for Zero Fcy/Lcy amount
         ** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 21
      
         ** Modfied By           : Revathi
         ** Modified On          : 28-FEB-2013
         ** Modified Reason      : Changes added to support the Back Value Date based on Working Days and Calendar date
         ** Search String        : FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7 Back Value Date changes
      
         ** Changed On           : 10-Apr-2013
         ** Changed By           : Rajesh Kumar J
         ** Change Description   : Changes added to populate the data for internal and external remarks.
         ** Search string        : FCUBS12.0.0.1CITI IUT3 SFR# 14 - Internal remarks data is getting deleted automatically
      
         ** Changed On           : 06-May-2013
         ** Changed By           : Girish L
         ** Change Description   : Changes added to populate the data for Related Custome
         ** Search string        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 03 IUT3 SFR# 173
      
         ** Changed On           : 10-May-2013
         ** Changed By           : Rajesh Kumar J
         ** Change Description   : Changes added to allow save, without Related Customer
         ** Search string        : FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#6
      
         ** Changed On           : 13-May-2013
         ** Changed By           : Rajesh Kumar J
         ** Change Description   : Changes added to allow save, without Related Customer
         ** Search string        : FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#6
      
         ** Changed On           : 18-May-2013
         ** Changed By           : Rajesh Kumar J
         ** Change Description   : Related Customer
         ** Search string        : FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#186
      
         ** Modfied By           : Revathi
         ** Modified On          : 21-MAY-2013
         ** Modified Reason      : Function Call has been added to Validate Back Value Date
         ** Search String        : FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7Back Value Date changes IUT SFR 208
         
         ** Changed On           : 21-May-2013
         ** Changed By           : Rajesh Kumar J
         ** Change Description   : Internal and external remarks.
         ** Search string        : FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#292
      
         ** Changed On           : 24-May-2013
         ** Changed By           : Rajesh Kumar J
         ** Change Description   : Related customer allowing to save, before authorising, the mandatory check changed to NO.
         ** Search string        : FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#402
      
        ** Modfied By           : Sohini Makar
        ** Modified On          : 10-June-2013
        ** Modified Reason      : Related customer validation issues.
        ** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 #ITR2 sfr 83
      
        ** Modified By       : Asha G R
        ** Modified Date    : 04-Aug-2013
        ** Modification reason    : Manual Posting for Journal entries
        ** Search String    : FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5   
        
        ** Modfied By           : Nagaraja Pillari
        ** Modified On          : 07-OCT-2013
        ** Modified Reason      : Reference number issue 
        ** Search String        : FCUBS12.0.1.7CITIDDA REL2 Vol<3> Tag <5> #ITR1 SFR#6
    
        ** Modified By        : Rajesha K S/Ankush
      ** Modified On        : 13-MAR-2014
      ** Modified Reason    : USER_ID Validation/Value Date Defaulting.
      ** Search String      : FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3

      ** Modfied By              : Anjani
      ** Modified On             : 25 APR 2014
      ** Modified Reason         : Changes done for changing the referenced package ifpks_otat_gen_extgbl to ifpks_eca_extgbl 
      ** Search String           : FCUBS12.0.1.7CITIDDA Rel4 ECA Code Review Changes    
      ** Modfied By              : Ruchir Pandya
      ** Modified On             : 17-JUN-2016
      ** Modified Reason         : Enabling UDF pickup for DEDJNLON.
      ** Search String           : artf257638
      
      Modfied By              : Ruchir Pandya
    Modified On             : 02-SEP-2016
    Modified Reason         : DEDJNLON UDF related Fixes
    Search String           : artf257638-1
      Modfied By              : Onsite Team
    Modified On             : 23-SEP-2016
    Modified Reason         : DEDJNLON Compute Operation Failing When doing BV Txn to 1 day
    Search String           : DEDJNLON BV TXN Compute Error Fix 23-Sep
    
    ** Modfied By              : Siva
     ** Modified On             : 28 SEP 2016
     ** Modified Reason         : Changes done as part of "Offset posting by External reference" to validate "External Ref Number" 
     ** Search String           : CITI_FC12_R5_SUPP SIT1 SFR#919
  
  ** Modfied By              : Achyut
     ** Modified On             : 03-Oct-2016
     ** Modified Reason         : Changes done as part of "Offset posting by External reference" to validate "External Ref Number" retrofication
     ** Search String           : artf264299
  
  ** Modfied By              : Achyut
     ** Modified On             : 12-Oct-2016
     ** Modified Reason         : DDA QC 
     ** Search String           : artf255142_QC4060
     
  ** Modfied By           : Debasish
  ** Modified On          : 15 FEB 2018
  ** Modified Reason      : Changes done as part of "Affiliates V3" to validate "Reserve for Account before Authorisation" 
  ** Search String        : FCUBS12.0.1.7CITIDDA Affiliates V3 Changes     
      -------------------------------------------------------------------------------------------------------
         */


      PROCEDURE dbg(p_msg VARCHAR2) IS
            l_msg VARCHAR2(32767);
      BEGIN
            l_msg := 'depks_dedjnlon_Custom ==>' || p_msg;
            debug.pr_debug('DE', l_msg);
      END dbg;

      PROCEDURE pr_log_error
      (
            p_function_id IN VARCHAR2
           ,p_source      VARCHAR2
           ,p_err_code    VARCHAR2
           ,p_err_params  VARCHAR2
      ) IS
      BEGIN
            cspks_req_utils.pr_log_error(p_source, p_function_id,
                                         p_err_code, p_err_params);
      END pr_log_error;
      PROCEDURE pr_skip_handler(p_stage IN VARCHAR2) IS
      BEGIN
            dbg('In Pr_Skip_Handler..');
      END pr_skip_handler;
      FUNCTION fn_post_build_type_structure
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_child_function   IN VARCHAR2
           ,p_addl_info        IN cspks_req_global.ty_addl_info
           ,p_dedjnlon         IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
      BEGIN
      
            dbg('In Fn_Post_Build_Type_Structure..');
      
            dbg('Returning Success From Fn_Post_Build_Type_Structure..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Post_Build_Type_Structure ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_build_type_structure;

      FUNCTION fn_pre_check_mandatory
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_child_function   IN VARCHAR2
           ,p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL'
           ,p_dedjnlon         IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN
      
       IS
      BEGIN
      
            dbg('In Fn_Pre_Check_Mandatory..');
      
            dbg('Returning  Success From Fn_Pre_Check_Mandatory..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Pre_Check_Mandatory ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_check_mandatory;

      FUNCTION fn_post_check_mandatory
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_child_function   IN VARCHAR2
           ,p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL'
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN
      
       IS
       --artf264299 retro starts
       --CITI_FC12_R5_SUPP SIT1 SFR#919 starts
            l_count          NUMBER;
            l_offset_posting detms_branch_cond_extgbl.offset_post_by_ext_ref%TYPE;
            --CITI_FC12_R5_SUPP SIT1 SFR#919 ends
      --artf264299 retro ends
      BEGIN
      
            dbg('In Fn_Post_Check_Mandatory..');
      --artf264299 retro starts      
            --CITI_FC12_R5_SUPP SIT1 SFR#919 starts
            IF p_action_code IN (Cspks_Req_Global.p_New, Cspks_Req_Global.p_Modify) 
            THEN
              BEGIN
                SELECT Nvl(offset_post_by_ext_ref, 'N')
                  INTO l_offset_posting
                  FROM detms_branch_cond_extgbl
                 WHERE branch_code = global.current_branch;
              EXCEPTION WHEN NO_DATA_FOUND THEN
                l_offset_posting := 'N';
              END;
              
              Dbg('l_offset_posting: '||l_offset_posting);
              IF l_offset_posting = 'Y' 
              THEN
                l_count := p_dedjnlon.v_jrnl_txn_detl_extgbl.COUNT;
                Dbg('l_count: '||l_count);
                
                FOR i IN 1..l_count
                LOOP
                  IF p_dedjnlon.v_jrnl_txn_detl_extgbl(i).external_ref_no IS NULL 
                  THEN
                    Dbg('External Reference Number is null for serial: '||p_dedjnlon.v_jrnl_txn_detl_extgbl(i).serial_no);
                    
                    p_err_code := 'DE-EXT-001';
                    p_err_params := '';
                    pr_log_error(p_function_id, 'FLEXCUBE', p_err_code, p_err_params);
                  END IF;
                END LOOP;
              END IF;
            END IF;
            --CITI_FC12_R5_SUPP SIT1 SFR#919 ends
      --artf264299 retro ends
            dbg('Returning Success From Fn_Post_Check_Mandatory..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Post_Check_Mandatory ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_check_mandatory;

      FUNCTION fn_pre_default_and_validate
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_child_function   IN VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_prev_dedjnlon    IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_wrk_dedjnlon     IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 21 changes start
            l_count NUMBER;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 21 changes end
      BEGIN
      
      
            dbg('In Fn_Pre_Default_And_Validate..');
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 21 changes start
            IF p_action_code IN ('NEW', 'MODIFY')
            THEN
                  l_count := p_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
                  FOR l_index IN 1 .. l_count
                  LOOP
                        IF p_dedjnlon.v_detbs_jrnl_txn_master.ccy <>
                           p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ccy
                        THEN
                              IF nvl(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                                     .amount, 0) = 0 AND
                                 p_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                              .lcy_amount <> 0
                              THEN
                                    p_prev_dedjnlon.v_detbs_jrnl_txn_detail(l_index).lcy_amount := p_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                                                                                                  .lcy_amount;
                                    dbg('LCY AMOUNT taken as a backup is' ||
                                        p_prev_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                                        .lcy_amount);
                              END IF;
                        END IF;
                  END LOOP;
            END IF;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 21 changes end
      
      
            smpks.g_tb_cluster_data('MODULE_ID') := 'DE'; --FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit
      
            dbg('Returning Success From Fn_Pre_Default_And_Validate..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Pre_Default_And_Validate ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_default_and_validate;

      FUNCTION fn_post_default_and_validate
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_child_function   IN VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_prev_dedjnlon    IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_wrk_dedjnlon     IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
            l_count NUMBER; -- FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit
            l_name  VARCHAR2(20); --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3
      
            --FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7 Back Value Date changes starts
            l_back_value_basis CHAR(1);
            l_acalc_bvday      DATE;
            l_val_date         DATE;
            l_diff             NUMBER := 0;
            l_allowed          detms_branch_cond.back_value%TYPE;
            l_days             detms_branch_cond.back_value_days%TYPE;
            l_cnt              NUMBER;
            --FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7 Back Value Date changes ends
            l_rel_cust_mandat sttms_branch_extgbl.related_cust_mandatory%TYPE; --FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#6
      BEGIN
      
            dbg('In Fn_Post_Default_And_Validate..');
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 21 changes start
            IF p_action_code IN ('NEW', 'MODIFY')
            THEN
                  l_count := p_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
                  FOR l_index IN 1 .. l_count
                  LOOP
                        dbg('l_index is' || l_index);
                        dbg('l_count is' || l_count);
                        IF p_dedjnlon.v_detbs_jrnl_txn_master.ccy <>
                           p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ccy
                        THEN
                              IF nvl(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                                     .lcy_amount, 0) = 0 AND
                                 p_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                              .amount <> 0
                              THEN
                                    p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index).lcy_amount := 0;
                                    pr_log_error(p_function_id, 'FLEXCUBE',
                                                 'DE-LCY-001',
                                                 p_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                                                 .amount);
                              END IF;
                              IF nvl(p_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                                     .amount, 0) = 0 AND
                                 p_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                              .lcy_amount <> 0
                              THEN
                              
                                    p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index).lcy_amount := p_prev_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                                                                                                 .lcy_amount;
                                    IF ovpks.gl_tblerror.COUNT > 0
                                    THEN
                                          FOR i IN 1 .. ovpks.gl_tblerror.COUNT
                                          LOOP
                                                IF ovpks.gl_tblerror(i)
                                                .err_code IN
                                                   ('CY-9001', 'DE-JRN68')
                                                THEN
                                                      dbg('Going to delete the error code');
                                                      ovpks.gl_tblerror.DELETE(i);
                                                END IF;
                                          END LOOP;
                                    END IF;
                                    pr_log_error(p_function_id, 'FLEXCUBE',
                                                 'DE-AMT-001',
                                                 p_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                                                 .lcy_amount);
                              END IF;
                              IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                              .lcy_amount = 0 AND
                                 p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                              .amount = 0
                              THEN
                                    pr_log_error(p_function_id, 'FLEXCUBE',
                                                 'DE-AMT-002', NULL);
                              END IF;
                        END IF;
                        IF p_dedjnlon.v_detbs_jrnl_txn_master.ccy =
                           p_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ccy
                        THEN
                              IF p_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                              .lcy_amount = 0
                              THEN
                                    pr_log_error(p_function_id, 'FLEXCUBE',
                                                 'DE-AMT-003', NULL);
                              END IF;
                        END IF;
                  END LOOP;
            END IF;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 21 changes end
            --FCUBS Release 12.0.0.1.0CITIGTS Lot2 - Input/Auth Limit (Start)
            dbg('p_Source                                          ' ||
                p_source);
            dbg('p_Source_Operation                                ' ||
                p_source_operation);
            dbg('p_Function_Id                                     ' ||
                p_function_id);
            dbg('p_Action_Code                                     ' ||
                p_action_code);
            dbg('p_Child_Function                                  ' ||
                p_child_function);
            dbg('Global.User_Id                                    ' ||
                global.user_id);
            dbg('global.current_branch                             ' ||
                global.current_branch);
      
            l_count := p_wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT;
      
            dbg('JRn count is ' || l_count);
      
            FOR l_index IN 1 .. l_count
            LOOP
                  dbg(' p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index).CCY -->' ||
                      p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ccy);
                  dbg(' p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index).Amount -->' ||
                      p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                      .amount);
            
            
                  IF NOT
                      smpks.fn_limits_validate('I',
                                               p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index).ccy,
                                               p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(l_index)
                                               .amount, global.user_id,
                                               global.current_branch,
                                               p_err_code, p_err_params)
                  
                  THEN
                        dbg('Failed in smpks.fn_limits_validate');
                        RETURN FALSE;
                  END IF;
            END LOOP;
      
            --FCUBS Release 12.0.0.1.0CITIGTS Lot2 - Input/Auth Limit (End)
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 STARTS
      
            dbg('p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT ' ||
                p_wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT);
            dbg('P_SOURCE ' || p_source);
            dbg('p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no ' ||
                p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no);
            dbg('P_ACTION_CODE ' || p_action_code);
      
            IF p_action_code = 'NEW'
            THEN
                  FOR i IN 1 .. p_wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT
                  LOOP
                        IF p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                        .ac_gl_no IS NOT NULL
                        --FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#6 starts
                        /*
                                                                                                                           AND p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                                                                                                                        .related_customer IS NULL*/
                        THEN
                              --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 #ITR2 sfr 83: starts
                              dbg('Calling depks_services_extgbl.Fn_Validate_rel_cust_mand');
                              IF NOT
                                  depks_services_extgbl.fn_validate_rel_cust_mand(global.current_branch,
                                                                                  p_dedjnlon.v_detbs_jrnl_txn_detail(i)
                                                                                  .related_customer,
                                                                                  p_action_code,
                                                                                  p_err_code,
                                                                                  p_err_params)
                              THEN
                                    dbg('Failed in depks_services_extgbl.Fn_Validate_rel_cust_mand');
                                    pr_log_error(p_function_id, p_source,
                                                 p_err_code, p_err_params);
                              END IF;
                              --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 #ITR2 sfr 83: ends
                              --FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#6 ends
                        END IF;
                  END LOOP;
            END IF;
      
      
            IF p_action_code = 'DEFLTTEMP' AND p_source = 'FLEXCUBE'
            THEN
                  dbg('IN ACTION CODE PRD_DFLT');
                  dbg('p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no ' ||
                      p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no);
                  IF p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no IS NOT NULL
                  THEN
                        BEGIN
                              FOR i IN 1 .. p_wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT
                              LOOP
                                    dbg('Detail Ref Before Assigning CUSTOM: ' ||
                                        p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                                        .reference_no);
                                    p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i).reference_no := nvl(p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                                                                                                  .reference_no,
                                                                                                  p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no);
                                    dbg('Detail Ref After Assigning CUSTOM: ' ||
                                        p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                                        .reference_no);
                              END LOOP;
                        EXCEPTION
                              WHEN OTHERS THEN
                                    dbg('IN WHEN OTHERS ' || SQLERRM);
                        END;
                  END IF;
            
                  FOR i IN 1 .. p_wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT
                  LOOP
                        dbg('cAME INSIDE Fn_Post_Default_And_Validate.');
                        dbg('p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(i).RELATED_CUSTOMER ' ||
                            p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                            .related_customer);
                        dbg('p_Wrk_dedjnlon.v_detbs_jrnl_txn_detail(i).serial_no ' ||
                            p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                            .serial_no);
                  
                        BEGIN
                              SELECT short_name
                              INTO   l_name
                              FROM   sttm_customer
                              WHERE  customer_no =
                                     p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                              .related_customer;
                        
                              p_wrk_dedjnlon.v_cstbs_ui_columns__alias(i).char_field1 := nvl(p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                                                                                             .reference_no,
                                                                                             p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no);
                              p_wrk_dedjnlon.v_cstbs_ui_columns__alias(i).num_field15 := p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                                                                                        .serial_no;
                              p_wrk_dedjnlon.v_cstbs_ui_columns__alias(i).char_field31 := l_name;
                        
                              dbg('ASSIGNED');
                              dbg('p_Wrk_dedjnlon.v_CSTBS_UI_COLUMNS__ALIAS(I).CHAR_FIELD1 ' ||
                                  p_wrk_dedjnlon.v_cstbs_ui_columns__alias(i)
                                  .char_field1);
                              dbg('p_Wrk_dedjnlon.v_CSTBS_UI_COLUMNS__ALIAS(I).NUM_FIELD15 ' ||
                                  p_wrk_dedjnlon.v_cstbs_ui_columns__alias(i)
                                  .num_field15);
                              dbg('p_Wrk_dedjnlon.v_CSTBS_UI_COLUMNS__ALIAS(I).CHAR_FIELD31 ' ||
                                  p_wrk_dedjnlon.v_cstbs_ui_columns__alias(i)
                                  .char_field31);
                        
                        EXCEPTION
                              WHEN no_data_found THEN
                                    dbg('IN NO DATA FOUND');
                                    p_wrk_dedjnlon.v_cstbs_ui_columns__alias(i).char_field31 := 'WALKIN CUSTOMER';
                                    continue;
                              
                              WHEN OTHERS THEN
                                    dbg('CAME HERE ' || SQLERRM);
                                    NULL;
                        END;
                  
                  END LOOP;
            
                  --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 03 IUT3 SFR# 173 starts
                  FOR i IN 1 .. p_wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT
                  LOOP
                        IF p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                        .ac_gl_no IS NOT NULL AND
                           p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                        .ac_or_gl = 'G'
                        THEN
                              p_wrk_dedjnlon.v_cstbs_ui_columns__alias(i).char_field1 := p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no;
                        
                              SELECT walkin_customer
                              INTO   p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i) .related_customer
                              FROM   sttm_branch
                              WHERE  branch_code = global.current_branch;
                        
                              SELECT short_name
                              INTO   p_wrk_dedjnlon.v_cstbs_ui_columns__alias(i) .char_field31
                              FROM   sttm_customer
                              WHERE  customer_no =
                                     p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                              .related_customer;
                        ELSIF p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                        .ac_or_gl = 'A'
                        THEN
                        
                              p_wrk_dedjnlon.v_cstbs_ui_columns__alias(i).char_field1 := p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no;
                              
                              dbg('p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i).ac_gl_no==>' || p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i).ac_gl_no);
                              
                              /*
                              SELECT related_cust_no
                              INTO   p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i) .related_customer
                              FROM   detms_jrnl_tmpl_dtl_extgbl
                              WHERE  template_id =  p_wrk_dedjnlon.v_detbs_jrnl_txn_master.template_id;
                              */
                              
                              SELECT related_cust_no
                              INTO   p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i) .related_customer
                              FROM   detms_jrnl_tmpl_master a,detms_jrnl_tmpl_detail b, detms_jrnl_tmpl_dtl_extgbl c
                              WHERE  a.template_id =  p_wrk_dedjnlon.v_detbs_jrnl_txn_master.template_id
                              AND     a.record_stat  =  'O'
                              AND     a.auth_Stat    =  'A'
                              AND     a.template_id  =  b.template_id
                              AND     b.template_id  =  c.template_id
                              and     b.serial_no    =  c.serial_no
                              AND     b.ac_gl_no    =  p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i).ac_gl_no;
                              dbg('ac_gl_no~customer no==>' || p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i).ac_gl_no || '~' || p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i) .related_customer );
                              
                        
                              SELECT short_name
                              INTO   p_wrk_dedjnlon.v_cstbs_ui_columns__alias(i) .char_field31
                              FROM   sttm_customer
                              WHERE  customer_no =
                                     p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                              .related_customer;
                        
                        END IF;
                  END LOOP;
                  --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 03 IUT3 SFR# 173 Ends
                  dbg('OUTSIDE LOOP ');
            END IF;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 ENDS
            --FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7 Back Value Date changes starts
            --DEDJNLON BV TXN Compute Error Fix 23-Sep Starts
            --IF p_action_code IN (cspks_req_global.p_new) 
           IF p_action_code IN (cspks_req_global.p_new,'AMT_COMP')
            --DEDJNLON BV TXN Compute Error Fix 23-Sep Ends
            THEN
                  dbg('validation starts for value date');
                  -- FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7Back Value Date changes IUT SFR 208 starts
                  
                  -- FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 Changes Starts
              IF p_wrk_dedjnlon.v_detbs_jrnl_txn_master.value_date < Global.Application_Date
              THEN                  
                  IF NOT
                      depkss_services_extgbl.fn_validate_bkvaldt(global.current_branch,
                                                                 p_function_id,
                                                                 global.application_date,
                                                                 p_wrk_dedjnlon.v_detbs_jrnl_txn_master.value_date,
                                                                 p_err_code,
                                                                 p_err_params)
                  THEN
                        pr_log_error(p_function_id, p_source, p_err_code,
                                     p_err_params);
                        RETURN FALSE;
                  
                  ELSE
                        dbg('Returning Success From depkss_services_extgbl - Fn_Validate_ValDt');
                  END IF;
                  --FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7Back Value Date changes IUT SFR 208 ends
              ELSIF p_wrk_dedjnlon.v_detbs_jrnl_txn_master.value_date > Global.Application_Date
              THEN
                Dbg('validation starts for future value date');
                IF NOT Depkss_Services_Extgbl.Fn_Validate_Futurevaldt(
                    Global.Current_Branch,
                    p_function_id,
                    Global.Application_Date,
                    p_wrk_dedjnlon.v_detbs_jrnl_txn_master.value_date,
                    p_err_code,
                    p_err_params
                    )
                THEN
                  pr_log_error(p_function_id, p_source, p_err_code,
                  p_err_params);
                  --RETURN FALSE;
                ELSE
                  Dbg('Returning Success From depkss_services_extgbl - Fn_Validate_ValDt');
                END IF;
              END IF;
              -- FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 Changes Ends                  
            
            END IF;
            --FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7 Back Value Date changes ends
            RETURN TRUE;
      
      
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Post_Default_And_Validate ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_default_and_validate;

      FUNCTION fn_pre_resolve_ref_numbers
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_dedjnlon         IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
      
      BEGIN
      
            dbg('In Fn_Pre_Resolve_Ref_Numbers..');
      
            dbg('Returning Success From Fn_Pre_Resolve_Ref_Numbers');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Main.Fn_Pre_Resolve_Ref_Numbers ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_resolve_ref_numbers;
      FUNCTION fn_post_resolve_ref_numbers
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_dedjnlon         IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
      
      BEGIN
      
            dbg('In Fn_Post_Resolve_Ref_Numbers..');
            IF p_action_code IN ('PRD_DFLT') THEN--artf257638
p_dedjnlon.V_CSTBS_UI_COLUMNS.CHAR_FIELD1 := 'CSCTRUDF:D;';--artf257638
END IF;--artf257638
            dbg('Returning Success From Fn_Post_Resolve_Ref_Numbers..');
            RETURN TRUE;
      
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When others of depks_dedjnlon_Main.Fn_Post_Resolve_Ref_Numbers ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_resolve_ref_numbers;
      FUNCTION fn_pre_product_default
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_wrk_dedjnlon     IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
      BEGIN
      
            dbg('In Fn_Pre_Product_Default..');
      
            dbg('Returning Success From Fn_Pre_Product_Default..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Pre_Product_Default ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_product_default;

      FUNCTION fn_post_product_default
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_wrk_dedjnlon     IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
      BEGIN
      
            dbg('In Fn_Post_Product_Default..');
      
            dbg('Returning Success From Fn_Post_Product_Default..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Post_Product_Default ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_product_default;

      FUNCTION fn_pre_unlock
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN OUT VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
      BEGIN
      
            dbg('In Fn_Pre_Unlock..');
      
            dbg('Returning Success From Fn_Pre_Unlock..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Pre_Unlock ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_unlock;

      FUNCTION fn_post_unlock
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN OUT VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
      BEGIN
      
            dbg('In Fn_Post_Unlock');
      
            dbg('Returning Success From Fn_Post_Unlock..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Post_Unlock ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_unlock;

      FUNCTION fn_pre_subsys_pickup
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_prev_dedjnlon    IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_wrk_dedjnlon     IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
      BEGIN
      
            dbg('In Fn_Pre_Subsys_Pickup..');
      
            dbg('Returning Success From Fn_Pre_Subsys_Pickup..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Pre_Subsys_Pickup ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_subsys_pickup;

      FUNCTION fn_post_subsys_pickup
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_prev_dedjnlon    IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_wrk_dedjnlon     IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
    
    --artf257638 Starts
            L_SUBSYS_STAT VARCHAR2(500);
    L_PICKUP      BOOLEAN := TRUE;
    L_STAT        VARCHAR2(1);
    L_PICKEDUP    BOOLEAN := TRUE;
    L_UDF_TBL     UVPKS_UDF_UPLOAD.TY_UPL_CONT_UDF;
    L_VERSION_NO  CSTMS_CONTRACT_USERDEF_FIELDS.VERSION_NO%TYPE;
    L_UDF_REC     CSTMS_CONTRACT_USERDEF_FIELDS%ROWTYPE;--artf257638-1
            --artf257638 Ends
      BEGIN
      
            dbg('In Fn_Post_Subsys_Pickup..');
            --artf257638 Starts
  --******************************************
            DBG('UDF PCIKUP');
      
      L_PICKEDUP := TRUE;
      L_STAT     := CSPKS_ONLINE_UTILS.FN_GET_SUBSYS_STAT(P_SOURCE,
                                                          'CSCTRUDF',
                                                          L_SUBSYS_STAT);
                                                        
      IF L_STAT = 'R' THEN
        DBG('Re-defaulting UDF pick up');
        PR_LOG_ERROR(P_FUNCTION_ID, P_SOURCE, 'CS-CUDF-RDF', NULL);
      END IF;

      DBG('Uvpkss_Udf_Upload.Fn_Pickup_Cont_Udf');
      IF NOT UVPKSS_UDF_UPLOAD.FN_PICKUP_CONT_UDF(p_wrk_dedjnlon.v_detbs_jrnl_txn_master.REFERENCE_NO,
                                                  'DE',
                                                  '0000',
                                                  P_ERR_CODE,
                                                  P_ERR_PARAMS) THEN
        DBG('Failed in Uvpkss_Udf_Upload.Fn_Pickup_Cont_Udf..');
        L_PICKEDUP := FALSE;
        RETURN FALSE;
      END IF;
      DBG('Reddy' || p_wrk_dedjnlon.TXN_UDF_DETAILS.COUNT);
      --artf257638-1 Starts
      IF NOT stpks_cash_utils.FN_QUERY_CONT_UDFDETAILS(P_FUNCTION_ID,
                                                         P_WRK_DEDJNLON.v_detbs_jrnl_txn_master.REFERENCE_NO,
                                                         NULL,
                                                         L_UDF_REC,
                                                         p_wrk_dedjnlon,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Query_Cont_Udfdetails..');
      RETURN FALSE;
    END IF;
    
    DBG(' Count of UDF Table-->'||L_UDF_TBL.COUNT);
    DBG('Count of fn id variable-->'||P_DEDJNLON.TXN_UDF_DETAILS.COUNT);
    DBG('Count of Wrk variable-->'||p_wrk_dedjnlon.TXN_UDF_DETAILS.COUNT);
    DBG('l_stat variable-->'||L_STAT);
   IF P_DEDJNLON.TXN_UDF_DETAILS.COUNT = 0 THEN
    DBG('going to assign p_wrk_dedtronl');
     L_UDF_TBL :=p_wrk_dedjnlon.TXN_UDF_DETAILS;
   ELSE
   DBG('going to assign p_dedtronl');
      L_UDF_TBL :=P_DEDJNLON.TXN_UDF_DETAILS;
   END IF;
   DBG('p_action_code'||P_ACTION_CODE);
   --artf257638-1 Ends
   
   
      IF p_wrk_dedjnlon.TXN_UDF_DETAILS.COUNT > 0 
      AND (L_STAT <> 'D' OR P_ACTION_CODE='NEW')--artf257638-1
      THEN
        DBG('Uvpks_Udf_Upload.Fn_Validate_Contract_Udf');
        IF NOT UVPKS_UDF_UPLOAD.FN_VALIDATE_CONTRACT_UDF(L_UDF_TBL,
                                                         '0000',
                                                         'INIT',
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
          DBG('Failed in Uvpks_Udf_Upload.Fn_Validate_Contract_Udf..');
          RETURN FALSE;
        ELSE
          BEGIN
            SELECT NVL(MAX(VERSION_NO), 1)
              INTO L_VERSION_NO
              FROM CSTMS_CONTRACT_USERDEF_FIELDS
             WHERE CONTRACT_REF_NO =
                   p_wrk_dedjnlon.v_detbs_jrnl_txn_master.REFERENCE_NO;
          EXCEPTION
            WHEN OTHERS THEN
              DBG('Failed While Selecting the latest version from cstms_contract_userdef_fields');
              DBG(SQLERRM);
              L_VERSION_NO := 1;
          END;

          DBG('Uvpkss_Udf_Upload.Fn_Contract_Udf_Upload_Type');
          IF NOT
              UVPKSS_UDF_UPLOAD.FN_CONTRACT_UDF_UPLOAD_TYPE(P_SOURCE,
                                                            p_wrk_dedjnlon.v_detbs_jrnl_txn_master.REFERENCE_NO,
                                                            p_wrk_dedjnlon.v_detbs_jrnl_txn_master.REFERENCE_NO,
                                                            L_VERSION_NO,
                                                            '0000',
                                                            P_ACTION_CODE,
                                                            --p_wrk_dedjnlon.TXN_UDF_DETAILS,--artf257638-1
                                                            L_UDF_TBL,--artf257638-1
                                                            P_ERR_CODE,
                                                            P_ERR_PARAMS) THEN
            DBG('Failed in Uvpkss_Udf_Upload.Fn_Contract_Udf_Upload_Type ');
            L_PICKEDUP := FALSE;
            RETURN FALSE;
          END IF;
        END IF;
      END IF;

      L_SUBSYS_STAT := CSPKS_ONLINE_UTILS.FN_UPD_SUBSYS_STAT('CSCTRUDF',
                                                             'S',
                                                             L_SUBSYS_STAT);
                   --artf257638 Ends
            --******************************************
            dbg('Returning Success From Fn_Post_Subsys_Pickup..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Post_Subsys_Pickup ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_subsys_pickup;

      FUNCTION fn_pre_enrich
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_prev_dedjnlon    IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_wrk_dedjnlon     IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
      BEGIN
      
            dbg('In Fn_Pre_Enrich..');
      
            dbg('Returning Success From Fn_Pre_Enrich..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Pre_Enrich ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_enrich;

      FUNCTION fn_post_enrich
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_prev_dedjnlon    IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_wrk_dedjnlon     IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
      BEGIN
      
            dbg('In Fn_Post_Enrich..');
      
            dbg('Returning Success From Fn_Post_Enrich..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Post_Enrich ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_enrich;

      FUNCTION fn_pre_upload_db
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_child_function   IN VARCHAR2
           ,p_multi_trip_id    IN VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_prev_dedjnlon    IN depks_dedjnlon_main.ty_dedjnlon
           ,p_wrk_dedjnlon     IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
            --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes strts
            l_count       NUMBER;
            l_txn_id      iftbs_eca_req_dtl_extgbl.unique_txn_id%TYPE;
            l_trn_branch  sttms_branch.branch_code%TYPE;
            l_sttmbrn_gbl cvpkss_utils_extgbl.typ_sttmbrn_gbl;
            l_eca_flag    sttms_branch_extgbl.eca_flag%TYPE;
            --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends      
      --artf264299 retro starts
            --CITI_FC12_R5_SUPP SIT1 SFR#919 starts
            l_ins_count         NUMBER := 0;
            l_upd_count         NUMBER := 0;
            l_del_count         NUMBER := 0;
            l_wrk_count         NUMBER := 0;
            l_prev_count        NUMBER := 0;
            l_rec_found         BOOLEAN := FALSE;
            
            i_v_jrnl_txn_detail_extgbl depks_dedjnlon_main.ty_tb_v_jrnl_txn_detl_extgbl;
            u_v_jrnl_txn_detail_extgbl depks_dedjnlon_main.ty_tb_v_jrnl_txn_detl_extgbl;
            d_v_jrnl_txn_detail_extgbl depks_dedjnlon_main.ty_tb_v_jrnl_txn_detl_extgbl;
      
            TYPE ty_tb_l_jrnl_txn_detail_extgbl IS TABLE OF detbs_jrnl_txn_detl_extgbl%ROWTYPE INDEX BY BINARY_INTEGER;
            l_tab_ty_txn_det_extgbl ty_tb_l_jrnl_txn_detail_extgbl;
            
            CURSOR v_extgbl IS
                  SELECT *
                  FROM   detbs_jrnl_txn_detl_extgbl
                  WHERE  reference_no =
                         p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no;
            --CITI_FC12_R5_SUPP SIT1 SFR#919 ends
      --artf264299 retro ends
      BEGIN
      
            dbg('In Fn_Pre_Upload_Db..');
            --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes strts
      
            l_trn_branch := global.current_branch;
      
            dbg('Calling cvpks_utils_extgbl.get_sttm_brn for getting branch level ECA flag value');
      
            cvpks_utils_extgbl.get_sttm_brn(l_trn_branch, l_sttmbrn_gbl);
      
            dbg('ECA Flag value for the branch is: ' ||
                l_sttmbrn_gbl.sttm_brn_extgblrec.eca_flag);
      
            l_eca_flag := nvl(l_sttmbrn_gbl.sttm_brn_extgblrec.eca_flag, 'N');
      
            IF p_action_code = cspks_req_global.p_delete AND
               l_eca_flag IN ('F', 'L')
            THEN
                  dbg('Action Code ' || p_action_code);
                  BEGIN
                        SELECT MAX(unique_txn_id)
                        INTO   l_txn_id
                        FROM   iftbs_eca_req_dtl_extgbl
                        WHERE  fcc_process_ref_no =
                               p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no
                               AND
                               original_number =
                               p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no
                               --AND statuscode <> 'D';
                               AND eca_status <> 'D';--FCUBS12.0.1.7CITIDDA Rel4 ECA Code Review Changes
                  EXCEPTION
                        WHEN OTHERS THEN
                              dbg('In WOT of ' || SQLERRM);
                  END;
            
                  dbg('unique_txn_id is ' || l_txn_id);
            
                  IF l_txn_id IS NOT NULL
                  THEN
                  
                        UPDATE iftb_eca_req_dtl_extgbl
                        --SET  statuscode = 'D'
                          SET  eca_status = 'D' --FCUBS12.0.1.7CITIDDA Rel4 ECA Code Review Changes
                        WHERE  unique_txn_id = l_txn_id;
                  END IF;
            
            END IF;
            --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends            
    --CITI_FC12_R5_SUPP SIT1 SFR#919 starts --Moved code from post_upload_db
    --artf264299 retro starts
    /*  
            dbg('Returning Success From Fn_Pre_Upload_Db..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Pre_Upload_Db ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_upload_db;

      FUNCTION fn_post_upload_db
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_child_function   IN VARCHAR2
           ,p_multi_trip_id    IN VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_prev_dedjnlon    IN depks_dedjnlon_main.ty_dedjnlon
           ,p_wrk_dedjnlon     IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 STARTS
            l_count             NUMBER := 0;
            l_ins_count         NUMBER := 0;
            l_upd_count         NUMBER := 0;
            l_del_count         NUMBER := 0;
            l_wrk_count         NUMBER := 0;
            l_prev_count        NUMBER := 0;
            l_rec_found         BOOLEAN := FALSE;
            l_row_id            ROWID;
            l_key               VARCHAR2(5000) := NULL;
            l_auth_stat         VARCHAR2(1) := 'A';
            l_base_data_from_fc VARCHAR2(1) := 'Y';
      
            i_v_jrnl_txn_detail_extgbl depks_dedjnlon_main.ty_tb_v_jrnl_txn_detl_extgbl;
            u_v_jrnl_txn_detail_extgbl depks_dedjnlon_main.ty_tb_v_jrnl_txn_detl_extgbl;
            d_v_jrnl_txn_detail_extgbl depks_dedjnlon_main.ty_tb_v_jrnl_txn_detl_extgbl;
      
            TYPE ty_tb_l_jrnl_txn_detail_extgbl IS TABLE OF detbs_jrnl_txn_detl_extgbl%ROWTYPE INDEX BY BINARY_INTEGER;
            l_tab_ty_txn_det_extgbl ty_tb_l_jrnl_txn_detail_extgbl;
      
            CURSOR v_extgbl IS
                  SELECT *
                  FROM   detbs_jrnl_txn_detl_extgbl
                  WHERE  reference_no =
                         p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 ENDS
      
            --FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#292 starts
            l_internal_remarks actbs_recon_details_extgbl.internal_remarks%TYPE;
            l_external_remarks actbs_recon_details_extgbl.internal_remarks%TYPE;
      
            CURSOR v_recon_master IS
                  SELECT *
                  FROM   actbs_recon_master
                  WHERE  branch =
                         p_wrk_dedjnlon.v_detbs_jrnl_txn_master.branch_code
                         AND
                         ref_no =
                         p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no;
      
            CURSOR v_recon_details(p_branch VARCHAR2, p_account VARCHAR2, p_ccy VARCHAR2, p_reconno VARCHAR2, p_refno VARCHAR2) IS
                  SELECT *
                  FROM   actbs_recon_details
                  WHERE  branch = p_branch
                         AND account = p_account
                         AND ccy = p_ccy
                         AND reconno = p_reconno
                         AND ref_no = p_refno;
            --FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#292 ends    
      
            --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes for updating iftbs_otat_details_extgbl status on Del strts
            l_ot_at_tk_ref iftbs_otat_details_extgbl.otat_tkt_ref%TYPE;
            l_rej_code     NUMBER := 1;
            l_called_from  VARCHAR2(10) := 'AUTHORIZE';
            l_action_code  VARCHAR2(5) := 'D';
            l_auth_id      VARCHAR2(10) := global.user_id;
            l_otat_status  iftbs_otat_details_extgbl.status%TYPE;
            l_msg          VARCHAR2(500);
            --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends
      
      BEGIN
      
            dbg('In Fn_Post_Upload_Db..');
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 STARTS
*/
--artf264299 retro ends      
            IF p_action_code = cspks_req_global.p_new
            THEN
            
                  dbg('Inserting Into DETBS_JRNL_TXN_DETL_EXTGBL..');
                  BEGIN
                        --FCUBS12.0.1.7CITIDDA REL2 Vol<3> Tag <5> #ITR1 SFR#6  Starts
                        IF p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no IS NOT NULL
                        THEN
                              FOR i IN 1 .. p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl.COUNT
                              LOOP
                                    dbg('Extgbl Ref Before Assigning : ' ||
                                        p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(i)
                                        .reference_no);
                                    p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(i).reference_no := nvl(p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(i)
                                                                                                 .reference_no,
                                                                                                 p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no);
                                    dbg('Extgbl Ref After Assigning : ' ||
                                        p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(i)
                                        .reference_no);
                              END LOOP;
                        END IF;
                        --FCUBS12.0.1.7CITIDDA REL2 Vol<3> Tag <5> #ITR1 SFR#6 Ends                  
                  
                        l_count := p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl.COUNT;
                        FORALL l_index IN 1 .. l_count
                              INSERT INTO detbs_jrnl_txn_detl_extgbl
                              VALUES p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl
                                    (l_index);
                  
                  EXCEPTION
                        WHEN OTHERS THEN
                              dbg('Failed In Insert intoDETBS_JRNL_TXN_DETL_EXTGBL..');
                              dbg(SQLERRM);
                              p_err_code   := 'ST-UPLD-001';
                              p_err_params := '@DETBS_JRNL_TXN_DETL_EXTGBL';
                              RETURN FALSE;
                  END;
            ELSIF p_action_code = cspks_req_global.p_modify
            THEN
            
                  dbg('Preapring Insert and Update Types for  DETBS_JRNL_TXN_DETL_EXTGBL..');
                  l_count := 0;
            
            
                  OPEN v_extgbl;
                  FETCH v_extgbl BULK COLLECT
                        INTO l_tab_ty_txn_det_extgbl;
                  CLOSE v_extgbl;
            
            
                  l_wrk_count  := p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl.COUNT;
                  l_prev_count := l_tab_ty_txn_det_extgbl.COUNT;
                  dbg('value of l_Prev_Count ' || l_prev_count);
            
                  IF l_wrk_count > 0
                  THEN
                        FOR l_index IN 1 .. l_wrk_count
                        LOOP
                              l_rec_found := FALSE;
                              IF l_prev_count > 0
                              THEN
                                    FOR l_index1 IN 1 .. l_prev_count
                                    LOOP
                                          IF (nvl(p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(l_index)
                                                  .serial_no, -1) =
                                             nvl(l_tab_ty_txn_det_extgbl(l_index1)
                                                  .serial_no, -1))
                                          THEN
                                                dbg('Record Has Been Found.Update Case..');
                                                l_rec_found := TRUE;
                                                EXIT;
                                          END IF;
                                    END LOOP;
                              END IF;
                              IF l_rec_found
                              THEN
                                    dbg('Record is Modified...');
                                    u_v_jrnl_txn_detail_extgbl(u_v_jrnl_txn_detail_extgbl.COUNT + 1) := p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(l_index);
                              ELSE
                                    dbg('Record is Added...');
                                    i_v_jrnl_txn_detail_extgbl(i_v_jrnl_txn_detail_extgbl.COUNT + 1) := p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(l_index);
                              END IF;
                        END LOOP;
                  END IF;
            
                  dbg('Preapring Delete Types for  DETBS_JRNL_TXN_DETL_EXTGBL..');
                  l_wrk_count  := p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl.COUNT;
                  l_prev_count := l_tab_ty_txn_det_extgbl.COUNT;
            
                  IF l_prev_count > 0
                  THEN
                        FOR l_index1 IN 1 .. l_prev_count
                        LOOP
                              l_rec_found := FALSE;
                              IF l_wrk_count > 0
                              THEN
                                    FOR l_index IN 1 .. l_wrk_count
                                    LOOP
                                          IF (nvl(p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(l_index)
                                                  .serial_no, -1) =
                                             nvl(l_tab_ty_txn_det_extgbl(l_index1)
                                                  .serial_no, -1))
                                          THEN
                                                dbg('Record Has Been Found.Update Case..');
                                                l_rec_found := TRUE;
                                                EXIT;
                                          END IF;
                                    END LOOP;
                              END IF;
                              IF NOT l_rec_found
                              THEN
                                    dbg('Record is Deleted...');
                                    d_v_jrnl_txn_detail_extgbl(d_v_jrnl_txn_detail_extgbl.COUNT + 1) := l_tab_ty_txn_det_extgbl(l_index1);
                              END IF;
                        END LOOP;
                  END IF;
                  l_del_count := d_v_jrnl_txn_detail_extgbl.COUNT;
                  dbg('Records Deleted  :' || l_del_count);
                  IF l_del_count > 0
                  THEN
                        FOR l_index IN 1 .. l_del_count
                        LOOP
                              dbg('Deleting Record...');
                              DELETE detbs_jrnl_txn_detl_extgbl
                              WHERE  reference_no =
                                     d_v_jrnl_txn_detail_extgbl(l_index)
                              .reference_no
                                     AND
                                     serial_no =
                                     d_v_jrnl_txn_detail_extgbl(l_index)
                              .serial_no;
                        END LOOP;
                  END IF;
                  l_ins_count := i_v_jrnl_txn_detail_extgbl.COUNT;
                  dbg('New Records Added  :' || l_ins_count);
                  BEGIN
                        l_count := i_v_jrnl_txn_detail_extgbl.COUNT;
                        FORALL l_index IN 1 .. l_count
                              INSERT INTO detbs_jrnl_txn_detl_extgbl
                              VALUES i_v_jrnl_txn_detail_extgbl
                                    (l_index);
                  EXCEPTION
                        WHEN OTHERS THEN
                              dbg('Failed in Insert IntoDETBS_JRNL_TXN_DETL_EXTGBL..');
                              dbg(SQLERRM);
                              p_err_code   := 'ST-UPLD-001';
                              p_err_params := '@DETBS_JRNL_TXN_DETL_EXTGBL';
                              RETURN FALSE;
                  END;
                  l_upd_count := u_v_jrnl_txn_detail_extgbl.COUNT;
                  dbg('Records Modified  :' || l_upd_count);
                  IF l_upd_count > 0
                  THEN
                        FOR l_index IN 1 .. l_upd_count
                        LOOP
                              dbg('Updating The  Record...');
                              BEGIN
                                    UPDATE detbs_jrnl_txn_detl_extgbl
                                    SET    internal_remarks = u_v_jrnl_txn_detail_extgbl(l_index)
                                                             .internal_remarks
                                    WHERE  reference_no =
                                           u_v_jrnl_txn_detail_extgbl(l_index)
                                    .reference_no
                                           AND
                                           serial_no =
                                           u_v_jrnl_txn_detail_extgbl(l_index)
                                    .serial_no;
                              EXCEPTION
                                    WHEN OTHERS THEN
                                          dbg('Failed in Updating DETBS_JRNL_TXN_DETL_EXTGBL..');
                                          dbg(SQLERRM);
                                          p_err_code   := 'ST-UPLD-001';
                                          p_err_params := '@DETBS_JRNL_TXN_DETL_EXTGBL';
                                          RETURN FALSE;
                              END;
                        END LOOP;
                  END IF;
      --artf264299 retro starts
            END IF;
            --CITI_FC12_R5_SUPP SIT1 SFR#919 ends
            
            dbg('Returning Success From Fn_Pre_Upload_Db..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Pre_Upload_Db ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_upload_db;

      FUNCTION fn_post_upload_db
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_child_function   IN VARCHAR2
           ,p_multi_trip_id    IN VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_prev_dedjnlon    IN depks_dedjnlon_main.ty_dedjnlon
           ,p_wrk_dedjnlon     IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 STARTS
            l_count             NUMBER := 0;
            l_ins_count         NUMBER := 0;
            l_upd_count         NUMBER := 0;
            l_del_count         NUMBER := 0;
            l_wrk_count         NUMBER := 0;
            l_prev_count        NUMBER := 0;
            l_rec_found         BOOLEAN := FALSE;
            l_row_id            ROWID;
            l_key               VARCHAR2(5000) := NULL;
            l_auth_stat         VARCHAR2(1) := 'A';
            l_base_data_from_fc VARCHAR2(1) := 'Y';
      
            i_v_jrnl_txn_detail_extgbl depks_dedjnlon_main.ty_tb_v_jrnl_txn_detl_extgbl;
            u_v_jrnl_txn_detail_extgbl depks_dedjnlon_main.ty_tb_v_jrnl_txn_detl_extgbl;
            d_v_jrnl_txn_detail_extgbl depks_dedjnlon_main.ty_tb_v_jrnl_txn_detl_extgbl;
      
            TYPE ty_tb_l_jrnl_txn_detail_extgbl IS TABLE OF detbs_jrnl_txn_detl_extgbl%ROWTYPE INDEX BY BINARY_INTEGER;
            l_tab_ty_txn_det_extgbl ty_tb_l_jrnl_txn_detail_extgbl;
      
            CURSOR v_extgbl IS
                  SELECT *
                  FROM   detbs_jrnl_txn_detl_extgbl
                  WHERE  reference_no =
                         p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 ENDS
      
            --FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#292 starts
            l_internal_remarks actbs_recon_details_extgbl.internal_remarks%TYPE;
            l_external_remarks actbs_recon_details_extgbl.internal_remarks%TYPE;
      
            CURSOR v_recon_master IS
                  SELECT *
                  FROM   actbs_recon_master
                  WHERE  branch =
                         p_wrk_dedjnlon.v_detbs_jrnl_txn_master.branch_code
                         AND
                         ref_no =
                         p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no;
      
            CURSOR v_recon_details(p_branch VARCHAR2, p_account VARCHAR2, p_ccy VARCHAR2, p_reconno VARCHAR2, p_refno VARCHAR2) IS
                  SELECT *
                  FROM   actbs_recon_details
                  WHERE  branch = p_branch
                         AND account = p_account
                         AND ccy = p_ccy
                         AND reconno = p_reconno
                         AND ref_no = p_refno;
            --FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#292 ends    
      
            --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes for updating iftbs_otat_details_extgbl status on Del strts
            l_ot_at_tk_ref iftbs_otat_details_extgbl.otat_tkt_ref%TYPE;
            l_rej_code     NUMBER := 1;
            l_called_from  VARCHAR2(10) := 'AUTHORIZE';
            l_action_code  VARCHAR2(5) := 'D';
            l_auth_id      VARCHAR2(10) := global.user_id;
            l_otat_status  iftbs_otat_details_extgbl.status%TYPE;
            l_msg          VARCHAR2(500);
            --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends
      
      BEGIN
      
            dbg('In Fn_Post_Upload_Db..');
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 STARTS
            --CITI_FC12_R5_SUPP SIT1 SFR#919 commenting starts - Moved code to fn_pre_upload_db
            /*IF p_action_code = cspks_req_global.p_new
            THEN
            
                  dbg('Inserting Into DETBS_JRNL_TXN_DETL_EXTGBL..');
                  BEGIN
                        --FCUBS12.0.1.7CITIDDA REL2 Vol<3> Tag <5> #ITR1 SFR#6  Starts
                        IF p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no IS NOT NULL
                        THEN
                              FOR i IN 1 .. p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl.COUNT
                              LOOP
                                    dbg('Extgbl Ref Before Assigning : ' ||
                                        p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(i)
                                        .reference_no);
                                    p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(i).reference_no := nvl(p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(i)
                                                                                                 .reference_no,
                                                                                                 p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no);
                                    dbg('Extgbl Ref After Assigning : ' ||
                                        p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(i)
                                        .reference_no);
                              END LOOP;
                        END IF;
                        --FCUBS12.0.1.7CITIDDA REL2 Vol<3> Tag <5> #ITR1 SFR#6 Ends                  
                  
                        l_count := p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl.COUNT;
                        FORALL l_index IN 1 .. l_count
                              INSERT INTO detbs_jrnl_txn_detl_extgbl
                              VALUES p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl
                                    (l_index);
                  
                  EXCEPTION
                        WHEN OTHERS THEN
                              dbg('Failed In Insert intoDETBS_JRNL_TXN_DETL_EXTGBL..');
                              dbg(SQLERRM);
                              p_err_code   := 'ST-UPLD-001';
                              p_err_params := '@DETBS_JRNL_TXN_DETL_EXTGBL';
                              RETURN FALSE;
                  END;
            ELSIF p_action_code = cspks_req_global.p_modify
            THEN
            
                  dbg('Preapring Insert and Update Types for  DETBS_JRNL_TXN_DETL_EXTGBL..');
                  l_count := 0;
            
            
                  OPEN v_extgbl;
                  FETCH v_extgbl BULK COLLECT
                        INTO l_tab_ty_txn_det_extgbl;
                  CLOSE v_extgbl;
            
            
                  l_wrk_count  := p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl.COUNT;
                  l_prev_count := l_tab_ty_txn_det_extgbl.COUNT;
                  dbg('value of l_Prev_Count ' || l_prev_count);
            
                  IF l_wrk_count > 0
                  THEN
                        FOR l_index IN 1 .. l_wrk_count
                        LOOP
                              l_rec_found := FALSE;
                              IF l_prev_count > 0
                              THEN
                                    FOR l_index1 IN 1 .. l_prev_count
                                    LOOP
                                          IF (nvl(p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(l_index)
                                                  .serial_no, -1) =
                                             nvl(l_tab_ty_txn_det_extgbl(l_index1)
                                                  .serial_no, -1))
                                          THEN
                                                dbg('Record Has Been Found.Update Case..');
                                                l_rec_found := TRUE;
                                                EXIT;
                                          END IF;
                                    END LOOP;
                              END IF;
                              IF l_rec_found
                              THEN
                                    dbg('Record is Modified...');
                                    u_v_jrnl_txn_detail_extgbl(u_v_jrnl_txn_detail_extgbl.COUNT + 1) := p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(l_index);
                              ELSE
                                    dbg('Record is Added...');
                                    i_v_jrnl_txn_detail_extgbl(i_v_jrnl_txn_detail_extgbl.COUNT + 1) := p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(l_index);
                              END IF;
                        END LOOP;
                  END IF;
            
                  dbg('Preapring Delete Types for  DETBS_JRNL_TXN_DETL_EXTGBL..');
                  l_wrk_count  := p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl.COUNT;
                  l_prev_count := l_tab_ty_txn_det_extgbl.COUNT;
            
                  IF l_prev_count > 0
                  THEN
                        FOR l_index1 IN 1 .. l_prev_count
                        LOOP
                              l_rec_found := FALSE;
                              IF l_wrk_count > 0
                              THEN
                                    FOR l_index IN 1 .. l_wrk_count
                                    LOOP
                                          IF (nvl(p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(l_index)
                                                  .serial_no, -1) =
                                             nvl(l_tab_ty_txn_det_extgbl(l_index1)
                                                  .serial_no, -1))
                                          THEN
                                                dbg('Record Has Been Found.Update Case..');
                                                l_rec_found := TRUE;
                                                EXIT;
                                          END IF;
                                    END LOOP;
                              END IF;
                              IF NOT l_rec_found
                              THEN
                                    dbg('Record is Deleted...');
                                    d_v_jrnl_txn_detail_extgbl(d_v_jrnl_txn_detail_extgbl.COUNT + 1) := l_tab_ty_txn_det_extgbl(l_index1);
                              END IF;
                        END LOOP;
                  END IF;
                  l_del_count := d_v_jrnl_txn_detail_extgbl.COUNT;
                  dbg('Records Deleted  :' || l_del_count);
                  IF l_del_count > 0
                  THEN
                        FOR l_index IN 1 .. l_del_count
                        LOOP
                              dbg('Deleting Record...');
                              DELETE detbs_jrnl_txn_detl_extgbl
                              WHERE  reference_no =
                                     d_v_jrnl_txn_detail_extgbl(l_index)
                              .reference_no
                                     AND
                                     serial_no =
                                     d_v_jrnl_txn_detail_extgbl(l_index)
                              .serial_no;
                        END LOOP;
                  END IF;
                  l_ins_count := i_v_jrnl_txn_detail_extgbl.COUNT;
                  dbg('New Records Added  :' || l_ins_count);
                  BEGIN
                        l_count := i_v_jrnl_txn_detail_extgbl.COUNT;
                        FORALL l_index IN 1 .. l_count
                              INSERT INTO detbs_jrnl_txn_detl_extgbl
                              VALUES i_v_jrnl_txn_detail_extgbl
                                    (l_index);
                  EXCEPTION
                        WHEN OTHERS THEN
                              dbg('Failed in Insert IntoDETBS_JRNL_TXN_DETL_EXTGBL..');
                              dbg(SQLERRM);
                              p_err_code   := 'ST-UPLD-001';
                              p_err_params := '@DETBS_JRNL_TXN_DETL_EXTGBL';
                              RETURN FALSE;
                  END;
                  l_upd_count := u_v_jrnl_txn_detail_extgbl.COUNT;
                  dbg('Records Modified  :' || l_upd_count);
                  IF l_upd_count > 0
                  THEN
                        FOR l_index IN 1 .. l_upd_count
                        LOOP
                              dbg('Updating The  Record...');
                              BEGIN
                                    UPDATE detbs_jrnl_txn_detl_extgbl
                                    SET    internal_remarks = u_v_jrnl_txn_detail_extgbl(l_index)
                                                             .internal_remarks
                                    WHERE  reference_no =
                                           u_v_jrnl_txn_detail_extgbl(l_index)
                                    .reference_no
                                           AND
                                           serial_no =
                                           u_v_jrnl_txn_detail_extgbl(l_index)
                                    .serial_no;
                              EXCEPTION
                                    WHEN OTHERS THEN
                                          dbg('Failed in Updating DETBS_JRNL_TXN_DETL_EXTGBL..');
                                          dbg(SQLERRM);
                                          p_err_code   := 'ST-UPLD-001';
                                          p_err_params := '@DETBS_JRNL_TXN_DETL_EXTGBL';
                                          RETURN FALSE;
                              END;
                        END LOOP;
                  END IF;
            ELSIF p_action_code = cspks_req_global.p_delete
            */--CITI_FC12_R5_SUPP SIT1 SFR#919 commenting ends
      --artf264299 retro ends
            IF p_action_code = cspks_req_global.p_delete --CITI_FC12_R5_SUPP SIT1 SFR#919 added
            THEN
                  dbg('Action Code ' || p_action_code);
                  dbg('Deleting The Data..');
            
            
                  DELETE detbs_jrnl_txn_detl_extgbl
                  WHERE  reference_no =
                         p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no;
            
                  --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes strts
            
                  BEGIN
                        SELECT otat_tkt_ref
                              ,status
                        INTO   l_ot_at_tk_ref
                              ,l_otat_status
                        FROM   iftbs_otat_details_extgbl
                        WHERE  external_ref_no =
                               p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no
                               AND status <> 'D';
                  EXCEPTION
                        WHEN no_data_found THEN
                              debug.pr_debug('IF',
                                             'Record not found in iftbs_otat_details_extgbl');
                              l_ot_at_tk_ref := NULL;
                              l_otat_status  := NULL;
                        WHEN OTHERS THEN
                              dbg('In WOT..' || SQLERRM);
                              l_otat_status  := NULL;
                              l_ot_at_tk_ref := NULL;
                  END;
            
                  IF l_otat_status = 'P'
                  THEN
                                            --FCUBS12.0.1.7CITIDDA Rel4 ECA Code Review Changes start
                                            -- fn_ot_appr_reject function has moved to ifpks_eca_extgbl package.                  
                        /*IF NOT
                            ifpks_otat_gen_extgbl.fn_ot_appr_reject(l_ot_at_tk_ref,
                                                                    l_action_code,
                                                                    l_rej_code,
                                                                    p_err_params,
                                                                    l_auth_id,
                                                                    l_called_from,
                                                                    p_err_code,
                                                                    p_err_params)
                        THEN
                              dbg('Failed while updating the OT tickets ' ||
                                  l_ot_at_tk_ref || '~' ||
                                  p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no);
                              p_err_code   := 'IFACPOST064';
                              p_err_params := SQLERRM;
                              ovpkss.pr_appendtbl(p_err_code, p_err_params);
                              RETURN FALSE;
                        END IF;*/
                        IF NOT
                              ifpks_eca_extgbl.fn_ot_appr_reject(l_ot_at_tk_ref,
                                          l_action_code,
                                          l_rej_code,
                                          p_err_params,
                                          l_auth_id,
                                          l_called_from,
                                          p_err_code,
                                          p_err_params)
                        THEN
                                  dbg('Failed while updating the OT tickets ' ||
                                        l_ot_at_tk_ref || '~' ||
                                        p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no);
                                  p_err_code   := 'IFACPOST064';
                                  p_err_params := SQLERRM;
                                  ovpkss.pr_appendtbl(p_err_code, p_err_params);
                                  RETURN FALSE;
                        END IF;
                        --FCUBS12.0.1.7CITIDDA Rel4 ECA Code Review Changes End                        
                  END IF;
            
                  --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends                         
            
            END IF;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 ENDS
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 STARTS
            dbg('p_Action_Code ' || p_action_code);
            IF p_action_code = 'NEW'
            THEN
            
                  FOR i IN 1 .. p_wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT
                  LOOP
                        INSERT INTO cstbs_ui_columns
                        VALUES p_wrk_dedjnlon.v_cstbs_ui_columns__alias
                              (i);
                        dbg('VALUE OF I ' || i || '~' || SQL%ROWCOUNT);
                  END LOOP;
            END IF;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 ENDS
      
            --FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#292 starts
      
            IF p_action_code = cspks_req_global.p_new
            THEN
                  dbg('recon entry started');
            
                  FOR i IN v_recon_master
                  LOOP
                        FOR j IN 1 .. p_wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT
                        LOOP
                              IF i.ref_no =
                                 p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(j)
                              .reference_no AND
                                 i.branch =
                                 p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(j)
                              .branch_code AND
                                 i.account =
                                 p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(j)
                              .ac_gl_no AND
                                 i.ccy =
                                 p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(j).ccy
                              THEN
                              
                                    FOR k IN 1 .. p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl.COUNT
                                    LOOP
                                          IF p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(k)
                                          .reference_no =
                                             p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(j)
                                          .reference_no AND
                                             p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(k)
                                          .serial_no =
                                             p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(j)
                                          .serial_no
                                          THEN
                                                l_internal_remarks := p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(k)
                                                                     .internal_remarks;
                                          END IF;
                                    END LOOP;
                              
                                    INSERT INTO actbs_recon_master_extgbl
                                          (branch
                                          ,account
                                          ,reconno
                                          ,ccy
                                          ,internal_remarks
                                          ,external_remarks)
                                    VALUES
                                          (i.branch
                                          ,i.account
                                          ,i.reconno
                                          ,i.ccy
                                          ,l_internal_remarks
                                          , p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(j)
                                           .addl_text);
                              
                              END IF;
                        END LOOP;
                  END LOOP;
            
                  FOR i IN v_recon_master
                  LOOP
                        FOR j IN v_recon_details(i.branch, i.account, i.ccy,
                                                 i.reconno, i.ref_no)
                        LOOP
                              FOR k IN 1 .. p_wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT
                              LOOP
                                    IF p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(k)
                                    .serial_no = j.serno
                                    THEN
                                          l_external_remarks := p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(k)
                                                               .addl_text;
                                    
                                          FOR m IN 1 .. p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl.COUNT
                                          LOOP
                                                IF p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(k)
                                                .reference_no =
                                                   p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(m)
                                                .reference_no AND
                                                   p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(k)
                                                .serial_no =
                                                   p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(m)
                                                .serial_no
                                                THEN
                                                      l_internal_remarks := p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl(m)
                                                                           .internal_remarks;
                                                END IF;
                                          END LOOP;
                                    END IF;
                              END LOOP;
                              INSERT INTO actb_recon_details_extgbl
                                    (branch
                                    ,account
                                    ,ccy
                                    ,serno
                                    ,reconno
                                    ,ref_no
                                    ,event_seq_no
                                    ,amount
                                    ,external_remarks
                                    ,internal_remarks)
                              VALUES
                                    (j.branch
                                    ,j.account
                                    ,j.ccy
                                    ,j.serno
                                    ,j.reconno
                                    ,j.ref_no
                                    ,j.event_seq_no
                                    ,j.amount
                                    ,l_external_remarks
                                    ,l_internal_remarks);
                        END LOOP;
                  END LOOP;
            END IF;
      
            --FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#292 ends
      
            dbg('Returning Success From Fn_Post_Upload_Db..');
      
      
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Post_Upload_Db ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_upload_db;

      FUNCTION fn_pre_process
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_child_function   IN VARCHAR2
           ,p_multi_trip_id    IN VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_prev_dedjnlon    IN depks_dedjnlon_main.ty_dedjnlon
           ,p_wrk_dedjnlon     IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
      BEGIN
      
            dbg('In Fn_Pre_Process..');
      
            dbg('Returning Success From Fn_Pre_Process..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Pre_Process ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_process;

      FUNCTION fn_post_process
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_child_function   IN VARCHAR2
           ,p_multi_trip_id    IN VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_prev_dedjnlon    IN depks_dedjnlon_main.ty_dedjnlon
           ,p_wrk_dedjnlon     IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
           l_account_class sttm_cust_account.account_class%type;    -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes
      BEGIN
      
            dbg('In Fn_Post_Process..');
                -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Starts
                for indx in 1 .. P_DEDJNLON.v_detbs_jrnl_txn_detail.COUNT loop
                  BEGIN
              DBG('P_DEDJNLON.v_detbs_jrnl_txn_detail(indx).cust_ac_no : ' || P_DEDJNLON.v_detbs_jrnl_txn_detail(indx)
                  .ac_gl_no);
              select account_Class
                into l_account_class
                from sttm_cust_Account a
               where cust_Ac_no = P_DEDJNLON.v_detbs_jrnl_txn_detail(indx).ac_gl_no
                    and a.branch_code = P_DEDJNLON.v_detbs_jrnl_txn_detail(indx).branch_code
                    and record_stat = 'O' and auth_stat = 'A'
                    and exists (select 1 from sttb_account b where ac_or_gl = 'A' and b.ac_gl_no = a.cust_ac_no);

              dbg('Account Class : ' || l_account_Class);
              
              IF instr(cvpks_utils_extgbl.fn_get_param_value('GWPAGEE_ACCCLASS_LST'),
                     l_Account_class) > 0  and P_DEDJNLON.v_detbs_jrnl_txn_detail(indx).dr_cr = 'D' 
                     
                     THEN
			BEGIN
			      insert into DETBS_RESERVE_DTL_EXTGBL
				(SYSTEM_ID,
				 DATETIMESTAMP,
				 MSG_REG,
				 MSG_TYPE,
				 ACCOUNT,
				 REFERENCE_NO,
				 VALUE_DT,
				 AMOUNT,
				 RESPONSE)
			      values
				('102',
				 to_char(sysdate,'YYYYMMDDHHMISS'),
				 '0',
				 'INT1002',
				 P_DEDJNLON.v_detbs_jrnl_txn_detail(indx).ac_gl_no,
				 P_DEDJNLON.v_detbs_jrnl_txn_detail(indx).reference_no,
				 to_char(global.application_date,'YYYYMMDDHHMISS'),
				 P_DEDJNLON.v_detbs_jrnl_txn_detail(indx).amount,
				 null);
			      dbg('Inserted to DE ECA Table ');

		exception
			when dup_val_on_index then
				dbg('Record Already inserted... Ignoring...');		
			when others then
				dbg('Failed in Insert or update...'||sqlerrm);	
		end;
	END IF;		
              commit;
              
                  EXCEPTION
              WHEN Others THEn
                dbg('Account Class Not Found ' || sqlerrm);
                  END;


                END LOOP;
                
                -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Ends
      
            dbg('Returning Success From Fn_Post_Process..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Post_Process ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_process;

      FUNCTION fn_pre_query
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_child_function   IN VARCHAR2
           ,p_full_data        IN VARCHAR2 DEFAULT 'Y'
           ,p_with_lock        IN VARCHAR2 DEFAULT 'N'
           ,p_qrydata_reqd     IN VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_wrk_dedjnlon     IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
      BEGIN
      
            dbg('In Fn_Pre_Query..');
      
            dbg('Returning Success From Fn_Pre_Query..');
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Pre_Query ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_pre_query;

      FUNCTION fn_post_query
      (
            p_source           IN VARCHAR2
           ,p_source_operation IN VARCHAR2
           ,p_function_id      IN VARCHAR2
           ,p_action_code      IN VARCHAR2
           ,p_child_function   IN VARCHAR2
           ,p_full_data        IN VARCHAR2 DEFAULT 'Y'
           ,p_with_lock        IN VARCHAR2 DEFAULT 'N'
           ,p_qrydata_reqd     IN VARCHAR2
           ,p_dedjnlon         IN depks_dedjnlon_main.ty_dedjnlon
           ,p_wrk_dedjnlon     IN OUT depks_dedjnlon_main.ty_dedjnlon
           ,p_err_code         IN OUT VARCHAR2
           ,p_err_params       IN OUT VARCHAR2
      ) RETURN BOOLEAN IS
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 STARTS
            CURSOR c_v_jrnl_txn_detail_extgbl IS
                  SELECT *
                  FROM   detbs_jrnl_txn_detl_extgbl
                  WHERE  reference_no =
                         p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 ENDS
            l_name VARCHAR2(20);






            L_UDF_REC CSTMS_CONTRACT_USERDEF_FIELDS%ROWTYPE;--artf257638-1
      BEGIN
      
            dbg('In Fn_Post_Query');
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 STARTS
            IF p_action_code = 'EXECUTEQUERY'
            THEN
                  --FCUBS12.0.0.1CITI IUT3 SFR# 14 - Internal remarks data is getting deleted automatically
                  OPEN c_v_jrnl_txn_detail_extgbl;
                  LOOP
                        FETCH c_v_jrnl_txn_detail_extgbl BULK COLLECT
                              INTO p_wrk_dedjnlon.v_jrnl_txn_detl_extgbl;
                        EXIT WHEN c_v_jrnl_txn_detail_extgbl%NOTFOUND;
                  END LOOP;
                  CLOSE c_v_jrnl_txn_detail_extgbl;
                  dbg('Returning Success From Fn_Post_Query..');
            END IF; --FCUBS12.0.0.1CITI IUT3 SFR# 14 - Internal remarks data is getting deleted automatically
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 ENDS
      
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 STARTS
            dbg('In Fn_Post_Query');
            dbg('p_Wrk_dedjnlon.v_detbs_jrnl_txn_master.REFERENCE_NO ' ||
                p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no);
            dbg('P_ACTION_CODE ' || p_action_code);
            IF p_action_code = 'EXECUTEQUERY'
            THEN
                  BEGIN
                        FOR i IN 1 .. p_wrk_dedjnlon.v_detbs_jrnl_txn_detail.COUNT
                        LOOP
                        
                              SELECT char_field31
                              INTO   l_name
                              FROM   cstbs_ui_columns
                              WHERE  char_field1 =
                                     p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no
                              AND    num_field15 = p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i).serial_no;--artf255142_QC4060 added
                        
                        
                              p_wrk_dedjnlon.v_cstbs_ui_columns__alias(i).char_field1 := nvl(p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                                                                                             .reference_no,
                                                                                             p_wrk_dedjnlon.v_detbs_jrnl_txn_master.reference_no);
                              p_wrk_dedjnlon.v_cstbs_ui_columns__alias(i).num_field15 := p_wrk_dedjnlon.v_detbs_jrnl_txn_detail(i)
                                                                                        .serial_no;
                              p_wrk_dedjnlon.v_cstbs_ui_columns__alias(i).char_field31 := l_name;
                        
                              dbg('p_Wrk_dedjnlon.v_CSTBS_UI_COLUMNS__ALIAS(I).CHAR_FIELD31 ' ||
                                  p_wrk_dedjnlon.v_cstbs_ui_columns__alias(i)
                                  .char_field31);
                        END LOOP;
                  EXCEPTION
                        WHEN OTHERS THEN
                              dbg('IN WHEN OTHERS ' || SQLERRM);
                  END;
            END IF;
            --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 ENDS
            --artf257638 Starts
            IF NOT STPKS_CASH_UTILS.FN_QUERY_CONT_UDFDETAILS(P_FUNCTION_ID,
                                                         P_WRK_DEDJNLON.v_detbs_jrnl_txn_master.REFERENCE_NO,
                                                         NULL,
                                                         L_UDF_REC,
                                                         p_wrk_dedjnlon,
                                                         P_ERR_CODE,
                                                         P_ERR_PARAMS) THEN
      DBG('Failed in Fn_Query_Cont_Udfdetails..');
      RETURN FALSE;
    END IF;
  --artf257638
    IF P_ACTION_CODE IN ('AMT_COMP','DEFLTTEMP') THEN
      P_WRK_DEDJNLON.TXN_UDF_DETAILS := P_DEDJNLON.TXN_UDF_DETAILS;
    END IF;
    --artf257638
            --artf257638 Ends
            dbg('Returning Success From Fn_Post_Query..'||P_WRK_DEDJNLON.TXN_UDF_DETAILS.COUNT);
            RETURN TRUE;
      EXCEPTION
            WHEN OTHERS THEN
                  debug.pr_debug('**',
                                 'In When Others of depks_dedjnlon_Custom.Fn_Post_Query ..');
                  debug.pr_debug('**', SQLERRM);
                  p_err_code   := 'ST-OTHR-001';
                  p_err_params := NULL;
                  RETURN FALSE;
      END fn_post_query;


END depks_dedjnlon_custom;
/