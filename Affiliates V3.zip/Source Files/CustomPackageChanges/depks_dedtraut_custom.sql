CREATE OR REPLACE PACKAGE BODY depks_dedtraut_custom AS
            /*-----------------------------------------------------------------------------------------------------
      **
      ** File Name  : depks_dedtraut_custom.sql
      **
      ** Module     : Data Entry
      **
      ** This source is part of the Oracle FLEXCUBE Software Product.
      ** Copyright � 2007,2013 , Oracle and/or its affiliates.  All rights reserved
      **
      **
      ** No part of this work may be reproduced, stored in a retrieval system, adopted..
      ** or transmitted in any form or by any means, electronic, mechanical,
      ** photographic, graphic, optic recording or otherwise, translated in any
      ** language or computer language, without the prior written permission of
      ** Oracle and/or its affiliates.
      **
      ** Oracle Financial Services Software Limited.
      ** Oracle Park, Off Western Express Highway,
      ** Goregaon (East),
      ** Mumbai - 400 063, India
      ** India
      -------------------------------------------------------------------------------------------------------
      CHANGE HISTORY
      SFR Number         :  FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes
      Changed By          :  Ankur Omar
      Change Description :  User profile level Input and Authorization Limit setup
      Search String :       FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6
      
     ** Modified By     : Asha G R
     ** Modified Date       : 10-Aug-2013
     ** Modification reason     : Manual Posting for Journal entries
     ** Search String       : FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5         
     
     ** Modified By     : Asha G R
     ** Modified Date       : 10-Aug-2013
     ** Modification reason     : Manual Posting for Journal entries
     ** Search String       : FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 SFR 145
     
        ** Modified By      : Asha G R
        ** Modified Date    : 15-Oct-2013
        ** Modification reason  : Override msg appearing evn though its authorised 
        ** Search String    :FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5    ITR sfr#98 and 88  changes   
     
     ** Modfied By           : Santosh Kumar Savanur
     ** Modified On          : 06-FEB-2014
     ** Modified Reason      : Account Hierarchy Changes
     ** Search String        : FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5

     ** Modfied By           : Raghu Viswanath
     ** Modified On          : 25-FEB-2014
     ** Modified Reason      : Exception Handling Changes
     ** Search String        : FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5 UT
     
    Modfied By              : Anjani
    Modified On             : 25 APR 2014
    Modified Reason         : Changes done for changing the referenced package ifpks_otat_gen_extgbl to ifpks_eca_extgbl 
    Search String           : FCUBS12.0.1.7CITIDDA Rel4 ECA Code Review Changes

    Modified By         : Nagaraja Pillari
    Modified On         : 11-Aug-2016
    Modified Reason     : Changes done to allow the DE auth trnasactions irrespective of ECA status.
    Search String       : CITI_FC12_R5_SUPP SIT1 SFR#797             
      
  ** Modfied By           : Debasish
  ** Modified On          : 15 FEB 2018
  ** Modified Reason      : Changes done as part of "Affiliates V3" to validate "Reserve for Account before Authorisation" 
  ** Search String        : FCUBS12.0.1.7CITIDDA Affiliates V3 Changes      
      -------------------------------------------------------------------------------------------------------
      */


            PROCEDURE dbg(p_msg VARCHAR2) IS
                        l_msg VARCHAR2(32767);
            BEGIN
                        l_msg := 'depks_dedtraut_Custom ==>' || p_msg;
                        debug.pr_debug('DE', l_msg);
            END dbg;

            PROCEDURE pr_log_error
            (
                        p_function_id IN VARCHAR2
                     ,p_source      VARCHAR2
                     ,p_err_code    VARCHAR2
                     ,p_err_params  VARCHAR2
            ) IS
            BEGIN
                        cspks_req_utils.pr_log_error(p_source
                                                                                ,p_function_id
                                                                                ,p_err_code
                                                                                ,p_err_params);
            END pr_log_error;
            PROCEDURE pr_skip_handler(p_stage IN VARCHAR2) IS
            BEGIN
                        dbg('In Pr_Skip_Handler..');
            END pr_skip_handler;
            FUNCTION fn_post_build_type_structure
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_child_function   IN VARCHAR2
                     ,p_addl_info        IN cspks_req_global.ty_addl_info
                     ,p_dedtraut         IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            BEGIN
            
                        dbg('In Fn_Post_Build_Type_Structure..');
            
                        dbg('Returning Success From Fn_Post_Build_Type_Structure..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Post_Build_Type_Structure ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_post_build_type_structure;

            FUNCTION fn_pre_check_mandatory
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_child_function   IN VARCHAR2
                     ,p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL'
                     ,p_dedtraut         IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN
            
             IS
            BEGIN
            
                        dbg('In Fn_Pre_Check_Mandatory..');
            
                        dbg('Returning  Success From Fn_Pre_Check_Mandatory..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Pre_Check_Mandatory ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_pre_check_mandatory;

            FUNCTION fn_post_check_mandatory
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_child_function   IN VARCHAR2
                     ,p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL'
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN
            
             IS
            BEGIN
            
                        dbg('In Fn_Post_Check_Mandatory..');
            
                        dbg('Returning Success From Fn_Post_Check_Mandatory..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Post_Check_Mandatory ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_post_check_mandatory;

            FUNCTION fn_pre_default_and_validate
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_child_function   IN VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_prev_dedtraut    IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_wrk_dedtraut     IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            BEGIN
            
                        dbg('In Fn_Pre_Default_And_Validate..');
            
                        smpks.g_tb_cluster_data('MODULE_ID') := 'DE'; ----FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth LimiT

                        -- FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5 Changes Starts
                        acpkss_acc_hierarchy_extgbl.g_consider_for_acc_hier := 'Y';
                        -- FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5 Changes Ends
                        
                        dbg('Returning Success From Fn_Pre_Default_And_Validate..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Pre_Default_And_Validate ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_pre_default_and_validate;

            FUNCTION fn_post_default_and_validate
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_child_function   IN VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_prev_dedtraut    IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_wrk_dedtraut     IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            BEGIN
            
                        dbg('In Fn_Post_Default_And_Validate..');
            
            
            
            
            
                        dbg('Returning Success From Fn_Post_Default_And_Validate');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Post_Default_And_Validate ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_post_default_and_validate;

            FUNCTION fn_pre_resolve_ref_numbers
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_dedtraut         IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            
            BEGIN
            
                        dbg('In Fn_Pre_Resolve_Ref_Numbers..');
            
                        dbg('Returning Success From Fn_Pre_Resolve_Ref_Numbers');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Main.Fn_Pre_Resolve_Ref_Numbers ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_pre_resolve_ref_numbers;
            FUNCTION fn_post_resolve_ref_numbers
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_dedtraut         IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            
            BEGIN
            
                        dbg('In Fn_Post_Resolve_Ref_Numbers..');
            
                        dbg('Returning Success From Fn_Post_Resolve_Ref_Numbers..');
                        RETURN TRUE;
            
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When others of depks_dedtraut_Main.Fn_Post_Resolve_Ref_Numbers ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_post_resolve_ref_numbers;
            FUNCTION fn_pre_product_default
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_wrk_dedtraut     IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            BEGIN
            
                        dbg('In Fn_Pre_Product_Default..');
            
                        dbg('Returning Success From Fn_Pre_Product_Default..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Pre_Product_Default ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_pre_product_default;

            FUNCTION fn_post_product_default
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_wrk_dedtraut     IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            BEGIN
            
                        dbg('In Fn_Post_Product_Default..');
            
                        dbg('Returning Success From Fn_Post_Product_Default..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Post_Product_Default ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_post_product_default;

            FUNCTION fn_pre_unlock
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN OUT VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            BEGIN
            
                        dbg('In Fn_Pre_Unlock..');
            
                        dbg('Returning Success From Fn_Pre_Unlock..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Pre_Unlock ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_pre_unlock;

            FUNCTION fn_post_unlock
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN OUT VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            BEGIN
            
                        dbg('In Fn_Post_Unlock');
            
                        dbg('Returning Success From Fn_Post_Unlock..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Post_Unlock ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_post_unlock;

            FUNCTION fn_pre_subsys_pickup
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_prev_dedtraut    IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_wrk_dedtraut     IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            BEGIN
            
                        dbg('In Fn_Pre_Subsys_Pickup..');
            
                        dbg('Returning Success From Fn_Pre_Subsys_Pickup..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Pre_Subsys_Pickup ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_pre_subsys_pickup;

            FUNCTION fn_post_subsys_pickup
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_prev_dedtraut    IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_wrk_dedtraut     IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            BEGIN
            
                        dbg('In Fn_Post_Subsys_Pickup..');
            
                        dbg('Returning Success From Fn_Post_Subsys_Pickup..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Post_Subsys_Pickup ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_post_subsys_pickup;

            FUNCTION fn_pre_enrich
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_prev_dedtraut    IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_wrk_dedtraut     IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            BEGIN
            
                        dbg('In Fn_Pre_Enrich..');
            
                        dbg('Returning Success From Fn_Pre_Enrich..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Pre_Enrich ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_pre_enrich;

            FUNCTION fn_post_enrich
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_prev_dedtraut    IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_wrk_dedtraut     IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            BEGIN
            
                        dbg('In Fn_Post_Enrich..');
            
                        dbg('Returning Success From Fn_Post_Enrich..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Post_Enrich ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_post_enrich;

            FUNCTION fn_pre_upload_db
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_child_function   IN VARCHAR2
                     ,p_multi_trip_id    IN VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_prev_dedtraut    IN depks_dedtraut_main.ty_dedtraut
                     ,p_wrk_dedtraut     IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            BEGIN
            
                        dbg('In Fn_Pre_Upload_Db..');
            
                        dbg('Returning Success From Fn_Pre_Upload_Db..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Pre_Upload_Db ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_pre_upload_db;

            FUNCTION fn_post_upload_db
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_child_function   IN VARCHAR2
                     ,p_multi_trip_id    IN VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_prev_dedtraut    IN depks_dedtraut_main.ty_dedtraut
                     ,p_wrk_dedtraut     IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
       --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes starts for change of status in iftbs_otat_details_extgbl to A on Auth              
        l_ot_at_tk_ref     iftbs_otat_details_extgbl.otat_tkt_ref%TYPE;
        l_auth_stat        VARCHAR2(1);
        l_rej_code         NUMBER := 1;
        l_called_from      VARCHAR2(10) := 'AUTHORIZE';
        l_action_code      VARCHAR2(5) :='A';
        l_auth_id          VARCHAR2(10) := global.user_id;
        l_otat_status      iftbs_otat_details_extgbl.status%TYPE;
        l_trn_branch     sttm_branch.branch_code%TYPE;
        l_sttmbrn_gbl           cvpkss_utils_extgbl.typ_sttmbrn_gbl;
        l_eca_flag         sttm_branch_extgbl.eca_flag%TYPE;
        l_acc sttm_cust_account.cust_ac_no%TYPE;
        l_count NUMBER;
    ----FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends            
            BEGIN
            
                        dbg('In Fn_Post_Upload_Db..');
                        
--FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5   changes start
  
     -- CITI_FC12_R5_SUPP SIT1 SFR#797 Starts
     -- Commented the below code and moved the same to fn_eca_appr_reject
     /*
    
    l_trn_branch:= global.current_branch;
    dbg('Calling cvpks_utils_extgbl.get_sttm_brn for getting branch level ECA flag value');
      cvpks_utils_extgbl.get_sttm_brn
    (
    l_trn_branch,
    l_sttmbrn_gbl
    );
    Dbg('ECA Flag value for the branch is: ' || l_sttmbrn_gbl.sttm_brn_extgblrec.eca_flag);
    l_eca_flag := NVL(l_sttmbrn_gbl.sttm_brn_extgblRec.eca_flag, 'N');
    
    IF l_eca_flag IN  ('F','L') 
      THEN
        BEGIN

          SELECT  count(1)
          INTO   l_count
          FROM   iftb_eca_req_dtl_extgbl
          WHERE   fcc_process_ref_no= p_wrk_dedtraut.v_detbs_jrnl_log.reference_no
          AND     original_number = p_wrk_dedtraut.v_detbs_jrnl_log.reference_no
          AND     eca_status in ('P','R')
          AND unique_txn_id=(select max(unique_txn_id) from iftb_eca_req_dtl_extgbl where fcc_process_ref_no= p_wrk_dedtraut.v_detbs_jrnl_log.reference_no
                             AND     original_number = p_wrk_dedtraut.v_detbs_jrnl_log.reference_no);


        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          dbg('Record not found in iftb_eca_req_dtl_extgbl'||SQLERRM);
            l_count := NULL;
        WHEN OTHERS THEN
          dbg('In WOT of '||SQLERRM);
            l_count := NULL;
        END;

    ELSIF l_eca_flag = 'N' 
    THEN
            BEGIN
            SELECT otat_tkt_ref,status
            INTO l_ot_at_tk_ref,l_otat_status
            FROM iftbs_otat_details_extgbl
            WHERE external_ref_no=p_wrk_dedtraut.v_detbs_jrnl_log.reference_no
            AND status <>'D';

        EXCEPTION
          WHEN NO_DATA_FOUND
          THEN
             DEBUG.pr_debug('IF','OT record not found for reference number'||p_wrk_dedtraut.v_detbs_jrnl_log.reference_no);
             l_ot_at_tk_ref:=NULL;
             l_otat_status:=NULL;
          RETURN TRUE;
        END;

    END IF;
        dbg('l_count is '||l_count);
        
        IF l_eca_flag IN  ('F','L')
        THEN
                     
          IF l_count > 0 
          THEN
          p_err_code := 'IF-ECA0005';
          p_err_params := 'ECA request pending approval,Cannot Proceed with Authorisation';
          Ovpkss.Pr_Appendtbl(p_err_code, p_err_params);
          
          END IF;
                    
        ELSIF l_eca_flag = 'N'
          THEN

            IF l_otat_status ='P' 
            then
        --FCUBS12.0.1.7CITIDDA Rel4 ECA Code Review Changes start
                /*IF NOT ifpks_otat_gen_extgbl.fn_ot_appr_reject
                            (
                            l_ot_at_tk_ref
                            ,l_action_code
                            ,l_rej_code
                            ,p_err_params
                            ,l_auth_id
                            ,l_called_from
                            ,p_err_code
                            ,p_err_params
                            )
                THEN
                  dbg('Failed while updating the OT tickets '||l_ot_at_tk_ref||'~'||p_wrk_dedtraut.v_detbs_jrnl_log.reference_no);
                  p_err_code := 'IFACPOST064';
                  p_err_params := SQLERRM;
                  Ovpkss.Pr_Appendtbl(p_err_code, p_err_params);
                  RETURN FALSE;
                END IF;*/
/*                IF NOT ifpks_eca_extgbl.fn_ot_appr_reject
                            (
                            l_ot_at_tk_ref
                            ,l_action_code
                            ,l_rej_code
                            ,p_err_params
                            ,l_auth_id
                            ,l_called_from
                            ,p_err_code
                            ,p_err_params
                            )
                THEN
                  dbg('Failed while updating the OT tickets '||l_ot_at_tk_ref||'~'||p_wrk_dedtraut.v_detbs_jrnl_log.reference_no);
                  p_err_code := 'IFACPOST064';
                  p_err_params := SQLERRM;
                  Ovpkss.Pr_Appendtbl(p_err_code, p_err_params);
                  RETURN FALSE;
                END IF;
        --FCUBS12.0.1.7CITIDDA Rel4 ECA Code Review Changes End
            END IF;

         END IF;
--FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5   changes ends                            
*/
    
     IF NOT ifpks_eca_extgbl.fn_eca_appr_reject
     (
     p_wrk_dedtraut.v_detbs_jrnl_log.reference_no
     ,l_action_code
     ,global.current_branch
     ,p_err_code
     ,p_err_params
     )
     THEN

        dbg('Failed in ifpks_eca_extgbl.fn_eca_appr_reject with '||p_err_code||'~'||p_err_params);
        dbg('Sqlerrm -->'||sqlerrm);
        RETURN FALSE;


     END IF;    
    -- CITI_FC12_R5_SUPP SIT1 SFR#797 Ends
            
                        dbg('Returning Success From Fn_Post_Upload_Db..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Post_Upload_Db ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_post_upload_db;

            FUNCTION fn_pre_process
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_child_function   IN VARCHAR2
                     ,p_multi_trip_id    IN VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_prev_dedtraut    IN depks_dedtraut_main.ty_dedtraut
                     ,p_wrk_dedtraut     IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
	-- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Starts
	function fn_chk_is_resv_avl(cont_ref_no         IN VARCHAR2)
	return CHAR
	IS
		ret CHAR(1):='Y';
	BEGIN
		dbg('Checking Reserve from GWPagee');
		select decode(response,'2','N','U','N','Y') into ret from DETB_RESERVE_DTL_EXTGBL where reference_no = cont_ref_no;
		return ret;
	exception when others 
	then
		return 'Y';
	end fn_chk_is_resv_avl;

	function fn_chk_is_resp_upd(cont_ref_no         IN VARCHAR2)
	return CHAR
	IS
		ret CHAR(1):='Y';
	BEGIN
		dbg('Checking Reserve updated or not from GWPagee');
		dbg('reference_no : '||cont_ref_no);
		select response into ret from DETB_RESERVE_DTL_EXTGBL where reference_no = cont_ref_no;
		dbg('Response : '||ret);
		IF ret is null
		THEN
		return 'N';
		else
		return 'Y';
		end if;
	exception when others 
	then
		return 'Y';
	end fn_chk_is_resp_upd;		
	-- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Ends            
            BEGIN
            
                        dbg('In Fn_Pre_Process..');
			-- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Starts
			IF fn_chk_is_resv_avl(p_dedtraut.v_detbs_jrnl_log.reference_no) <> 'Y'
			THEN
						debug.pr_debug('**'
													,'Reserve Not aVailable for the account as per GWPagee. Not allowed to authorize');
						debug.pr_debug('**', SQLERRM);
						p_err_code   := 'ST-PASS-001';
						p_err_params := p_err_params||p_dedtraut.v_detbs_jrnl_log.account||'~';

			END IF;
			IF fn_chk_is_resp_upd(p_dedtraut.v_detbs_jrnl_log.reference_no) <> 'Y'
			THEN
						debug.pr_debug('**'
													,'Reserve Not Updated yet from GWPagee... Please retry authorising again after some time');
						debug.pr_debug('**', SQLERRM);
						p_err_code   := 'ST-PASS-002';
						p_err_params := p_err_params|| p_dedtraut.v_detbs_jrnl_log.account||'~';
			END IF;
			IF p_err_params is not null
			THEN
						RETURN FALSE;												
			END IF;
			-- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Ends   
            
                        dbg('Returning Success From Fn_Pre_Process..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Pre_Process ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_pre_process;

            FUNCTION fn_post_process
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_child_function   IN VARCHAR2
                     ,p_multi_trip_id    IN VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_prev_dedtraut    IN depks_dedtraut_main.ty_dedtraut
                     ,p_wrk_dedtraut     IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            BEGIN
            
                        dbg('In Fn_Post_Process..');
            
                        dbg('Returning Success From Fn_Post_Process..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Post_Process ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_post_process;

            FUNCTION fn_pre_query
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_child_function   IN VARCHAR2
                     ,p_full_data        IN VARCHAR2 DEFAULT 'Y'
                     ,p_with_lock        IN VARCHAR2 DEFAULT 'N'
                     ,p_qrydata_reqd     IN VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_wrk_dedtraut     IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
            BEGIN
            
                        dbg('In Fn_Pre_Query..');
            
                        dbg('Returning Success From Fn_Pre_Query..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Pre_Query ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_pre_query;

            FUNCTION fn_post_query
            (
                        p_source           IN VARCHAR2
                     ,p_source_operation IN VARCHAR2
                     ,p_function_id      IN VARCHAR2
                     ,p_action_code      IN VARCHAR2
                     ,p_child_function   IN VARCHAR2
                     ,p_full_data        IN VARCHAR2 DEFAULT 'Y'
                     ,p_with_lock        IN VARCHAR2 DEFAULT 'N'
                     ,p_qrydata_reqd     IN VARCHAR2
                     ,p_dedtraut         IN depks_dedtraut_main.ty_dedtraut
                     ,p_wrk_dedtraut     IN OUT depks_dedtraut_main.ty_dedtraut
                     ,p_err_code         IN OUT VARCHAR2
                     ,p_err_params       IN OUT VARCHAR2
            ) RETURN BOOLEAN IS
    --- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5  for handling the ovd msgs starts
      l_tbl_contract_ovd depks_dedtraut_main.ty_tb_v_cstbs_contract_ovd;
      l_status varchar2(1);
      l_count   number :=0;
      l_acc sttm_cust_account.cust_ac_no%TYPE;
      l_sttmbrn_gbl         cvpkss_utils_extgbl.typ_sttmbrn_gbl;
      l_trn_branch     sttm_branch.branch_code%TYPE;
      l_eca_flag         sttm_branch_extgbl.eca_flag%TYPE;

    --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5  for handling the ovd msgs ends
            BEGIN
            
                        dbg('In Fn_Post_Query');

-- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5  for handling the ovd msgs starts
    l_trn_branch:= global.current_branch;
    l_count := 0;
        
    dbg('Calling cvpks_utils_extgbl.get_sttm_brn for getting branch level ECA flag value');
        
        cvpks_utils_extgbl.get_sttm_brn
        (
        l_trn_branch,
        l_sttmbrn_gbl
        );
        
    Dbg('ECA Flag value for the branch is: ' || l_sttmbrn_gbl.sttm_brn_extgblrec.eca_flag);
    l_eca_flag := NVL(l_sttmbrn_gbl.sttm_brn_extgblRec.eca_flag, 'N');
            
        
            FOR i IN 1 .. p_wrk_dedtraut.v_cstbs_contract_ovd.COUNT
            LOOP
            
                l_acc:=Cspkes_Misc.Fn_Getparam(p_wrk_dedtraut.v_cstbs_contract_ovd(i).parameters,1, '~');
                dbg('acc is '||l_acc);
                
                l_status := NULL;
            
            IF l_eca_flag IN  ('F','L') AND l_acc is not null
            THEN
                BEGIN         
                
                    SELECT eca_status 
                    INTO    l_status
                    FROM    iftb_eca_req_dtl_extgbl
                    WHERE   fcc_process_ref_no= p_wrk_dedtraut.v_detbs_jrnl_log.reference_no
                    AND     cust_ac_no           = l_acc
                    AND     original_number = p_wrk_dedtraut.v_detbs_jrnl_log.reference_no
                    AND     ac_branch = l_trn_branch;
                    
                
                EXCEPTION
                WHEN TOO_MANY_ROWS
                THEN
                    dbg('Single record fetch returned multiple rows');
                    BEGIN
                        SELECT DISTINCT eca_status 
                        INTO    l_status
                        FROM    iftb_eca_req_dtl_extgbl
                        WHERE   fcc_process_ref_no=p_wrk_dedtraut.v_detbs_jrnl_log.reference_no
                        AND     cust_ac_no = l_acc
                        AND     original_number = p_wrk_dedtraut.v_detbs_jrnl_log.reference_no
                        AND     ac_branch = l_trn_branch                        
                        AND     eca_status = 'P';
                    EXCEPTION
                    WHEN OTHERS
                    THEN
                        dbg('In WOT of '||SQLERRM);
                        l_status := NULL;
                    END;
                    
                    --l_status:= NULL;
                --FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5 UT Changes Starts
                WHEN NO_DATA_FOUND 
                THEN
                    l_status := NULL;
                --FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5 UT Changes Ends

                end;
                
            ELSIF l_eca_flag = 'N' AND l_acc is not null
            THEN
                BEGIN         
                
                    SELECT status 
                    INTO    l_status
                    FROM    iftbs_otat_details_extgbl
                    WHERE   external_ref_no= p_wrk_dedtraut.v_detbs_jrnl_log.reference_no
                    AND     customer_acc_no = l_acc;
                
                EXCEPTION
                --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 SFR 145 Changes Starts
                WHEN NO_DATA_FOUND
                THEN
                    dbg('No data found in iftbs_otat_details_extgbl for ref number '||p_wrk_dedtraut.v_detbs_jrnl_log.reference_no);
                    l_status := NULL;
                --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 SFR 145 Changes Ends
                WHEN TOO_MANY_ROWS
                THEN
                    dbg('Single record fetch returned multiple rows');
                    BEGIN
                        SELECT DISTINCT status 
                        INTO    l_status
                        FROM    iftbs_otat_details_extgbl
                        WHERE   external_ref_no=p_wrk_dedtraut.v_detbs_jrnl_log.reference_no
                        AND     customer_acc_no=l_acc
                        AND     status = 'P';
                    EXCEPTION
                    WHEN OTHERS 
                    THEN
                        dbg('In WOT of '||SQLERRM);
                        l_status := NULL;
                    END;
                    
                    --l_status:= NULL;
                END;
                    
            END IF; 
                dbg('l_status is '||l_status);  
                dbg('p_Wrk_dedjrnau.v_csvw_contract_ovd__auth(i).ERR_CODE is '||p_wrk_dedtraut.v_cstbs_contract_ovd(i).ERR_CODE);   
                
                IF l_eca_flag IN  ('F','L')
                THEN

                    IF (
                            p_wrk_dedtraut.v_cstbs_contract_ovd(i).ERR_CODE <> 'IF-ECARQ-01'
                            OR
                            (p_wrk_dedtraut.v_cstbs_contract_ovd(i).ERR_CODE = 'IF-ECARQ-01' AND l_status = 'P')
                        )
                    THEN
                        dbg('chk point for ovd in ECA');
                            l_count := l_count + 1;
                        l_tbl_contract_ovd(l_count) := p_wrk_dedtraut.v_cstbs_contract_ovd(i);
                    END IF; 
                ELSIF l_eca_flag = 'N'
                THEN    
                    
                    IF (
                            p_wrk_dedtraut.v_cstbs_contract_ovd(i).ERR_CODE <> 'IF-OTACK-01'
                            OR
                            (p_wrk_dedtraut.v_cstbs_contract_ovd(i).ERR_CODE = 'IF-OTACK-01' AND l_status = 'P')
                        )
                    THEN
                        dbg('chk point for ovd in OT');
                            l_count := l_count + 1;
                        l_tbl_contract_ovd(l_count) := p_wrk_dedtraut.v_cstbs_contract_ovd(i);
                    END IF;                 
                
                END IF; 
                    
            dbg('Count here :' || l_tbl_contract_ovd.COUNT);
            END LOOP;

            --IF l_tbl_contract_ovd.COUNT >0 --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5      ITR sfr#98 and 88 changes commented
            --THEN --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5    ITR sfr#98 and 88 changes commented
                p_wrk_dedtraut.v_cstbs_contract_ovd.DELETE;
                p_wrk_dedtraut.v_cstbs_contract_ovd := l_tbl_contract_ovd;
            --END IF; --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5     ITR sfr#98 and 88 changes commented
            
        --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5  for handling the ovd msgs starts Ends                            
            
                        dbg('Returning Success From Fn_Post_Query..');
                        RETURN TRUE;
            EXCEPTION
                        WHEN OTHERS THEN
                                    debug.pr_debug('**'
                                                                ,'In When Others of depks_dedtraut_Custom.Fn_Post_Query ..');
                                    debug.pr_debug('**', SQLERRM);
                                    p_err_code   := 'ST-OTHR-001';
                                    p_err_params := NULL;
                                    RETURN FALSE;
            END fn_post_query;


END depks_dedtraut_custom;
/