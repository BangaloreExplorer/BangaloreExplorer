CREATE OR REPLACE PACKAGE BODY depks_dengwpps_main AS
     /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : depks_dengwpps_main.sql
     **
     ** Module     : Data Entry
     ** 
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright (R) 2008,2018 , Oracle and/or its affiliates.  All rights reserved
     ** 
     ** 
     ** No part of this work may be reproduced, stored in a retrieval system, adopted 
     ** or transmitted in any form or by any means, electronic, mechanical, 
     ** photographic, graphic, optic recording or otherwise, translated in any 
     ** language or computer language, without the prior written permission of 
     ** Oracle and/or its affiliates. 
     ** 
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,
     ** Goregaon (East), 
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
     CHANGE HISTORY
     
     SFR Number         :  
     Changed By         :  
     Change Description :  
     
     -------------------------------------------------------------------------------------------------------
     */
     

   g_Base_Table_Rec  DETB_RESERVE_DTL_EXTGBL%ROWTYPE;
   --Skip Handler Variables
   g_Skip_Sys       BOOLEAN := FALSE;
   g_Skip_Custom    BOOLEAN := FALSE;
   PROCEDURE Dbg(p_msg VARCHAR2)  IS
      l_Msg     VARCHAR2(32767);
   BEGIN
      l_Msg := 'depks_dengwpps_Main ==>'||p_Msg;
      Debug.Pr_Debug('DE' ,l_Msg);
   END Dbg;

   PROCEDURE Pr_Log_Error(p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
      l_Fid    VARCHAR2(32767) := 'DENGWPPS';
   BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,l_Fid,p_Err_Code,p_Err_Params);
   END Pr_Log_Error;
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
   BEGIN
      depks_dengwpps_Custom.Pr_Skip_Handler (P_Stage);
   END Pr_Skip_Handler;
   PROCEDURE Pr_Set_Skip_Sys IS
   BEGIN
      g_Skip_Sys := TRUE;
   END Pr_Set_Skip_Sys;
   PROCEDURE Pr_Set_Activate_Sys IS
   BEGIN
      g_Skip_Sys := FALSE;
   END Pr_Set_Activate_Sys;
   FUNCTION  Fn_Skip_Sys RETURN BOOLEAN IS
   BEGIN
      RETURN G_Skip_Sys;
   END  Fn_Skip_Sys;
   PROCEDURE Pr_Set_Skip_Custom IS
   BEGIN
      g_Skip_Custom := TRUE;
   END Pr_Set_Skip_Custom;
   PROCEDURE Pr_Set_Activate_Custom IS
   BEGIN
      g_Skip_Custom := FALSE;
   END Pr_Set_Activate_Custom;
   FUNCTION  Fn_Skip_Custom RETURN BOOLEAN IS
   BEGIN
      IF Cspks_Req_Global.g_Release_Type IN(Cspks_Req_Global.p_Kernel,Cspks_Req_Global.P_Cluster) THEN
         RETURN TRUE;
      ELSIF Cspks_Req_Global.g_Release_Type =Cspks_Req_Global.p_Custom THEN
         RETURN FALSE;
      ELSE
         RETURN G_Skip_Custom;
      END IF;
   END  Fn_Skip_Custom;
   FUNCTION Fn_Sys_Filter(p_Notif_Code IN VARCHAR2,
                   p_Operation          IN VARCHAR2,
                   p_Rec_Rowid          IN VARCHAR2,
                   p_Pkey_Fields        IN VARCHAR2,
                   p_Pkey_Values        IN VARCHAR2,
                   p_Process_Notif      IN OUT VARCHAR2,
                   p_Err_Code           IN OUT VARCHAR2,
                   p_Err_Params          IN OUT VARCHAR2) RETURN BOOLEAN IS

      l_Pk_Counter NUMBER :=1;
      l_Where      VARCHAR2(32767);
      l_Pkey       VARCHAR2(32767);
      l_PVal       VARCHAR2(32767);
      l_Pk_reference_no VARCHAR2(32767);
      l_Pk_datetimestamp VARCHAR2(32767);
   BEGIN

      dbg('In Fn_Sys_Filter..');
      l_Pk_Counter := 1;
      l_Pkey            := NVL(cspkes_misc.Fn_Getparam(p_Pkey_Fields, l_Pk_Counter, '~'),'EOPL');
      l_PVal            := cspkes_misc.Fn_Getparam(p_Pkey_Values, l_Pk_Counter, '~');
      WHILE (l_PKey <> 'EOPL' AND l_PVal <> 'EOPL' )
      LOOP
         dbg('Key/Value   :'||l_PKey ||':'||l_PVal);
         IF l_Pkey = 'REFERENCE_NO' THEN
            l_pk_reference_no:= l_PVal;
         ELSIF l_Pkey = 'DATETIMESTAMP' THEN
            l_pk_datetimestamp:= l_PVal;
         END IF;
         l_Pk_Counter := l_Pk_Counter +1;
         l_Pkey := NVL(cspkes_misc.Fn_Getparam(p_Pkey_Fields, l_Pk_Counter, '~'),'EOPL');
         l_PVal := cspkes_misc.Fn_Getparam(p_Pkey_Values, l_Pk_Counter, '~');
      END LOOP;
      BEGIN
         SELECT *
         INTO   g_Base_Table_Rec
         FROM  DETB_RESERVE_DTL_EXTGBL
         WHERE REFERENCE_NO = NVL(l_pk_reference_no,REFERENCE_NO) AND DATETIMESTAMP = NVL(l_pk_datetimestamp,DATETIMESTAMP) ;
      EXCEPTION
         WHEN no_data_found THEN
            dbg('Record Does not Exist..');
            p_err_code    := 'ST-NOTF-001';
            p_Err_Params  := p_Pkey_Values;
      END;

      p_Process_Notif:= 'Y';
      dbg('Returning from Fn_Sys_Filter');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of depks_dengwpps_Main.Fn_Sys_Filter ..');
         debug.pr_debug('**',SQLERRM);
         p_err_code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Filter;
   FUNCTION Fn_Sys_Build_Request(p_Notif_Code IN VARCHAR2,
                   p_Operation          IN VARCHAR2,
                   p_Rec_Rowid          IN VARCHAR2,
                   p_Pkey_Fields        IN VARCHAR2,
                   p_Pkey_Values        IN VARCHAR2,
                   p_GW_Service_Code    IN OUT VARCHAR2,
                   p_GW_Operation_Code  IN OUT VARCHAR2,
                   p_Req_Node_List IN OUT VARCHAR2,
                   p_Req_Tags      IN OUT VARCHAR2,
                   p_Req_Vals      IN OUT VARCHAR2,
                   p_Err_Code           IN OUT VARCHAR2,
                   p_Err_Params          IN OUT VARCHAR2) RETURN BOOLEAN IS

   BEGIN

      dbg('In Fn_Sys_Build_Request..');

      p_GW_Service_Code   := '';
      p_GW_Operation_Code := '';
      p_Req_Node_List     := '';
      p_Req_Tags :='Id_Sist~DtHr~ClgReg~CodMsg~CtaCongenere~NumOpOrig~DtMovTo~Vlr';
      p_Req_Vals :=g_Base_Table_Rec.system_id||'~'||g_Base_Table_Rec.datetimestamp||'~'||g_Base_Table_Rec.msg_reg||'~'||g_Base_Table_Rec.msg_type||'~'||g_Base_Table_Rec.account||'~'||g_Base_Table_Rec.reference_no||'~'||g_Base_Table_Rec.value_dt||'~'||g_Base_Table_Rec.amount;
      dbg('Returning from Fn_Sys_Build_Request');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of depks_dengwpps_Main.Fn_Sys_Build_Request ..');
         debug.pr_debug('**',SQLERRM);
         p_err_code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Sys_Build_Request;
   FUNCTION Fn_Filter(p_Notif_Code IN VARCHAR2,
                   p_Operation          IN VARCHAR2,
                   p_Rec_Rowid          IN VARCHAR2,
                   p_Pkey_Fields        IN VARCHAR2,
                   p_Pkey_Values        IN VARCHAR2,
                   p_Process_Notif      IN OUT VARCHAR2,
                   p_Err_Code           IN OUT VARCHAR2,
                   p_Err_Params          IN OUT VARCHAR2) RETURN BOOLEAN IS

   BEGIN

      dbg('In Fn_Filter..');

      Pr_Skip_Handler('PREFILTER');
      IF NOT depks_dengwpps_Main.Fn_Skip_custom  THEN
         IF NOT depks_dengwpps_Custom.Fn_Pre_Filter (p_Notif_Code,
            p_Operation,
            p_Rec_Rowid,
            p_Pkey_Fields,
            p_Pkey_Values,
            p_Process_Notif,
            p_err_code,
            p_Err_Params)  THEN
            dbg('Failed in Fn_Pre_Filter..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dengwpps_Main.Fn_Skip_Sys THEN
         dbg('Calling Fn_Sys_Filter..');
         IF NOT Fn_Sys_Filter (p_Notif_Code,
            p_Operation,
            p_Rec_Rowid,
            p_Pkey_Fields,
            p_Pkey_Values,
            p_Process_Notif,
            p_err_code,
            p_Err_Params)  THEN
            dbg('Failed in Fn_Sys_Filter..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTFILTER');
      IF NOT depks_dengwpps_Main.Fn_Skip_custom  THEN
         IF NOT depks_dengwpps_Custom.Fn_Post_Filter (p_Notif_Code,
            p_Operation,
            p_Rec_Rowid,
            p_Pkey_Fields,
            p_Pkey_Values,
            p_Process_Notif,
            p_err_code,
            p_Err_Params)  THEN
            dbg('Failed in Fn_Post_Filter..');
            RETURN FALSE;
         END IF;
      END IF;
      dbg('Returning from Fn_Filter');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of depks_dengwpps_Main.Fn_Filter ..');
         debug.pr_debug('**',SQLERRM);
         p_err_code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Filter;
   FUNCTION Fn_Build_Request(p_Notif_Code IN VARCHAR2,
                   p_Operation          IN VARCHAR2,
                   p_Rec_Rowid          IN VARCHAR2,
                   p_Pkey_Fields        IN VARCHAR2,
                   p_Pkey_Values        IN VARCHAR2,
                   p_GW_Service_Code    IN OUT VARCHAR2,
                   p_GW_Operation_Code  IN OUT VARCHAR2,
                   p_Req_Node_List IN OUT VARCHAR2,
                   p_Req_Tags      IN OUT VARCHAR2,
                   p_Req_Vals      IN OUT VARCHAR2,
                   p_Err_Code           IN OUT VARCHAR2,
                   p_Err_Params          IN OUT VARCHAR2) RETURN BOOLEAN IS

   BEGIN

      dbg('In Fn_Build_Request..');

      Pr_Skip_Handler('PREBLDREQ');
      IF NOT depks_dengwpps_Main.Fn_Skip_custom  THEN
         IF NOT depks_dengwpps_Custom.Fn_Pre_Build_Request (p_Notif_Code,
            p_Operation,
            p_Rec_Rowid,
            p_Pkey_Fields,
            p_Pkey_Values,
            p_GW_Service_Code,
            p_GW_Operation_Code,
            p_Req_Node_List,
            p_Req_Tags ,
            p_Req_Vals,
            p_err_code,
            p_Err_Params)  THEN
            dbg('Failed in Fn_Pre_Build_Request..');
            RETURN FALSE;
         END IF;
      END IF;
      IF NOT depks_dengwpps_Main.Fn_Skip_Sys THEN
         dbg('Calling Fn_Sys_Build_Request..');
         IF NOT Fn_Sys_Build_Request (p_Notif_Code,
            p_Operation,
            p_Rec_Rowid,
            p_Pkey_Fields,
            p_Pkey_Values,
            p_GW_Service_Code,
            p_GW_Operation_Code,
            p_Req_Node_List,
            p_Req_Tags ,
            p_Req_Vals,
            p_err_code,
            p_Err_Params)  THEN
            dbg('Failed in Fn_Pre_Build_Request..');
            RETURN FALSE;
         END IF;
      END IF;
      Pr_Skip_Handler('POSTBLDREQ');
      IF NOT depks_dengwpps_Main.Fn_Skip_custom  THEN
         IF NOT depks_dengwpps_Custom.Fn_Post_Build_Request (p_Notif_Code,
            p_Operation,
            p_Rec_Rowid,
            p_Pkey_Fields,
            p_Pkey_Values,
            p_GW_Service_Code,
            p_GW_Operation_Code,
            p_Req_Node_List,
            p_Req_Tags ,
            p_Req_Vals,
            p_err_code,
            p_Err_Params)  THEN
            dbg('Failed in Fn_Post_Build_Request..');
            RETURN FALSE;
         END IF;
      END IF;
      dbg('Returning from Fn_Build_Request');
      RETURN TRUE;

   EXCEPTION
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of depks_dengwpps_Main.Fn_Build_Request ..');
         debug.pr_debug('**',SQLERRM);
         p_err_code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Build_Request;
   FUNCTION Fn_Main(p_Notif_Code     IN VARCHAR2,
                   p_Operation          IN VARCHAR2,
                   p_Rec_Rowid          IN VARCHAR2,
                   p_Pkey_Fields        IN VARCHAR2,
                   p_Pkey_Values        IN VARCHAR2,
                   p_GW_Service_Code    IN OUT VARCHAR2,
                   p_GW_Operation_Code  IN OUT VARCHAR2,
                   p_Req_Node_List      IN OUT VARCHAR2,
                   p_Req_Tags           IN OUT VARCHAR2,
                   p_Req_Vals           IN OUT VARCHAR2,
                   p_Process_Notif      IN OUT VARCHAR2,
                   p_Err_Code           IN OUT VARCHAR2,
                   p_Err_Params          IN OUT VARCHAR2) RETURN BOOLEAN IS
      E_Failure_Exception     EXCEPTION;

   BEGIN

      dbg('In Fn_Main');

      SAVEPOINT sp_main;

      IF NOT Fn_Filter (p_Notif_Code,
         p_Operation,
         p_Rec_Rowid,
         p_Pkey_Fields,
         p_Pkey_Values,
         p_Process_Notif,
         p_err_code,
         p_Err_Params)  THEN
         dbg('Failed in Fn_Filter..');
         RAISE E_Failure_Exception;
      END IF;
      IF NVL(p_Process_Notif,'N') = 'Y' THEN
         dbg('Calling Fn_Build_Request..');
         IF NOT Fn_Build_Request (p_Notif_Code,
            p_Operation,
            p_Rec_Rowid,
            p_Pkey_Fields,
            p_Pkey_Values,
            p_GW_Service_Code,
            p_GW_Operation_Code,
            p_Req_Node_List,
            p_Req_Tags ,
            p_Req_Vals,
            p_err_code,
            p_Err_Params)  THEN
            RAISE E_Failure_Exception;
            RETURN FALSE;
         END IF;
      END IF;

      dbg('Returning Success From Fn_Main..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         dbg('From E_Failure_Exception of Fn_Main');
         ROLLBACK TO Sp_Main;
         dbg('Errors     :'||p_err_code);
         dbg('Parameters :'||p_Err_Params);
         RETURN FALSE;

      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of Fn_Main ..');
         debug.pr_debug('**',SQLERRM);
         ROLLBACK TO Sp_Main;
         p_err_code    := 'ST-OTHR-001';
         p_Err_Params  := Null;
         RETURN FALSE;
   END Fn_Main;

END depks_dengwpps_main;
/