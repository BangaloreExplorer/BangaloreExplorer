CREATE OR REPLACE PACKAGE BODY depks_dedbttot_custom AS
     /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : depks_dedbttot_custom.sql
     **
     ** Module     : Data Entry
     ** 
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright � 2008,2014 , Oracle and/or its affiliates.  All rights reserved
     ** 
     ** 
     ** No part of this work may be reproduced, stored in a retrieval system, adopted 
     ** or transmitted in any form or by any means, electronic, mechanical, 
     ** photographic, graphic, optic recording or otherwise, translated in any 
     ** language or computer language, without the prior written permission of 
     ** Oracle and/or its affiliates. 
     ** 
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,
     ** Goregaon (East), 
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
     CHANGE HISTORY
     
     SFR Number         :  
     Changed By         :  
     Change Description :  
     
     Modified On          : 07-JUL-2014
     Modified Reason      : Batch reassign and Restriction of Batch Authorisation
			    Incorpporated the changes from DEDBTHAU to DEDBTTOT                             
     Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol1 Tag 4                              
     
     30-OCT-2012 FCUBS CITI Release 12.0.0.1.0 IUT SFR#37 : Validation only to check assignee and assigned from with global user id	 	

     SFR Number         :  FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes
     Changed By         :  Maheboob Pasha Kazi
     Change Description :  User profile level Input and Authorization Limit setup
 			   Incorpporated the changes from DEDBTHAU to DEDBTTOT
     Search String      :  FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit     
     
      ** Modified By         : Rajesha K S
      ** Modified On         : 20-AUG-2014
      ** Modified Reason     : Incorpporated the changes from DEDBTHAU to DEDBTTOT
      ** Search String       : FCUBS12.0.1.7CITIDDA Rel3 SIT1 SFR#79      
      ** RETRO bug#          : CITI_FC12_R4_SUPP DEV1 SFR#23 Changes
      ** RETROED On          : 20-AUG-2014
      ** RETROED By          : Rajesha K S
      
  ** Modfied By           : Debasish
  ** Modified On          : 15 FEB 2018
  ** Modified Reason      : Changes done as part of "Affiliates V3" to validate "Reserve for Account before Authorisation" 
  ** Search String        : FCUBS12.0.1.7CITIDDA Affiliates V3 Changes      
     -------------------------------------------------------------------------------------------------------
     */
     

   PROCEDURE Dbg(p_msg VARCHAR2)  IS
      l_Msg     VARCHAR2(32767);
   BEGIN
      l_Msg := 'depks_dedbttot_Custom ==>'||p_Msg;
      Debug.Pr_Debug('DE' ,l_Msg);
   END Dbg;

   PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
   BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,p_Function_Id,p_Err_Code,p_Err_Params);
   END Pr_Log_Error;
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
   BEGIN
      Dbg('In Pr_Skip_Handler');
   END Pr_Skip_Handler;
   FUNCTION fn_Post_build_type_structure (p_source    IN     VARCHAR2,
                              p_source_operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_addl_info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_dedbttot     IN  OUT depks_dedbttot_Main.ty_dedbttot,
      p_err_code          IN OUT VARCHAR2,
      p_err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      dbg('In fn_Post_build_type_structure');

      dbg('Returning Success from fn_Post_build_type_structure');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of depks_dedbttot_Custom.fn_Post_build_type_structure ..');
         debug.pr_debug('**',SQLERRM);
         p_err_code    := 'ST-OTHR-001';
         p_err_params  := NULL;
         RETURN FALSE;
   END fn_Post_build_type_structure;

   FUNCTION Fn_main       (p_source            IN     VARCHAR2,
                              p_source_operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_action_code       IN     VARCHAR2,
                              p_Child_Function    IN     VARCHAR2,
                              p_multi_trip_id     IN     VARCHAR2,
                              p_Request_No        IN     VARCHAR2,
                              p_dedbttot          IN OUT  depks_dedbttot_Main.ty_dedbttot,
                              p_status            IN OUT VARCHAR2 ,
                              p_err_code          IN OUT VARCHAR2,
                              p_err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN 
   IS
      E_Failure_Exception    EXCEPTION;
      E_Override_Exception   EXCEPTION;
      -- FCUBS12.0.1.7CITIDDA Rel3 SIT1 SFR#79 Changes Starts
      --FCUBS CITI Release 12.0.0.1.0 FS Vol1 Tag 4 Starts
      L_Reasig_Restr Detm_Branch_Cond_Extgbl.Restrict_Branch_Reassign%type;
      L_Count number;
      L_Cr_Ent_Total Detbs_Batch_Master.Cr_Ent_Total%type;
      --FCUBS CITI Release 12.0.0.1.0 FS Vol1 Tag 4 Ends
      
      --FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit (Start)
      --l_fn_call_id number;
      --l_tb_cluster_data Global.Ty_Tb_Cluster_Data; -- FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit commeneted      
      --FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit (End)      
      -- FCUBS12.0.1.7CITIDDA Rel3 SIT1 SFR#79 Changes Ends
      -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Starts
				function fn_chk_is_resv_avl(cont_ref_no         IN VARCHAR2)
				
				return CHAR
				IS
					ret CHAR(1):='Y';
				BEGIN
					dbg('Checking Reserve from GWPagee');
					select decode(response,'2','N','U','N','Y') into ret from DETB_RESERVE_DTL_EXTGBL where reference_no = cont_ref_no;
					return ret;
				exception when others 
				then
					return 'Y';
				end fn_chk_is_resv_avl;
				
				function fn_chk_is_resp_upd(cont_ref_no         IN VARCHAR2)
				return CHAR
				IS
					ret CHAR(1):='Y';
				BEGIN
					dbg('Checking Reserve updated or not from GWPagee');
					select response into ret from DETB_RESERVE_DTL_EXTGBL where reference_no = cont_ref_no;
					IF ret is null
					THEN
					return 'N';
					else
					return 'Y';
					end if;
				exception when others 
				then
					return 'Y';
				end fn_chk_is_resp_upd;	
        -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Ends      

   BEGIN

      dbg('In Fn_main');
      SAVEPOINT Sp_Main_Dedbttot_custom;
      
      dbg('p_action_code :' || p_action_code);
            
	Smpks.g_tb_cluster_data('MODULE_ID'):= 'DE';  --FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit	
        -- FCUBS12.0.1.7CITIDDA Rel3 SIT1 SFR#79 Changes Starts
	--FCUBS CITI Release 12.0.0.1.0 FS Vol1 Tag 4 Starts
	
	IF p_action_code = 'AUTH'
	THEN
		BEGIN
		  SELECT Restrict_Branch_Reassign
		    INTO L_Reasig_Restr
		    FROM Detm_Branch_Cond_Extgbl
		   WHERE Branch_Code = global.current_branch;
		EXCEPTION
		  WHEN NO_DATA_FOUND THEN
		    NULL;
		END;
		Dbg('Batch No : ' || p_dedbttot.v_detbs_batch_master.batch_no || '~' || 'L_Reasig_Restr : ' || L_Reasig_Restr);
		IF NVL(L_Reasig_Restr, 'N') = 'Y' 
		THEN
			BEGIN
				SELECT COUNT(*)
				  INTO L_Count
				  FROM Detb_Batch_Master_Extgbl
				 WHERE Branch_Code = global.current_branch
				   AND Batch_No = p_dedbttot.v_detbs_batch_master.batch_no
				   AND (Assignee = Global.User_Id
				  --Or Assigned_To = Global.User_Id --30-OCT-2012 FCUBS CITI Release 12.0.0.1.0 IUT SFR#37 Changes
				    OR Assigned_From = Global.User_Id);
			EXCEPTION
				WHEN NO_DATA_FOUND THEN
				NULL;
			END;

			Dbg('L_Count : ' || L_Count);
			IF NVL(L_Count, 0) <> 0 
			THEN
				Dbg('L_Count if :' || L_Count);
				Debug.Pr_Debug('**',
					'Batch Contains Entries Input/Reassigned By The Current User' ||
					L_Count);
				p_Err_Code := 'DE-BAT100';
				Pr_Log_Error(p_Function_id,
					     p_source,
					     p_err_code,
					     p_err_params);
				RETURN FALSE;			  	
			END IF;
		END IF;
		--FCUBS CITI Release 12.0.0.1.0 FS Vol1 Tag 4 Ends
			
		--FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit (Start)
		--l_fn_call_id := 1;			
		--l_tb_cluster_data('MODULE_ID') := 'DE'; -- FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit commented			
	
		BEGIN
			SELECT ENTTOTCR
			  INTO L_Cr_Ent_Total
			  FROM Devws_Batch_Authorize
			 WHERE Branch = Global.Current_Branch
			   AND Batno = P_Dedbttot.V_Detbs_Batch_Master.Batch_No;
		EXCEPTION 
			WHEN NO_DATA_FOUND THEN
			L_Cr_Ent_Total := NULL;
		END;							   
		Dbg('L_Cr_Ent_Total :' || L_Cr_Ent_Total);
		IF NOT Smpks.fn_limits_validate('A',
						Global.Lcy,
						L_Cr_Ent_Total,
						Global.User_Id,
						Global.Current_Branch,
						p_err_code,
						p_err_params)
		THEN
			Debug.Pr_Debug ('**', 'The call to the function fn_limits_validate in Smpks package has returned false..');
			pr_log_error(p_Function_id, 
				     p_source, 
				     p_err_code, 
				     p_err_params);
		RETURN FALSE;      
		--FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit (End)
                -- FCUBS12.0.1.7CITIDDA Rel3 SIT1 SFR#79 Changes Ends
		END IF;
    -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Starts
    for indx in (select * from detbs_upload_detail where batch_no = P_Dedbttot.V_Detbs_Batch_Master.Batch_No)
    LOOP
						IF fn_chk_is_resv_avl(indx.branch_code||indx.source_code||indx.batch_no||indx.curr_no) <> 'Y'
						THEN
									debug.pr_debug('**'
																,'Reserve Not aVailable for the account '||indx.account||' as per GWPagee. Not allowed to authorize');
									debug.pr_debug('**', SQLERRM);
									p_err_code   := 'ST-PASS-001';
									p_err_params := p_err_params||indx.account||'~';
									Pr_Log_Error(p_Function_id,
														     p_source,
														     p_err_code,
					     										p_err_params);
						END IF;
						IF fn_chk_is_resp_upd(indx.branch_code||indx.source_code||indx.batch_no||indx.curr_no) <> 'Y'
						THEN
									debug.pr_debug('**'
																,'Reserve Not Updated yet for account '||indx.account||'from GWPagee... Please retry authorising again after some time');
									debug.pr_debug('**', SQLERRM);
									p_err_code   := 'ST-PASS-002';
									p_err_params := p_err_params||indx.account||'~';
									Pr_Log_Error(p_Function_id,
														     p_source,
														     p_err_code,
					     										p_err_params);									
						END IF;
						if p_err_params is not null
						then
							return false;
						end if;
						-- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Ends			
    
    end loop;
    -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Ends
    
	END IF;
      dbg('Returning Success From Fn_Main..');
      RETURN TRUE;

   EXCEPTION
      WHEN E_Failure_Exception THEN
         dbg('From E_Failure_Exception of Fn_Main');
         ROLLBACK TO Sp_Main_Dedbttot_custom;
         p_status        := 'F';
         dbg('Errors     :'||p_err_code);
         dbg('Parameters :'||p_err_params);
         RETURN FALSE;

      WHEN E_Override_Exception THEN
         dbg('From E_Override_Exception of Fn_Main');
         p_status        := 'O';
         dbg('Errors     :'||p_err_code);
         dbg('Parameters :'||p_err_params);
         RETURN FALSE;

      WHEN OTHERS THEN
         debug.pr_debug('**','In when others of depks_dedbttot_Custom.Fn_Main ..');
         debug.pr_debug('**',SQLERRM);
         p_status      := 'F';
         ROLLBACK TO Sp_Main_Dedbttot_custom;
         p_err_code    := 'ST-OTHR-001';
         p_err_params  := NULL;
         RETURN FALSE;
   END Fn_Main;


END depks_dedbttot_custom;
/
