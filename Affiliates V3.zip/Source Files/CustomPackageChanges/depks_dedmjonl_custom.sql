CREATE OR REPLACE PACKAGE BODY depks_dedmjonl_custom AS
  /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : depks_dedmjonl_custom.sql
     **
     ** Module     : Data Entry
     **
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright � 2007,2013 , Oracle and/or its affiliates.  All rights reserved
     **
     **
     ** No part of this work may be reproduced, stored in a retrieval system, adopted
     ** or transmitted in any form or by any means, electronic, mechanical,
     ** photographic, graphic, optic recording or otherwise, translated in any
     ** language or computer language, without the prior written permission of
     ** Oracle and/or its affiliates.
     **
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,.,
     ** Goregaon (East),
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
	CHANGE HISTORY

	SFR Number         :  FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes
	Changed By         :  Maheboob Pasha Kazi
	Change Description :  User profile level Input and Authorization Limit setup
	Search String      :  FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit

	** Modfied By           : Rajesh Kumar J
	** Modified On          : 07-JAN-2013
	** Modified Reason      : Changes added to populate the data for internal and external remarks.
	** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20

	** Modfied By           : Girish L
	** Modified On          : 10-JAN-2013
	** Modified Reason      : Changes added to populate Related Customer No and Name.
	** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3

	** Modfied By           : Revathi
	** Modified On          : 28-FEB-2013
	** Modified Reason      : Changes added to support the Back Value Date based on Working Days
	** Search String        : FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7 Back Value Date changes

	** Changed On           : 10-Apr-2013
	** Changed By           : Rajesh Kumar J
	** Change Description   : Changes added to populate Related Customer No and Name.
	** Search string        : FCUBS12.0.0.1CITI IUT3 SFR# 15 - Unable to query from summary screen

	** Changed On           : 16-Apr-2013
	** Changed By           : Rajesh Kumar J
	** Change Description   : Changes added to populate Related Customer No and Name.
	** Search string        : FCUBS12.0.0.1CITI IUT3 SFR# 0 - unique constraint violation

	** Changed On           : 06-May-2013
	** Changed By           : Girish L
	** Change Description   : Changes added to populate Related Customer No and Name.
	** Search string        : FS_FCUBS12.0.0.1CitiDDA_Vol4 Tag 03  IUT3 SFR# 175

	** Changed On           : 06-May-2013
	** Changed By           : Rajesh Kumar J
	** Change Description   : Changes added to populate details of, template without related customer.
	** Search string        : FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#6

	** Changed On           : 15-May-2013
	** Changed By           : Rajesh Kumar J
	** Change Description   : Changes added to allow rel cust as null, if not mandatory.
	** Search string        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 IUT3 SFR#189

	** Changed On           : 15-May-2013
	** Changed By           : Rajesh Kumar J
	** Change Description   : related customer
	** Search string        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 IUT3 SFR#186
  
  	** Modfied By           : Revathi
  	** Modified On          : 21-MAY-2013
  	** Modified Reason      : Function Call has been added to Validate Back Value Date
  	** Search String        : FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7Back Value Date changes IUT SFR 208
  
  	** Changed On           : 21-May-2013
  	** Changed By           : Rajesh Kumar J
  	** Change Description   : internal and external remarks
	** Search string        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 SFR#292

	** Changed On           : 24-May-2013
  	** Changed By           : Rajesh Kumar J
  	** Change Description   : Allowing to save without rel cust, before authorising the rel cust mandatory to No.
	** Search string        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 IUT3 SFR#402
  
     ** Modfied By           : Sohini Makar
     ** Modified On          : 10-June-2013
     ** Modified Reason      : Related customer validation issues.
     ** Search String        : FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 #ITR2 sfr 83
	 
     ** Modified By	   	: Asha G R
     ** Modified Date	: 10-Aug-2013
     ** Modification reason  : Manual Posting for Journal entries
     ** Search String	: FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5	 
    
     ** Modified By        : Rajesha K S/Ankush
     ** Modified On        : 13-MAR-2014
     ** Modified Reason    : USER_ID Validation/Value Date Defaulting.
     ** Search String      : FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3
     
     ** Modfied By           : Santosh Kumar Savanur
     ** Modified On          : 06-FEB-2014
     ** Modified Reason      : Account Hierarchy Changes
     ** Search String        : FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5 

	Modfied By              : Anjani
	Modified On             : 25 APR 2014
	Modified Reason         : Changes done for changing the referenced package ifpks_otat_gen_extgbl to ifpks_eca_extgbl 
	Search String           : FCUBS12.0.1.7CITIDDA Rel4 ECA Code Review Changes	 
  
     ** Modfied By           : Raghu Viswanath
     ** Modified On          : 26-APR-2016
     ** Modified Reason      : During Template default, system throws error due to smaller size of template ID and short name. Code modified for the same.
     ** Search String        : CITI_FC12_R5_SUPP SIT1 SFR#614

     ** Modfied By           : Siva
   	 ** Modified On          : 28 SEP 2016
   	 ** Modified Reason      : Changes done as part of "Offset posting by External reference" to validate "External Ref Number" 
   	 ** Search String        : CITI_FC12_R5_SUPP SIT1 SFR#919
   	 
  ** Modfied By           : Debasish
  ** Modified On          : 15 FEB 2018
  ** Modified Reason      : Changes done as part of "Affiliates V3" to validate "Reserve for Account before Authorisation" 
  ** Search String        : FCUBS12.0.1.7CITIDDA Affiliates V3 Changes
     -------------------------------------------------------------------------------------------------------
     */

  PROCEDURE dbg(p_msg VARCHAR2) IS
    l_msg VARCHAR2(32767);
  BEGIN
    l_msg := 'depks_dedmjonl_Custom ==>' || p_msg;
    debug.pr_debug('DE', l_msg);
  END dbg;

  PROCEDURE pr_log_error(p_function_id IN VARCHAR2,
                         p_source      VARCHAR2,
                         p_err_code    VARCHAR2,
                         p_err_params  VARCHAR2) IS
  BEGIN
    cspks_req_utils.pr_log_error(p_source,
                                 p_function_id,
                                 p_err_code,
                                 p_err_params);
  END pr_log_error;
  PROCEDURE pr_skip_handler(p_stage IN VARCHAR2) IS
  BEGIN
    dbg('In Pr_Skip_Handler..');
  END pr_skip_handler;
  FUNCTION fn_post_build_type_structure(p_source           IN VARCHAR2,
                                        p_source_operation IN VARCHAR2,
                                        p_function_id      IN VARCHAR2,
                                        p_action_code      IN VARCHAR2,
                                        p_child_function   IN VARCHAR2,
                                        p_addl_info        IN cspks_req_global.ty_addl_info,
                                        p_dedmjonl         IN OUT depks_dedmjonl_main.ty_dedmjonl,
                                        p_err_code         IN OUT VARCHAR2,
                                        p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    dbg('In Fn_Post_Build_Type_Structure..');

    dbg('Returning Success From Fn_Post_Build_Type_Structure..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Post_Build_Type_Structure ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_build_type_structure;

  FUNCTION fn_pre_check_mandatory(p_source           IN VARCHAR2,
                                  p_source_operation IN VARCHAR2,
                                  p_function_id      IN VARCHAR2,
                                  p_action_code      IN VARCHAR2,
                                  p_child_function   IN VARCHAR2,
                                  p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL',
                                  p_dedmjonl         IN OUT depks_dedmjonl_main.ty_dedmjonl,
                                  p_err_code         IN OUT VARCHAR2,
                                  p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN

   IS
  BEGIN

    dbg('In Fn_Pre_Check_Mandatory..');

    dbg('Returning  Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Pre_Check_Mandatory ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION fn_post_check_mandatory(p_source           IN VARCHAR2,
                                   p_source_operation IN VARCHAR2,
                                   p_function_id      IN VARCHAR2,
                                   p_action_code      IN VARCHAR2,
                                   p_child_function   IN VARCHAR2,
                                   p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                                   p_err_code         IN OUT VARCHAR2,
                                   p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    l_offset_posting detms_branch_cond_extgbl.offset_post_by_ext_ref%TYPE; --CITI_FC12_R5_SUPP SIT1 SFR#919 changes
  BEGIN
    dbg('In Fn_Post_Check_Mandatory..');
    
    --CITI_FC12_R5_SUPP SIT1 SFR#919 starts
    IF p_action_code IN (Cspks_Req_Global.p_New, Cspks_Req_Global.p_Modify) 
    THEN
      BEGIN
        SELECT Nvl(offset_post_by_ext_ref, 'N')
          INTO l_offset_posting
          FROM detms_branch_cond_extgbl
         WHERE branch_code = global.current_branch;
      EXCEPTION WHEN NO_DATA_FOUND THEN
        l_offset_posting := 'N';
      END;
              
      Dbg('l_offset_posting: '||l_offset_posting);
      IF l_offset_posting = 'Y' 
      THEN
        IF p_dedmjonl.v_mlt_ofst_mast_extgbl.external_ref_no IS NULL 
        THEN
          Dbg('External Reference Number is null');
          
          p_err_code := 'DE-EXT-001';
          p_err_params := '';
          pr_log_error(p_function_id, 'FLEXCUBE', p_err_code, p_err_params);
        END IF;
      END IF;
    END IF;
    --CITI_FC12_R5_SUPP SIT1 SFR#919 ends
    
    dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Post_Check_Mandatory ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_check_mandatory;

  FUNCTION fn_pre_default_and_validate(p_source           IN VARCHAR2,
                                       p_source_operation IN VARCHAR2,
                                       p_function_id      IN VARCHAR2,
                                       p_action_code      IN VARCHAR2,
                                       p_child_function   IN VARCHAR2,
                                       p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                                       p_prev_dedmjonl    IN OUT depks_dedmjonl_main.ty_dedmjonl,
                                       p_wrk_dedmjonl     IN OUT depks_dedmjonl_main.ty_dedmjonl,
                                       p_err_code         IN OUT VARCHAR2,
                                       p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
    smpks.g_tb_cluster_data('MODULE_ID') := 'DE'; --FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit

    dbg('In Fn_Pre_Default_And_Validate..');
    
    -- FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5 Changes Starts
    acpkss_acc_hierarchy_extgbl.g_consider_for_acc_hier := 'Y';
    -- FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5 Changes Ends   

    dbg('Returning Success From Fn_Pre_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Pre_Default_And_Validate ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_default_and_validate;

  FUNCTION fn_post_default_and_validate(p_source           IN VARCHAR2,
                                        p_source_operation IN VARCHAR2,
                                        p_function_id      IN VARCHAR2,
                                        p_action_code      IN VARCHAR2,
                                        p_child_function   IN VARCHAR2,
                                        p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                                        p_prev_dedmjonl    IN OUT depks_dedmjonl_main.ty_dedmjonl,
                                        p_wrk_dedmjonl     IN OUT depks_dedmjonl_main.ty_dedmjonl,
                                        p_err_code         IN OUT VARCHAR2,
                                        p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    l_fn_call_id      NUMBER; --FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit (Start)
    l_tb_cluster_data global.ty_tb_cluster_data;
    --CITI_FC12_R5_SUPP SIT1 SFR#614 Changes Start
    --l_id    VARCHAR2(09); --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3
    --l_name  VARCHAR2(20); --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3
    l_id                Sttms_Customer.Customer_No%TYPE;
    l_name              Sttms_Customer.Short_Name%TYPE;
    --CITI_FC12_R5_SUPP SIT1 SFR#614 Changes End
    l_ac_gl VARCHAR2(01); --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3
    --FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7 Back Value Date changes starts
    j                  INTEGER;
    l_back_value_basis CHAR(1);
    l_acalc_bvday      DATE;
    l_diff             NUMBER := 0;
    l_allowed          detms_branch_cond.back_value%TYPE;
    l_days             detms_branch_cond.back_value_days%TYPE;
    l_cnt              NUMBER;
    l_tblerror         ovpks.tbl_error;
    --FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7 Back Value Date changes ends
    l_rel_cust_mandat sttms_branch_extgbl.related_cust_mandatory%TYPE; --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 IUT3 SFR#189

  BEGIN
    IF p_wrk_dedmjonl.v_detbs_mlt_offset_master.ccy_cd IS NOT NULL THEN

      IF NOT smpks.fn_limits_validate('I',
                                      p_wrk_dedmjonl.v_detbs_mlt_offset_master.ccy_cd,
                                      p_wrk_dedmjonl.v_detbs_mlt_offset_master.amount,
                                      global.user_id,
                                      global.current_branch,
                                      p_err_code,
                                      p_err_params) THEN
        pr_log_error(p_function_id,
                     p_source,
                     p_err_code,
                     p_err_params);
        RETURN FALSE;

      ELSE
        dbg('Returning Success From Fn_Post_Default_And_Validate IN DEDMJONL_CUSTOM PACKAGE');
      END IF;

    END IF;

    dbg('In Fn_Post_Default_And_Validate..');
    --FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit (Start)

    l_fn_call_id := 1;
    l_tb_cluster_data('MOUDLE_ID') := 'DE';

    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 starts
    IF p_action_code = 'NEW' THEN
    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 IUT3 SFR#189 starts
    /*
      IF p_wrk_dedmjonl.v_detbs_mlt_offset_master.account IS NOT NULL AND
         p_wrk_dedmjonl.v_mlt_ofst_mast_extgbl.related_cust_no IS NULL THEN
        p_err_code := 'DE-TRN01';
        RETURN FALSE;
      END IF;
    */
          dbg('check the related cust mandatory');
        IF p_wrk_dedmjonl.v_detbs_mlt_offset_master.account IS NOT NULL
        THEN
        --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 #ITR2 sfr 83: starts
     Dbg('Calling depks_services_extgbl.Fn_Validate_rel_cust_mand');
   IF NOT depks_services_extgbl.Fn_Validate_rel_cust_mand(GLOBAL.current_branch,
                                                        p_dedmjonl.v_mlt_ofst_mast_extgbl.related_cust_no,
                                                        p_Action_Code,
                                                        p_Err_Code,
                                                        p_Err_Params) THEN
    Dbg('Failed in depks_services_extgbl.Fn_Validate_rel_cust_mand');
    pr_log_error(p_function_id, p_source, p_Err_Code, p_Err_Params);
    END IF;
          --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 #ITR2 sfr 83: ends
        END IF;
      --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 IUT3 SFR#189 ends

    END IF;

    dbg('P_ACTION_CODE ' || p_action_code);

    IF p_action_code = 'DFLT' THEN
      dbg('Came inside if  ');

      --FS_FCUBS12.0.0.1CitiDDA_Vol4 Tag 03  IUT3 SFR# 175 Starts
      BEGIN
        --FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#6
        SELECT related_cust_no
          INTO l_id
          FROM detms_mtl_of_tmp_dt_extgbl
         WHERE template_id = p_wrk_dedmjonl.v_cstb_ui_columns.char_field9;               
        --FS_FCUBS12.0.0.1CitiDDA_Vol4 Tag 03  IUT3 SFR# 175 Ends

        SELECT short_name
          INTO l_name
          FROM sttms_customer
         WHERE customer_no = l_id;

        --FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#6 starts
      EXCEPTION
        WHEN no_data_found THEN
          dbg('Template created for no default walkin customer');
      END;
      --FCUBS12.0.1.7.0 CITI Vol3 Tag5 IUT3 SFR#6 ends

      dbg('Came inside if L_ID ' || l_id);
      dbg('L_NAME ' || l_name);

      p_wrk_dedmjonl.v_mlt_ofst_mast_extgbl.related_cust_no := l_id;
      p_wrk_dedmjonl.v_cstb_ui_columns.char_field31         := l_name;

      dbg('p_Wrk_dedmjonl.v_mlt_ofst_mast_extgbl.REFERENCE_NO ' ||
          p_wrk_dedmjonl.v_mlt_ofst_mast_extgbl.reference_no ||
          p_wrk_dedmjonl.v_detbs_mlt_offset_master.reference_no);
      dbg('p_Wrk_dedmjonl.v_mlt_ofst_mast_extgbl.RELATED_CUST_NO ' ||
          p_wrk_dedmjonl.v_mlt_ofst_mast_extgbl.related_cust_no);
      dbg('p_Wrk_dedmjonl.v_cstb_ui_columns.CHAR_FIELD33 ' ||
          p_wrk_dedmjonl.v_cstb_ui_columns.char_field33);
    END IF;
    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 ENDS
    --FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7 Back Value Date changes starts
    dbg('In Fn_Post_Default_And_Validate..');
    IF p_action_code IN (cspks_req_global.p_new) THEN
      dbg('validation starts for value date');
       -- FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7Back Value Date changes IUT SFR 208 starts
       		-- FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 Changes Starts
		IF p_wrk_dedmjonl.v_detbs_mlt_offset_master.value_date < Global.Application_Date
		THEN
			IF NOT depkss_services_extgbl.Fn_Validate_bkvaldt(
									  global.current_branch,
									  p_function_id,
									  global.application_date,
									  p_wrk_dedmjonl.v_detbs_mlt_offset_master.value_date,
									  p_err_code,
									  p_err_params
									  )
			THEN
				pr_log_error(p_function_id,
				p_source,
				p_err_code,
				p_err_params);
				--RETURN FALSE;

			ELSE
				 dbg('Returning Success From depkss_services_extgbl - Fn_Validate_ValDt');
			END IF;
			--FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7Back Value Date changes IUT SFR 208 ends		
			
			ELSIF p_wrk_dedmjonl.v_detbs_mlt_offset_master.value_date > Global.Application_Date
			THEN
			Dbg('validation starts for future value date'); 		
			IF NOT Depkss_Services_Extgbl.Fn_Validate_Futurevaldt(
										Global.Current_Branch,
										p_function_id,
										Global.Application_Date,
										p_wrk_dedmjonl.v_detbs_mlt_offset_master.value_date,
										p_err_code,
										p_err_params
										)
			THEN
				pr_log_error(p_function_id,
				p_source,
				p_err_code,
				p_err_params);
				--RETURN FALSE;
			ELSE
				Dbg('Returning Success From depkss_services_extgbl - Fn_Validate_Futurevaldt');
			END IF;			
		END IF;
		-- FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 Changes Ends
    END IF;
    --FS_FCUBS12.0.0.1CitiDDA_Vol3 Tag 7 Back Value Date changes ends
    dbg('Returning Success From Fn_Post_Default_And_Validate');
    RETURN TRUE;

    --FCUBS CITI Release 12.0.0.1.0 FS Vol 2 Tag 6 changes - Input/Auth Limit (End)
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Post_Default_And_Validate ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_default_and_validate;

  FUNCTION fn_pre_resolve_ref_numbers(p_source           IN VARCHAR2,
                                      p_source_operation IN VARCHAR2,
                                      p_function_id      IN VARCHAR2,
                                      p_action_code      IN VARCHAR2,
                                      p_dedmjonl         IN OUT depks_dedmjonl_main.ty_dedmjonl,
                                      p_err_code         IN OUT VARCHAR2,
                                      p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN

    dbg('In Fn_Pre_Resolve_Ref_Numbers..');

    dbg('Returning Success From Fn_Pre_Resolve_Ref_Numbers');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Main.Fn_Pre_Resolve_Ref_Numbers ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_resolve_ref_numbers;
  FUNCTION fn_post_resolve_ref_numbers(p_source           IN VARCHAR2,
                                       p_source_operation IN VARCHAR2,
                                       p_function_id      IN VARCHAR2,
                                       p_action_code      IN VARCHAR2,
                                       p_dedmjonl         IN OUT depks_dedmjonl_main.ty_dedmjonl,
                                       p_err_code         IN OUT VARCHAR2,
                                       p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

  BEGIN

    dbg('In Fn_Post_Resolve_Ref_Numbers..');

    dbg('Returning Success From Fn_Post_Resolve_Ref_Numbers..');
    RETURN TRUE;

  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When others of depks_dedmjonl_Main.Fn_Post_Resolve_Ref_Numbers ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_resolve_ref_numbers;
  FUNCTION fn_pre_product_default(p_source           IN VARCHAR2,
                                  p_source_operation IN VARCHAR2,
                                  p_function_id      IN VARCHAR2,
                                  p_action_code      IN VARCHAR2,
                                  p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                                  p_wrk_dedmjonl     IN OUT depks_dedmjonl_main.ty_dedmjonl,
                                  p_err_code         IN OUT VARCHAR2,
                                  p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    dbg('In Fn_Pre_Product_Default..');

    dbg('Returning Success From Fn_Pre_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Pre_Product_Default ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_product_default;

  FUNCTION fn_post_product_default(p_source           IN VARCHAR2,
                                   p_source_operation IN VARCHAR2,
                                   p_function_id      IN VARCHAR2,
                                   p_action_code      IN VARCHAR2,
                                   p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                                   p_wrk_dedmjonl     IN OUT depks_dedmjonl_main.ty_dedmjonl,
                                   p_err_code         IN OUT VARCHAR2,
                                   p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    dbg('In Fn_Post_Product_Default..');

    dbg('Returning Success From Fn_Post_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Post_Product_Default ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_product_default;

  FUNCTION fn_pre_unlock(p_source           IN VARCHAR2,
                         p_source_operation IN VARCHAR2,
                         p_function_id      IN VARCHAR2,
                         p_action_code      IN OUT VARCHAR2,
                         p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                         p_err_code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    dbg('In Fn_Pre_Unlock..');

    dbg('Returning Success From Fn_Pre_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Pre_Unlock ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_unlock;

  FUNCTION fn_post_unlock(p_source           IN VARCHAR2,
                          p_source_operation IN VARCHAR2,
                          p_function_id      IN VARCHAR2,
                          p_action_code      IN OUT VARCHAR2,
                          p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                          p_err_code         IN OUT VARCHAR2,
                          p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    dbg('In Fn_Post_Unlock');

    dbg('Returning Success From Fn_Post_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Post_Unlock ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_unlock;

  FUNCTION fn_pre_subsys_pickup(p_source           IN VARCHAR2,
                                p_source_operation IN VARCHAR2,
                                p_function_id      IN VARCHAR2,
                                p_action_code      IN VARCHAR2,
                                p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                                p_prev_dedmjonl    IN OUT depks_dedmjonl_main.ty_dedmjonl,
                                p_wrk_dedmjonl     IN OUT depks_dedmjonl_main.ty_dedmjonl,
                                p_err_code         IN OUT VARCHAR2,
                                p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    dbg('In Fn_Pre_Subsys_Pickup..');

    dbg('Returning Success From Fn_Pre_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Pre_Subsys_Pickup ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_subsys_pickup;

  FUNCTION fn_post_subsys_pickup(p_source           IN VARCHAR2,
                                 p_source_operation IN VARCHAR2,
                                 p_function_id      IN VARCHAR2,
                                 p_action_code      IN VARCHAR2,
                                 p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                                 p_prev_dedmjonl    IN OUT depks_dedmjonl_main.ty_dedmjonl,
                                 p_wrk_dedmjonl     IN OUT depks_dedmjonl_main.ty_dedmjonl,
                                 p_err_code         IN OUT VARCHAR2,
                                 p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    dbg('In Fn_Post_Subsys_Pickup..');

    dbg('Returning Success From Fn_Post_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Post_Subsys_Pickup ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_subsys_pickup;

  FUNCTION fn_pre_enrich(p_source           IN VARCHAR2,
                         p_source_operation IN VARCHAR2,
                         p_function_id      IN VARCHAR2,
                         p_action_code      IN VARCHAR2,
                         p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                         p_prev_dedmjonl    IN OUT depks_dedmjonl_main.ty_dedmjonl,
                         p_wrk_dedmjonl     IN OUT depks_dedmjonl_main.ty_dedmjonl,
                         p_err_code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    dbg('In Fn_Pre_Enrich..');

    dbg('Returning Success From Fn_Pre_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Pre_Enrich ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_enrich;

  FUNCTION fn_post_enrich(p_source           IN VARCHAR2,
                          p_source_operation IN VARCHAR2,
                          p_function_id      IN VARCHAR2,
                          p_action_code      IN VARCHAR2,
                          p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                          p_prev_dedmjonl    IN OUT depks_dedmjonl_main.ty_dedmjonl,
                          p_wrk_dedmjonl     IN OUT depks_dedmjonl_main.ty_dedmjonl,
                          p_err_code         IN OUT VARCHAR2,
                          p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    dbg('In Fn_Post_Enrich..');

    dbg('Returning Success From Fn_Post_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Post_Enrich ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_enrich;

  FUNCTION fn_pre_upload_db(p_source           IN VARCHAR2,
                            p_source_operation IN VARCHAR2,
                            p_function_id      IN VARCHAR2,
                            p_action_code      IN VARCHAR2,
                            p_child_function   IN VARCHAR2,
                            p_multi_trip_id    IN VARCHAR2,
                            p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                            p_prev_dedmjonl    IN depks_dedmjonl_main.ty_dedmjonl,
                            p_wrk_dedmjonl     IN OUT depks_dedmjonl_main.ty_dedmjonl,
                            p_err_code         IN OUT VARCHAR2,
                            p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
		  	--FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes strts
		l_count 		NUMBER;
		l_txn_id 		iftbs_eca_req_dtl_extgbl.unique_txn_id%TYPE;
		l_trn_branch     	sttms_branch.branch_code%TYPE;
		l_sttmbrn_gbl     cvpkss_utils_extgbl.typ_sttmbrn_gbl;
		l_eca_flag  	sttms_branch_extgbl.eca_flag%TYPE;
		--FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends
  BEGIN

    dbg('In Fn_Pre_Upload_Db..');
	
	--FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes strts
	l_trn_branch:= global.current_branch;
    	dbg('Calling cvpks_utils_extgbl.get_sttm_brn for getting branch level ECA flag value');
      cvpks_utils_extgbl.get_sttm_brn
		    (
		    l_trn_branch,
		    l_sttmbrn_gbl
		    );
    	Dbg('ECA Flag value for the branch is: ' || l_sttmbrn_gbl.sttm_brn_extgblrec.eca_flag);
    	
    	l_eca_flag := NVL(l_sttmbrn_gbl.sttm_brn_extgblRec.eca_flag, 'N');

	IF	p_action_code = cspks_req_global.p_delete AND l_eca_flag IN  ('F','L')
	THEN
		dbg('Action Code ' || p_action_code);
						    
		BEGIN
			SELECT  max(unique_txn_id)
			INTO   l_txn_id
			FROM   iftbs_eca_req_dtl_extgbl
			WHERE   fcc_process_ref_no= p_Wrk_dedmjonl.v_detbs_mlt_offset_master.reference_no
			AND     original_number = p_Wrk_dedmjonl.v_detbs_mlt_offset_master.reference_no
			AND 	eca_status<> 'D';
		EXCEPTION
		WHEN OTHERS
		THEN
		    dbg('In WOT of '||SQLERRM);
		END;
		
		dbg('unique_txn_id is '||l_txn_id);

		BEGIN
		     UPDATE  iftbs_eca_req_dtl_extgbl
			 SET 	  eca_status='D'
			 WHERE unique_txn_id = l_txn_id;
		EXCEPTION
		WHEN OTHERS
		THEN
		dbg('Error while updating.. '||SQLERRM);
		END;

	END IF;
	--FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends	  

    --CITI_FC12_R5_SUPP SIT1 SFR#919 starts - Moved code from fn_post_upload_db
    IF p_action_code = cspks_req_global.p_new THEN

      dbg('Inserting Into DETBS_MLT_OFST_MAST_EXTGBL..');
      BEGIN
        IF p_wrk_dedmjonl.v_mlt_ofst_mast_extgbl.reference_no IS NOT NULL THEN
          dbg('Record Sent..');
          INSERT INTO detbs_mlt_ofst_mast_extgbl
          VALUES p_wrk_dedmjonl.v_mlt_ofst_mast_extgbl;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          dbg('Failed In Insert intoDETBS_MLT_OFST_MAST_EXTGBL..');
          dbg(SQLERRM);
          p_err_code   := 'ST-UPLD-001';
          p_err_params := '@DETBS_MLT_OFST_MAST_EXTGBL';
          RETURN FALSE;
      END;
    END IF;
    --CITI_FC12_R5_SUPP SIT1 SFR#919 ends
    
    dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Pre_Upload_Db ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_upload_db;

  FUNCTION fn_post_upload_db(p_source           IN VARCHAR2,
                             p_source_operation IN VARCHAR2,
                             p_function_id      IN VARCHAR2,
                             p_action_code      IN VARCHAR2,
                             p_child_function   IN VARCHAR2,
                             p_multi_trip_id    IN VARCHAR2,
                             p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                             p_prev_dedmjonl    IN depks_dedmjonl_main.ty_dedmjonl,
                             p_wrk_dedmjonl     IN OUT depks_dedmjonl_main.ty_dedmjonl,
                             p_err_code         IN OUT VARCHAR2,
                             p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS

    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 SFR#292 starts
            l_internal_remarks actbs_recon_details_extgbl.internal_remarks%TYPE;
            l_external_remarks actbs_recon_details_extgbl.internal_remarks%TYPE;

            CURSOR v_recon_master   
            IS
                   SELECT 	* 
                     FROM 	actbs_recon_master 
                     WHERE	branch = p_wrk_dedmjonl.v_detbs_mlt_offset_master.branch_code
                      AND	ref_no = p_wrk_dedmjonl.v_detbs_mlt_offset_master.reference_no;
                      
            CURSOR v_recon_details	(p_branch VARCHAR2
            				,p_account VARCHAR2
            				,p_ccy VARCHAR2
            				,p_reconno VARCHAR2
            				,p_refno VARCHAR2) 
            IS
                   SELECT * 
                     FROM actbs_recon_details 
                    WHERE branch = p_branch
                      AND account = p_account
                      AND ccy = p_ccy
                      AND reconno = p_reconno
                      AND ref_no = p_refno;    
    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 SFR#292 ends
	
		--FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes for updating iftbs_otat_details_extgbl status on Del strts
        l_ot_at_tk_ref 	iftbs_otat_details_extgbl.otat_tkt_ref%TYPE;
        l_auth_stat     VARCHAR2(1);
        l_rej_code     	NUMBER := 1;
        l_called_from 	VARCHAR2(10) := 'AUTHORIZE';
        l_action_code  	VARCHAR2(5) :='D';
        l_auth_id 	VARCHAR2(10) := global.user_id;
        l_otat_status 	iftbs_otat_details_extgbl.status%TYPE;
        l_msg  		VARCHAR2(500);
		--FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends
    
  BEGIN

    dbg('In Fn_Post_Upload_Db..');
	
		--FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes for updating iftbs_otat_details_extgbl status on Del	   
	IF p_action_code = cspks_req_global.p_delete 
	THEN
      	dbg('Action Code ' || p_action_code);

		BEGIN
			SELECT	otat_tkt_ref
					,status
			INTO		l_ot_at_tk_ref
					,l_otat_status
			FROM 		iftbs_otat_details_extgbl
			WHERE 	external_ref_no	= p_Wrk_dedmjonl.v_detbs_mlt_offset_master.reference_no
			AND 		status 	<> 'D';
		EXCEPTION
		WHEN NO_DATA_FOUND
		THEN
			DEBUG.pr_debug('IF','Record not found in iftbs_otat_details_extgbl');
			l_ot_at_tk_ref :=NULL;
			l_otat_status :=NULL;
		WHEN OTHERS
		THEN
			dbg('In WOT..'||SQLERRM);
			l_otat_status :=NULL;
			l_ot_at_tk_ref :=NULL;
		END;



  		IF l_otat_status ='P' THEN
				--FCUBS12.0.1.7CITIDDA Rel4 ECA Code Review Changes Start
        		/*IF NOT ifpks_otat_gen_extgbl.fn_ot_appr_reject
						  (
						  l_ot_at_tk_ref
						  ,l_action_code
						  ,l_rej_code
						  ,p_err_params
						  ,l_auth_id
						  ,l_called_from
						  ,p_err_code
						  ,p_err_params
						  )
        		THEN
				dbg('Failed while updating the OT tickets '||l_ot_at_tk_ref||'~'||p_Wrk_dedmjonl.v_detbs_mlt_offset_master.reference_no);
				p_err_code := 'IFACPOST064';
				p_err_params := SQLERRM;
				Ovpkss.Pr_Appendtbl(p_err_code, p_err_params);
          			RETURN FALSE;
        		END IF;*/
			IF NOT ifpks_eca_extgbl.fn_ot_appr_reject
						  (
						  l_ot_at_tk_ref
						  ,l_action_code
						  ,l_rej_code
						  ,p_err_params
						  ,l_auth_id
						  ,l_called_from
						  ,p_err_code
						  ,p_err_params
						  )
        		THEN
				dbg('Failed while updating the OT tickets '||l_ot_at_tk_ref||'~'||p_Wrk_dedmjonl.v_detbs_mlt_offset_master.reference_no);
				p_err_code := 'IFACPOST064';
				p_err_params := SQLERRM;
				Ovpkss.Pr_Appendtbl(p_err_code, p_err_params);
          			RETURN FALSE;
        		END IF;
				--FCUBS12.0.1.7CITIDDA Rel4 ECA Code Review Changes end
  		END IF;
	END IF;
 	---FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends
	
    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 STARTS
    --CITI_FC12_R5_SUPP SIT1 SFR#919 commenting starts - Moved code to fn_pre_upload_db
    /*IF p_action_code = cspks_req_global.p_new THEN

      dbg('Inserting Into DETBS_MLT_OFST_MAST_EXTGBL..');
      BEGIN
        IF p_wrk_dedmjonl.v_mlt_ofst_mast_extgbl.reference_no IS NOT NULL THEN
          dbg('Record Sent..');
          INSERT INTO detbs_mlt_ofst_mast_extgbl
          VALUES p_wrk_dedmjonl.v_mlt_ofst_mast_extgbl;
        END IF;
      EXCEPTION
        WHEN OTHERS THEN
          dbg('Failed In Insert intoDETBS_MLT_OFST_MAST_EXTGBL..');
          dbg(SQLERRM);
          p_err_code   := 'ST-UPLD-001';
          p_err_params := '@DETBS_MLT_OFST_MAST_EXTGBL';
          RETURN FALSE;
      END;
    ELSIF p_action_code = cspks_req_global.p_delete THEN
    */--CITI_FC12_R5_SUPP SIT1 SFR#919 commenting starts
    IF p_action_code = cspks_req_global.p_delete THEN --CITI_FC12_R5_SUPP SIT1 SFR#919 added
      dbg('Action Code ' || p_action_code);
      dbg('Deleting The Data..');

      DELETE detbs_mlt_ofst_mast_extgbl
       WHERE reference_no = p_wrk_dedmjonl.v_detbs_mlt_offset_master.reference_no;             

    END IF;

    dbg('Returning Success From Fn_Sys_Upload_Db');
    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 ENDS

    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 STARTS
    IF p_action_code = 'NEW' THEN
      --FCUBS12.0.0.1CITI IUT3 SFR# 0 - unique constraint violation starts
      /*
                INSERT INTO  DETBS_MLT_OFST_MAST_EXTGBL
                      VALUES p_Wrk_dedmjonl.v_mlt_ofst_mast_extgbl;
      */
      --FCUBS12.0.0.1CITI IUT3 SFR# 0 - unique constraint violation ends
      INSERT INTO cstbs_ui_columns
      VALUES p_wrk_dedmjonl.v_cstb_ui_columns;
    END IF;
    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 ENDS
    
    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 SFR#292 starts
      IF p_action_code = cspks_req_global.p_new
      THEN
      dbg('recon entry started');
    
      FOR i in v_recon_master LOOP
            IF i.REF_NO = p_wrk_dedmjonl.v_detbs_mlt_offset_master.REFERENCE_NO
               AND i.BRANCH = p_wrk_dedmjonl.v_detbs_mlt_offset_master.BRANCH_CODE
               AND i.ACCOUNT = p_wrk_dedmjonl.v_detbs_mlt_offset_master.ACCOUNT
               AND i.ccy = p_wrk_dedmjonl.v_detbs_mlt_offset_master.ccy_cd
            THEN
            
              IF p_wrk_dedmjonl.v_detbs_mlt_offset_master.REFERENCE_NO = p_wrk_dedmjonl.v_mlt_ofst_mast_extgbl.REFERENCE_NO
              THEN
                 l_internal_remarks := p_wrk_dedmjonl.v_mlt_ofst_mast_extgbl.INTERNAL_REMARKS;
              END IF;                     
    
              IF p_wrk_dedmjonl.v_detbs_mlt_offset_master.REFERENCE_NO = p_wrk_dedmjonl.v_cstb_ui_columns.char_field1
              THEN
                 l_external_remarks := p_wrk_dedmjonl.v_cstb_ui_columns.char_field8;
              END IF;                               
           
	    INSERT INTO actbs_recon_master_extgbl
	       (branch
	       ,account
	       ,reconno
	       ,ccy
	       ,internal_remarks
	       ,external_remarks)
	    VALUES
	       (i.BRANCH
		,i.ACCOUNT
		,i.RECONNO
		,i.ccy
		,l_internal_remarks
		,l_external_remarks);

	    END IF;   
	END LOOP;          
        END IF;
    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 SFR#292 ends
    
    dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Post_Upload_Db ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_upload_db;

  FUNCTION fn_pre_process(p_source           IN VARCHAR2,
                          p_source_operation IN VARCHAR2,
                          p_function_id      IN VARCHAR2,
                          p_action_code      IN VARCHAR2,
                          p_child_function   IN VARCHAR2,
                          p_multi_trip_id    IN VARCHAR2,
                          p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                          p_prev_dedmjonl    IN depks_dedmjonl_main.ty_dedmjonl,
                          p_wrk_dedmjonl     IN OUT depks_dedmjonl_main.ty_dedmjonl,
                          p_err_code         IN OUT VARCHAR2,
                          p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    dbg('In Fn_Pre_Process..');

    dbg('Returning Success From Fn_Pre_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Pre_Process ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_process;

  FUNCTION fn_post_process(p_source           IN VARCHAR2,
                           p_source_operation IN VARCHAR2,
                           p_function_id      IN VARCHAR2,
                           p_action_code      IN VARCHAR2,
                           p_child_function   IN VARCHAR2,
                           p_multi_trip_id    IN VARCHAR2,
                           p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                           p_prev_dedmjonl    IN depks_dedmjonl_main.ty_dedmjonl,
                           p_wrk_dedmjonl     IN OUT depks_dedmjonl_main.ty_dedmjonl,
                           p_err_code         IN OUT VARCHAR2,
                           p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
			l_account_class sttm_cust_account.account_class%type;        -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes    
  BEGIN

    dbg('In Fn_Post_Process..');
    -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Starts
      BEGIN
        DBG('p_dedmjonl.v_detbs_jrnl_txn_detail.cust_ac_no : ' || p_dedmjonl.v_detbs_mlt_offset_master
            .account);
        select account_Class
          into l_account_class
          from sttm_cust_Account a
         where cust_Ac_no = p_dedmjonl.v_detbs_mlt_offset_master
              .account
              and a.branch_code = p_dedmjonl.v_detbs_mlt_offset_master.branch_code
              and record_stat = 'O' and auth_stat = 'A'
              and exists (select 1 from sttb_account b where ac_or_gl = 'A' and b.ac_gl_no = a.cust_ac_no);              
        dbg('Account Class : ' || l_account_Class);
      IF instr(cvpks_utils_extgbl.fn_get_param_value('GWPAGEE_ACCCLASS_LST'),
               l_Account_class) > 0  and p_dedmjonl.v_detbs_mlt_offset_master.dr_cr = 'D' THEN
	insert into DETBS_RESERVE_DTL_EXTGBL
	  (SYSTEM_ID,
	   DATETIMESTAMP,
	   MSG_REG,
	   MSG_TYPE,
	   ACCOUNT,
	   REFERENCE_NO,
	   VALUE_DT,
	   AMOUNT,
	   RESPONSE)
        values
          ('102',
           to_char(sysdate,'YYYYMMDDHHMISS'),
           '0',
           'INT1002',
           p_dedmjonl.v_detbs_mlt_offset_master.account,
           p_dedmjonl.v_detbs_mlt_offset_master.reference_no,
           to_char(global.application_date,'YYYYMMDDHHMISS'),
           p_dedmjonl.v_detbs_mlt_offset_master.amount,
           null);
        dbg('Inserted to DE ECA Table ');
        commit;
      END IF;        
      EXCEPTION
        WHEN Others THEn
          dbg('Account Class Not Found ' || sqlerrm);
      END;
    

    
    -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Ends
    dbg('Returning Success From Fn_Post_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Post_Process ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_process;

  FUNCTION fn_pre_query(p_source           IN VARCHAR2,
                        p_source_operation IN VARCHAR2,
                        p_function_id      IN VARCHAR2,
                        p_action_code      IN VARCHAR2,
                        p_child_function   IN VARCHAR2,
                        p_full_data        IN VARCHAR2 DEFAULT 'Y',
                        p_with_lock        IN VARCHAR2 DEFAULT 'N',
                        p_qrydata_reqd     IN VARCHAR2,
                        p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                        p_wrk_dedmjonl     IN OUT depks_dedmjonl_main.ty_dedmjonl,
                        p_err_code         IN OUT VARCHAR2,
                        p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    dbg('In Fn_Pre_Query..');

    dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Pre_Query ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_pre_query;

  FUNCTION fn_post_query(p_source           IN VARCHAR2,
                         p_source_operation IN VARCHAR2,
                         p_function_id      IN VARCHAR2,
                         p_action_code      IN VARCHAR2,
                         p_child_function   IN VARCHAR2,
                         p_full_data        IN VARCHAR2 DEFAULT 'Y',
                         p_with_lock        IN VARCHAR2 DEFAULT 'N',
                         p_qrydata_reqd     IN VARCHAR2,
                         p_dedmjonl         IN depks_dedmjonl_main.ty_dedmjonl,
                         p_wrk_dedmjonl     IN OUT depks_dedmjonl_main.ty_dedmjonl,
                         p_err_code         IN OUT VARCHAR2,
                         p_err_params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN

    dbg('In Fn_Post_Query');
    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 STARTS
    dbg('Get the Record For :DETBS_MLT_OFST_MAST_EXTGBL');
    BEGIN
      SELECT *
        INTO p_wrk_dedmjonl.v_mlt_ofst_mast_extgbl
        FROM detbs_mlt_ofst_mast_extgbl
       WHERE reference_no = p_wrk_dedmjonl.v_detbs_mlt_offset_master.reference_no;             
    EXCEPTION
      WHEN no_data_found THEN
        --FCUBS12.0.0.1CITI IUT3 SFR# 15 - Unable to query from summary screen
        dbg(SQLERRM);
        dbg('Failed in Selecting The Record For :DETBS_MLT_OFST_MAST_EXTGBL');
    END;
    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 20 ENDS

    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 STARTS
    IF p_action_code = 'EXECUTEQUERY' THEN
      BEGIN
        --FCUBS12.0.0.1CITI IUT3 SFR# 15 - Unable to query from summary screen
        SELECT related_cust_no
          INTO p_wrk_dedmjonl.v_mlt_ofst_mast_extgbl.related_cust_no
          FROM detbs_mlt_ofst_mast_extgbl
         WHERE reference_no = p_wrk_dedmjonl.v_detbs_mlt_offset_master.reference_no;               
        --FCUBS12.0.0.1CITI IUT3 SFR# 15 - Unable to query from summary screen starts
      EXCEPTION
        WHEN no_data_found THEN
          dbg(SQLERRM);
          dbg('Failed in Selecting The Record For :DETBS_MLT_OFST_MAST_EXTGBL');
      END;
      --FCUBS12.0.0.1CITI IUT3 SFR# 15 - Unable to query from summary screen ends
    END IF;
    --FCUBS CITI Release 12.0.0.1.0 FS Vol4 Tag 3 ENDS

    dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      debug.pr_debug('**',
                     'In When Others of depks_dedmjonl_Custom.Fn_Post_Query ..');
      debug.pr_debug('**', SQLERRM);
      p_err_code   := 'ST-OTHR-001';
      p_err_params := NULL;
      RETURN FALSE;
  END fn_post_query;

END depks_dedmjonl_custom;
/
