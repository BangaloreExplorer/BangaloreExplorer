CREATE OR REPLACE PACKAGE BODY depks_dedtlaut_custom AS
  /*-----------------------------------------------------------------------------------------------------
  **
  ** File Name  : depks_dedtlaut_custom.sql
  **
  ** Module     : Data Entry
  ** 
  ** This source is part of the Oracle FLEXCUBE Software System and is copyrighted by Oracle Financial Services Software Limited.
  ** 
  ** 
  ** All rights reserved. No part of this work may be reproduced, stored in a retrieval system,
  ** adopted or transmitted in any form or by any means, electronic, mechanical, photographic,
  ** graphic, optic recording or otherwise, translated in any language or computer language,..
  ** without the prior written permission of Oracle Financial Services Software Limited.
  ** 
  ** Oracle Financial Services Software Limited.
  ** 10-11, SDF I, SEEPZ, Andheri (East),
  ** Mumbai - 400 096.
  ** India
  ** Copyright � 2008 - 2010 Oracle Financial Services Software Limited. All rights reserved.
  -------------------------------------------------------------------------------------------------------
  CHANGE HISTORY
  
     ** Modified By     : Asha G R
     ** Modified Date       : 10-Aug-2013
     ** Modification reason     : Manual Posting for Journal entries
     ** Search String       : FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5
  
     ** Modified By     : Asha G R
     ** Modified Date       : 03-Oct-2013
     ** Modification reason     : Manual Posting for Journal entries
     ** Search String       : FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 SFR 130
     
     ** Modified By     : Asha G R
     ** Modified Date   : 15-Oct-2013
     ** Modification reason  : Override msg appearing evn though its authorised 
     ** Search String   :FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5    ITR sfr#98 and 88  changes

     ** Modified By     : Sivasankar K
     ** Modified Date       : 28-Oct-2013
     ** Modification reason     : OT tickets handling during authorisation
     ** Search String       : FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 ITR2 SFR#29
     
     ** Modfied By           : Santosh Kumar Savanur
     ** Modified On          : 06-FEB-2014
     ** Modified Reason      : Account Hierarchy Changes
     ** Search String        : FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5

     ** Modfied By           : Raghu Viswanath
     ** Modified On          : 25-FEB-2014
     ** Modified Reason      : Exception Handling Changes
     ** Search String        : FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5 UT
     
    Modfied By              : Anjani
    Modified On             : 25 APR 2014
    Modified Reason         : Changes done for changing the referenced package ifpks_otat_gen_extgbl to ifpks_eca_extgbl 
    Search String           : FCUBS12.0.1.7CITIDDA Rel4 ECA Code Review Changes

     ** Modified By          : Siva
     ** Modified On          : 19-MAY-2014
     ** Modified Reason      : Partial Cheque Payment changes
     ** Search String        : FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4
     
     ** Modified By          : Sushma
     ** Modified On          : 05-MAY-2014
     ** Modified Reason      : Partial Cheque Payment changes
     ** Search String        : FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 ITR SFR#31
     
    Modified By         : Nagaraja Pillari
    Modified On         : 11-Aug-2016
    Modified Reason     : Changes done to allow the DE auth trnasactions irrespective of ECA status.
    Search String       : CITI_FC12_R5_SUPP SIT1 SFR#797     
    
  ** Modfied By           : Debasish
  ** Modified On          : 15 FEB 2018
  ** Modified Reason      : Changes done as part of "Affiliates V3" to validate "Reserve for Account before Authorisation" 
  ** Search String        : FCUBS12.0.1.7CITIDDA Affiliates V3 Changes    
  -------------------------------------------------------------------------------------------------------
  */

  PROCEDURE Dbg(p_msg VARCHAR2) IS
    l_Msg VARCHAR2(32767);
  BEGIN
    l_Msg := 'depks_dedtlaut_Custom ==>' || p_Msg;
    Debug.Pr_Debug('DE', l_Msg);
  END Dbg;

  PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,
                         p_Source      VARCHAR2,
                         p_Err_Code    VARCHAR2,
                         p_Err_Params  VARCHAR2) IS
  BEGIN
    Cspks_Req_Utils.Pr_Log_Error(p_Source,
                                 p_Function_Id,
                                 p_Err_Code,
                                 p_Err_Params);
  END Pr_Log_Error;
  PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
  BEGIN
    Dbg('In Pr_Skip_Handler..');
  END Pr_Skip_Handler;
  FUNCTION Fn_Post_Build_Type_Structure(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_Addl_Info        IN Cspks_Req_Global.Ty_Addl_Info,
                                        p_dedtlaut         IN OUT depks_dedtlaut_Main.ty_dedtlaut,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Build_Type_Structure..');
  
    Dbg('Returning Success From Fn_Post_Build_Type_Structure..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Post_Build_Type_Structure ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Build_Type_Structure;

  FUNCTION Fn_Pre_Check_Mandatory(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_Id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_Child_Function   IN VARCHAR2,
                                  p_pk_or_full       IN VARCHAR2 DEFAULT 'FULL',
                                  p_dedtlaut         IN OUT depks_dedtlaut_Main.ty_dedtlaut,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Pre_Check_Mandatory..');
  
    Dbg('Returning  Success From Fn_Pre_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Pre_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_pre_check_mandatory;

  FUNCTION Fn_Post_Check_Mandatory(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_Child_Function   IN VARCHAR2,
                                   p_Pk_Or_Full       IN VARCHAR2 DEFAULT 'FULL',
                                   p_dedtlaut         IN depks_dedtlaut_Main.ty_dedtlaut,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN
  
   IS
  BEGIN
  
    Dbg('In Fn_Post_Check_Mandatory..');
  
    Dbg('Returning Success From Fn_Post_Check_Mandatory..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Post_Check_Mandatory ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Check_Mandatory;

  FUNCTION Fn_Pre_Default_And_Validate(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_Id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_Child_Function   IN VARCHAR2,
                                       p_dedtlaut         IN depks_dedtlaut_Main.Ty_dedtlaut,
                                       p_Prev_dedtlaut    IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                                       p_Wrk_dedtlaut     IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Default_And_Validate..');
    
    -- FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5 Changes Starts
    acpkss_acc_hierarchy_extgbl.g_consider_for_acc_hier := 'Y';
    -- FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5 Changes Ends
      
    Dbg('Returning Success From Fn_Pre_Default_And_Validate..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Pre_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Default_And_Validate;

  FUNCTION Fn_Post_Default_And_Validate(p_Source           IN VARCHAR2,
                                        p_Source_Operation IN VARCHAR2,
                                        p_Function_Id      IN VARCHAR2,
                                        p_Action_Code      IN VARCHAR2,
                                        p_Child_Function   IN VARCHAR2,
                                        p_dedtlaut         IN depks_dedtlaut_Main.Ty_dedtlaut,
                                        p_Prev_dedtlaut    IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                                        p_Wrk_dedtlaut     IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                                        p_Err_Code         IN OUT VARCHAR2,
                                        p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Default_And_Validate..');
  
    Dbg('Returning Success From Fn_Post_Default_And_Validate');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Post_Default_And_Validate ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Default_And_Validate;

  FUNCTION Fn_Pre_Resolve_Ref_Numbers(p_Source           IN VARCHAR2,
                                      p_Source_Operation IN VARCHAR2,
                                      p_Function_Id      IN VARCHAR2,
                                      p_Action_Code      IN VARCHAR2,
                                      p_dedtlaut         IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                                      p_Err_Code         IN OUT VARCHAR2,
                                      p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    Dbg('In Fn_Pre_Resolve_Ref_Numbers..');
  
    Dbg('Returning Success From Fn_Pre_Resolve_Ref_Numbers');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Main.Fn_Pre_Resolve_Ref_Numbers ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Resolve_Ref_Numbers;
  FUNCTION Fn_Post_Resolve_Ref_Numbers(p_Source           IN VARCHAR2,
                                       p_Source_Operation IN VARCHAR2,
                                       p_Function_id      IN VARCHAR2,
                                       p_Action_Code      IN VARCHAR2,
                                       p_dedtlaut         IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                                       p_Err_Code         IN OUT VARCHAR2,
                                       p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  
  BEGIN
  
    Dbg('In Fn_Post_Resolve_Ref_Numbers..');
  
    Dbg('Returning Success From Fn_Post_Resolve_Ref_Numbers..');
    RETURN TRUE;
  
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When others of depks_dedtlaut_Main.Fn_Post_Resolve_Ref_Numbers ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Resolve_Ref_Numbers;
  FUNCTION Fn_Pre_Product_Default(p_Source           IN VARCHAR2,
                                  p_Source_Operation IN VARCHAR2,
                                  p_Function_Id      IN VARCHAR2,
                                  p_Action_Code      IN VARCHAR2,
                                  p_dedtlaut         IN depks_dedtlaut_Main.Ty_dedtlaut,
                                  p_Wrk_dedtlaut     IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                                  p_Err_Code         IN OUT VARCHAR2,
                                  p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Product_Default..');
  
    Dbg('Returning Success From Fn_Pre_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Pre_Product_Default ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Product_Default;

  FUNCTION Fn_Post_Product_Default(p_Source           IN VARCHAR2,
                                   p_Source_Operation IN VARCHAR2,
                                   p_Function_Id      IN VARCHAR2,
                                   p_Action_Code      IN VARCHAR2,
                                   p_dedtlaut         IN depks_dedtlaut_Main.Ty_dedtlaut,
                                   p_Wrk_dedtlaut     IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                                   p_Err_Code         IN OUT VARCHAR2,
                                   p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Product_Default..');
  
    Dbg('Returning Success From Fn_Post_Product_Default..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Post_Product_Default ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Product_Default;

  FUNCTION Fn_Pre_Unlock(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN OUT VARCHAR2,
                         p_dedtlaut         IN depks_dedtlaut_Main.ty_dedtlaut,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Unlock..');
  
    Dbg('Returning Success From Fn_Pre_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Pre_Unlock ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Unlock;

  FUNCTION Fn_Post_Unlock(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN OUT VARCHAR2,
                          p_dedtlaut         IN depks_dedtlaut_Main.Ty_dedtlaut,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Unlock');
  
    Dbg('Returning Success From Fn_Post_Unlock..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Post_Unlock ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Unlock;

  FUNCTION Fn_Pre_Subsys_Pickup(p_Source           IN VARCHAR2,
                                p_Source_Operation IN VARCHAR2,
                                p_Function_Id      IN VARCHAR2,
                                p_Action_code      IN VARCHAR2,
                                p_dedtlaut         IN depks_dedtlaut_Main.Ty_dedtlaut,
                                p_Prev_dedtlaut    IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                                p_Wrk_dedtlaut     IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                                p_Err_Code         IN OUT VARCHAR2,
                                p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Subsys_Pickup..');
  
    Dbg('Returning Success From Fn_Pre_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Pre_Subsys_Pickup ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Subsys_Pickup;

  FUNCTION Fn_Post_Subsys_Pickup(p_Source           IN VARCHAR2,
                                 p_Source_Operation IN VARCHAR2,
                                 p_Function_Id      IN VARCHAR2,
                                 p_Action_code      IN VARCHAR2,
                                 p_dedtlaut         IN depks_dedtlaut_Main.Ty_dedtlaut,
                                 p_Prev_dedtlaut    IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                                 p_Wrk_dedtlaut     IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                                 p_Err_Code         IN OUT VARCHAR2,
                                 p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Subsys_Pickup..');
  
    Dbg('Returning Success From Fn_Post_Subsys_Pickup..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Post_Subsys_Pickup ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Subsys_Pickup;

  FUNCTION Fn_Pre_Enrich(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_id      IN VARCHAR2,
                         p_Action_code      IN VARCHAR2,
                         p_dedtlaut         IN depks_dedtlaut_Main.Ty_dedtlaut,
                         p_Prev_dedtlaut    IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                         p_wrk_dedtlaut     IN OUT depks_dedtlaut_Main.ty_dedtlaut,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Enrich..');
  
    Dbg('Returning Success From Fn_Pre_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Pre_Enrich ..');
      Debug.pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Enrich;

  FUNCTION Fn_Post_Enrich(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN VARCHAR2,
                          p_dedtlaut         IN depks_dedtlaut_Main.Ty_dedtlaut,
                          p_Prev_dedtlaut    IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                          p_Wrk_dedtlaut     IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Enrich..');
  
    Dbg('Returning Success From Fn_Post_Enrich..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Post_Enrich ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Enrich;

  FUNCTION Fn_Pre_Upload_Db(p_Source           IN VARCHAR2,
                            p_Source_Operation IN VARCHAR2,
                            p_Function_Id      IN VARCHAR2,
                            p_Action_Code      IN VARCHAR2,
                            p_Child_Function   IN VARCHAR2,
                            p_Multi_Trip_Id    IN VARCHAR2,
                            p_dedtlaut         IN depks_dedtlaut_Main.Ty_dedtlaut,
                            p_Prev_dedtlaut    IN depks_dedtlaut_Main.Ty_dedtlaut,
                            p_Wrk_dedtlaut     IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                            p_Err_Code         IN OUT VARCHAR2,
                            p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Upload_Db..');
  
    Dbg('Returning Success From Fn_Pre_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Pre_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Upload_Db;

  FUNCTION Fn_Post_Upload_Db(p_Source           IN VARCHAR2,
                             p_Source_Operation IN VARCHAR2,
                             p_Function_Id      IN VARCHAR2,
                             p_Action_Code      IN VARCHAR2,
                             p_Child_Function   IN VARCHAR2,
                             p_Multi_Trip_Id    IN VARCHAR2,
                             p_dedtlaut         IN depks_dedtlaut_Main.Ty_dedtlaut,
                             p_Prev_dedtlaut    IN depks_dedtlaut_Main.Ty_dedtlaut,
                             p_Wrk_dedtlaut     IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                             p_Err_Code         IN OUT VARCHAR2,
                             p_Err_Params       IN OUT VARCHAR2)
    RETURN BOOLEAN IS
    --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes starts for change of status in iftbs_otat_details_extgbl to A on Auth
    l_ot_at_tk_ref     iftbs_otat_details_extgbl.otat_tkt_ref%TYPE;
    l_auth_stat        VARCHAR2(1);
    l_rej_code         NUMBER := 1;
    l_called_from      VARCHAR2(10) := 'AUTHORIZE';
    l_action_code      VARCHAR2(5) :='A';
    l_auth_id          VARCHAR2(10) := global.user_id;
    l_otat_status      iftbs_otat_details_extgbl.status%TYPE;
    l_trn_branch     sttms_branch.branch_code%TYPE;
    l_sttmbrn_gbl      cvpkss_utils_extgbl.typ_sttmbrn_gbl;
    l_eca_flag         sttms_branch_extgbl.eca_flag%TYPE;
    l_count NUMBER;
    --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends  
    l_ot_count     NUMBER;  -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 ITR2 SFR#29 Changes
  
  BEGIN
  
    Dbg('In Fn_Post_Upload_Db..');
    Dbg('Reference no is '||p_dedtlaut.v_detbs_teller_master__auth.reference_no);
        
     -- CITI_FC12_R5_SUPP SIT1 SFR#797 Starts
     -- Commented the below code and moved the same to fn_eca_appr_reject
     /*

    --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5   changes start
    l_trn_branch:= global.current_branch;
    
    dbg('Calling cvpks_utils_extgbl.get_sttm_brn for getting branch level ECA flag value');
    
    cvpks_utils_extgbl.get_sttm_brn
            (
            l_trn_branch,
            l_sttmbrn_gbl
            );
            
    Dbg('ECA Flag value for the branch is: ' || l_sttmbrn_gbl.sttm_brn_extgblrec.eca_flag);
    
    l_eca_flag := NVL(l_sttmbrn_gbl.sttm_brn_extgblRec.eca_flag, 'N');

    IF l_eca_flag IN  ('F','L')
    THEN
      BEGIN

          SELECT  COUNT(1)
          INTO    l_count
          FROM    iftbs_eca_req_dtl_extgbl
          WHERE   fcc_process_ref_no= p_dedtlaut.v_detbs_teller_master__auth.reference_no
          AND     original_number = p_dedtlaut.v_detbs_teller_master__auth.reference_no
          -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 SFR 130 Changes Starts
          --AND     eca_status IN ('P','R')
      --AND     unique_txn_id= ( SELECT MAX(unique_txn_id) 
      --                 FROM   iftbs_eca_req_dtl_extgbl 
      --                 WHERE fcc_process_ref_no= p_dedtlaut.v_detbs_teller_master__auth.reference_no
      --                 AND     original_number = p_dedtlaut.v_detbs_teller_master__auth.reference_no
      --                );
      AND     eca_status IN ('P','R');
      --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 SFR 130 Changes Ends
          

        EXCEPTION
        WHEN NO_DATA_FOUND THEN
          dbg('Record not found in iftb_eca_req_dtl_extgbl'||SQLERRM);
            l_count := 0;
        WHEN OTHERS THEN
          dbg('In WOT of '||SQLERRM);
            l_count := 0;
        END;

    ELSIF l_eca_flag = 'N'
    THEN
    
            BEGIN
                -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 ITR2 SFR#29 Changes Starts
--      SELECT otat_tkt_ref,status
--      INTO l_ot_at_tk_ref,l_otat_status
--      FROM iftbs_otat_details_extgbl
--      WHERE external_ref_no=p_dedtlaut.v_detbs_teller_master__auth.reference_no
--      AND status <> 'D';
        
        l_ot_count := 0;

        SELECT  COUNT(1)
        INTO    l_ot_count
        FROM    iftbs_otat_details_extgbl
        WHERE   external_ref_no = p_dedtlaut.v_detbs_teller_master__auth.reference_no
        AND status      = 'P';
        
        -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 ITR2 SFR#29 Changes Ends
            
            EXCEPTION
            WHEN NO_DATA_FOUND
            THEN
        DEBUG.pr_debug('IF','OT record not found for reference number'||p_dedtlaut.v_detbs_teller_master__auth.reference_no);
        l_ot_at_tk_ref:=NULL;
        l_otat_status:=NULL;
        RETURN TRUE;
        END;

    END IF;
        
    dbg('l_count is '||l_count);

    IF l_eca_flag IN  ('F','L')
    THEN

        IF l_count > 0
        THEN
            p_err_code := 'IF-ECA0005';
            p_err_params := 'ECA request pending approval,Cannot Proceed with Authorisation';
            Ovpkss.Pr_Appendtbl(p_err_code, p_err_params);
        END IF;

        ELSIF l_eca_flag = 'N'
        THEN
            --IF l_otat_status ='P'     -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 ITR2 SFR#29 Changes
            IF  l_ot_count  > 0 -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 ITR2 SFR#29 Changes
            THEN
            
        -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 ITR2 SFR#29 Changes Starts
        FOR eachrec IN (
                SELECT  *
                FROM    iftbs_otat_details_extgbl
                WHERE   external_ref_no = p_dedtlaut.v_detbs_teller_master__auth.reference_no
                AND status      = 'P'
                )
        LOOP
        -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 ITR2 SFR#29 Changes Ends
            --FCUBS12.0.1.7CITIDDA Rel4 ECA Code Review Changes start
            /*IF NOT ifpks_otat_gen_extgbl.fn_ot_appr_reject
                    (
                    --l_ot_at_tk_ref        -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 ITR2 SFR#29 Changes
                    eachrec.otat_tkt_ref    -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 ITR2 SFR#29 Changes
                    ,l_action_code
                    ,l_rej_code
                    ,p_err_params
                    ,l_auth_id
                    ,l_called_from
                    ,p_err_code
                    ,p_err_params
                    )
            THEN
              dbg('Failed while updating the OT tickets '||l_ot_at_tk_ref||'~'||p_dedtlaut.v_detbs_teller_master__auth.reference_no);
              p_err_code := 'IFACPOST064';
              p_err_params := SQLERRM;
              Ovpkss.Pr_Appendtbl(p_err_code, p_err_params);
              RETURN FALSE;
            END IF;*/
/*            IF NOT ifpks_eca_extgbl.fn_ot_appr_reject
                    (
                    --l_ot_at_tk_ref        -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 ITR2 SFR#29 Changes
                    eachrec.otat_tkt_ref    -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 ITR2 SFR#29 Changes
                    ,l_action_code
                    ,l_rej_code
                    ,p_err_params
                    ,l_auth_id
                    ,l_called_from
                    ,p_err_code
                    ,p_err_params
                    )
            THEN
              dbg('Failed while updating the OT tickets '||l_ot_at_tk_ref||'~'||p_dedtlaut.v_detbs_teller_master__auth.reference_no);
              p_err_code := 'IFACPOST064';
              p_err_params := SQLERRM;
              Ovpkss.Pr_Appendtbl(p_err_code, p_err_params);
              RETURN FALSE;
            END IF;
            --FCUBS12.0.1.7CITIDDA Rel4 ECA Code Review Changes end
        END LOOP;   -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 ITR2 SFR#29 Changes
             END IF;

         END IF;
    --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 changes ends
    */
    
     IF NOT ifpks_eca_extgbl.fn_eca_appr_reject
     (
     p_dedtlaut.v_detbs_teller_master__auth.reference_no
     ,l_action_code
     ,global.current_branch
     ,p_err_code
     ,p_err_params
     )
     THEN

        dbg('Failed in ifpks_eca_extgbl.fn_eca_appr_reject with '||p_err_code||'~'||p_err_params);
        dbg('Sqlerrm -->'||sqlerrm);
        RETURN FALSE;


     END IF;    
    -- CITI_FC12_R5_SUPP SIT1 SFR#797 Ends    
    
    --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 Changes Starts
    Dbg('p_action_code: '||p_action_code);
    Dbg('txn_branch: '||Nvl(p_dedtlaut.v_detbs_teller_master__auth.txn_branch, global.current_branch));
    Dbg('txn_account: '||p_dedtlaut.v_detbs_teller_master__auth.txn_account);
    Dbg('instrument_no: '||p_dedtlaut.v_detbs_teller_master__auth.instrument_no);
    
    IF p_dedtlaut.v_detbs_teller_master__auth.instrument_no IS NOT NULL 
    THEN
      SELECT count(*)
        INTO l_count
        FROM catbs_check_util_extgbl a
       WHERE a.branch = Nvl(p_dedtlaut.v_detbs_teller_master__auth.txn_branch, global.current_branch)
         AND a.account = p_dedtlaut.v_detbs_teller_master__auth.txn_account
         AND a.check_no = p_dedtlaut.v_detbs_teller_master__auth.instrument_no
         AND nvl(a.once_auth,'N') = 'N';
      Dbg('l_count: '||l_count);
      
      IF l_count > 0 AND p_action_code = cspks_req_global.p_Auth THEN
        UPDATE catbs_check_util_extgbl
           SET auth_stat = 'A',
               checker_id = global.user_id,
               checker_dt_stamp = Global.application_date,
               once_auth = 'Y'
         WHERE branch = Nvl(p_dedtlaut.v_detbs_teller_master__auth.txn_branch, global.current_branch)
           AND account = p_dedtlaut.v_detbs_teller_master__auth.txn_account
           AND check_no = p_dedtlaut.v_detbs_teller_master__auth.instrument_no;
      END IF;
    END IF;
    --FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 Changes Ends
    
    Dbg('Returning Success From Fn_Post_Upload_Db..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Post_Upload_Db ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Upload_Db;

  FUNCTION Fn_Pre_Process(p_Source           IN VARCHAR2,
                          p_Source_Operation IN VARCHAR2,
                          p_Function_Id      IN VARCHAR2,
                          p_Action_Code      IN VARCHAR2,
                          p_Child_Function   IN VARCHAR2,
                          p_Multi_Trip_Id    IN VARCHAR2,
                          p_dedtlaut         IN depks_dedtlaut_Main.Ty_dedtlaut,
                          p_Prev_dedtlaut    IN depks_dedtlaut_Main.Ty_dedtlaut,
                          p_Wrk_dedtlaut     IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                          p_Err_Code         IN OUT VARCHAR2,
                          p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
	-- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Starts
	function fn_chk_is_resv_avl(cont_ref_no         IN VARCHAR2)
	return CHAR
	IS
		ret CHAR(1):='Y';
	BEGIN
		dbg('Checking Reserve from GWPagee');
		select decode(response,'2','N','U','N','Y') into ret from DETB_RESERVE_DTL_EXTGBL where reference_no = cont_ref_no;
		return ret;
	exception when others 
	then
		return 'Y';
	end fn_chk_is_resv_avl;

	function fn_chk_is_resp_upd(cont_ref_no         IN VARCHAR2)
	return CHAR
	IS
		ret CHAR(1):='Y';
	BEGIN
		dbg('Checking Reserve updated or not from GWPagee');
		dbg('reference_no : '||cont_ref_no);
		select response into ret from DETB_RESERVE_DTL_EXTGBL where reference_no = cont_ref_no;
		dbg('Response : '||ret);
		IF ret is null
		THEN
		return 'N';
		else
		return 'Y';
		end if;
	exception when others 
	then
		return 'Y';
	end fn_chk_is_resp_upd;		
	-- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Ends                          
  BEGIN
  
    Dbg('In Fn_Pre_Process..');
        -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Starts
	IF fn_chk_is_resv_avl(p_dedtlaut.v_detbs_teller_master__auth.reference_no) <> 'Y'
	THEN
				debug.pr_debug('**'
											,'Reserve Not aVailable for the account as per GWPagee. Not allowed to authorize');
				debug.pr_debug('**', SQLERRM);
				p_err_code   := 'ST-PASS-001';
				p_err_params := p_err_params||p_dedtlaut.v_detbs_teller_master__auth.txn_account||'~';
				RETURN FALSE;									
	END IF;
	IF fn_chk_is_resp_upd(p_dedtlaut.v_detbs_teller_master__auth.reference_no) <> 'Y'
	THEN
				debug.pr_debug('**'
											,'Reserve Not Updated yet from GWPagee... Please retry authorising again after some time');
				debug.pr_debug('**', SQLERRM);
				p_err_code   := 'ST-PASS-002';
				p_err_params := p_err_params||p_dedtlaut.v_detbs_teller_master__auth.txn_account||'~';
				RETURN FALSE;									
	END IF;
	-- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Ends     
    Dbg('Returning Success From Fn_Pre_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Pre_Process ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Process;

  FUNCTION Fn_Post_Process(p_Source           IN VARCHAR2,
                           p_Source_Operation IN VARCHAR2,
                           p_Function_id      IN VARCHAR2,
                           p_Action_Code      IN VARCHAR2,
                           p_Child_Function   IN VARCHAR2,
                           p_Multi_Trip_Id    IN VARCHAR2,
                           p_dedtlaut         IN depks_dedtlaut_Main.Ty_dedtlaut,
                           p_Prev_dedtlaut    IN depks_dedtlaut_Main.Ty_dedtlaut,
                           p_Wrk_dedtlaut     IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                           p_Err_Code         IN OUT VARCHAR2,
                           p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Post_Process..');
  
    Dbg('Returning Success From Fn_Post_Process..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Post_Process ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Post_Process;

  FUNCTION Fn_Pre_Query(p_Source           IN VARCHAR2,
                        p_Source_Operation IN VARCHAR2,
                        p_Function_Id      IN VARCHAR2,
                        p_Action_Code      IN VARCHAR2,
                        p_Child_Function   IN VARCHAR2,
                        p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                        p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                        p_QryData_Reqd     IN VARCHAR2,
                        p_dedtlaut         IN depks_dedtlaut_Main.Ty_dedtlaut,
                        p_Wrk_dedtlaut     IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                        p_Err_Code         IN OUT VARCHAR2,
                        p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
  BEGIN
  
    Dbg('In Fn_Pre_Query..');
  
    Dbg('Returning Success From Fn_Pre_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Pre_Query ..');
      Debug.pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END Fn_Pre_Query;

  FUNCTION Fn_Post_Query(p_Source           IN VARCHAR2,
                         p_Source_Operation IN VARCHAR2,
                         p_Function_Id      IN VARCHAR2,
                         p_Action_Code      IN VARCHAR2,
                         p_Child_Function   IN VARCHAR2,
                         p_Full_Data        IN VARCHAR2 DEFAULT 'Y',
                         p_With_Lock        IN VARCHAR2 DEFAULT 'N',
                         p_QryData_Reqd     IN VARCHAR2,
                         p_dedtlaut         IN depks_dedtlaut_Main.Ty_dedtlaut,
                         p_Wrk_dedtlaut     IN OUT depks_dedtlaut_Main.Ty_dedtlaut,
                         p_Err_Code         IN OUT VARCHAR2,
                         p_Err_Params       IN OUT VARCHAR2) RETURN BOOLEAN IS
    -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5  for handling the ovd msgs starts
    
    l_tbl_contract_ovd depks_dedtlaut_Main.ty_tb_cstbs_contract_ovd__auth;
    l_status varchar2(1);
    l_count number :=0; -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5 Changes
    l_account       sttm_cust_account.cust_ac_no%TYPE;
    l_sttmbrn_gbl           cvpkss_utils_extgbl.typ_sttmbrn_gbl;
    l_trn_branch        sttm_branch.branch_code%TYPE;
    l_eca_flag          sttm_branch_extgbl.eca_flag%TYPE;

    --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5  for handling the ovd msgs ends
 BEGIN
  
    dbg('In Fn_Post_Query');

  -- FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5  for handling the ovd msgs starts
    l_trn_branch:= global.current_branch;
    l_count := 0;
        
    dbg('Calling cvpks_utils_extgbl.get_sttm_brn for getting branch level ECA flag value');
        
        cvpks_utils_extgbl.get_sttm_brn
        (
        l_trn_branch,
        l_sttmbrn_gbl
        );
        
    Dbg('ECA Flag value for the branch is: ' || l_sttmbrn_gbl.sttm_brn_extgblrec.eca_flag);
    l_eca_flag := NVL(l_sttmbrn_gbl.sttm_brn_extgblRec.eca_flag, 'N');
            
        
            FOR i IN 1 .. p_Wrk_dedtlaut.v_cstbs_contract_ovd__auth.COUNT
            LOOP
            BEGIN
                l_account := Cspkes_Misc.Fn_Getparam(p_Wrk_dedtlaut.v_cstbs_contract_ovd__auth(i).parameters,1, '~');
            EXCEPTION
            WHEN OTHERS
            THEN
                dbg('Override message :' || p_Wrk_dedtlaut.v_cstbs_contract_ovd__auth(i).parameters);
                dbg('In WOT while slecting account '||SQLERRM);
                l_account := NULL;
            END;            
            
            dbg('acc is '||l_account);
                
            l_status := NULL;
            
            IF l_eca_flag IN  ('F','L') AND l_account is not null
            THEN
                BEGIN         
                
                    SELECT eca_status 
                    INTO    l_status
                    FROM    iftb_eca_req_dtl_extgbl
                    WHERE   fcc_process_ref_no= p_Wrk_dedtlaut.v_detbs_teller_master__auth.reference_no
                    AND     cust_ac_no           = l_account
                    AND     original_number = p_Wrk_dedtlaut.v_detbs_teller_master__auth.reference_no
                    AND     ac_branch = l_trn_branch;
                
                EXCEPTION
                WHEN TOO_MANY_ROWS
                THEN
                    dbg('Single record fetch returned multiple rows');
                    BEGIN
                        SELECT DISTINCT eca_status 
                        INTO    l_status
                        FROM    iftb_eca_req_dtl_extgbl
                        WHERE   fcc_process_ref_no=p_Wrk_dedtlaut.v_detbs_teller_master__auth.reference_no
                        AND     cust_ac_no = l_account
                        AND     original_number = p_Wrk_dedtlaut.v_detbs_teller_master__auth.reference_no
                        AND     ac_branch = l_trn_branch                        
                        AND     eca_status = 'P';
                    EXCEPTION
                    WHEN OTHERS
                    THEN
                        dbg('In WOT of '||SQLERRM);
                        l_status := NULL;
                    END;
                    
                    l_status:= NULL;
                --FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5 UT Changes Starts
                WHEN NO_DATA_FOUND 
                THEN
                    l_status := NULL;
                --FCUBS12.0.1.7CITIDDA Rel4 Vol1 Tag5 UT Changes Ends
                    
                end;
                
            ELSIF l_eca_flag = 'N' AND l_account is not null
            THEN
                BEGIN         
                
                    SELECT status 
                    INTO    l_status
                    FROM    iftbs_otat_details_extgbl
                    WHERE   external_ref_no= p_Wrk_dedtlaut.v_detbs_teller_master__auth.reference_no
                    AND     customer_acc_no = l_account;
                
                EXCEPTION
                WHEN TOO_MANY_ROWS
                THEN
                    dbg('Single record fetch returned multiple rows');
                    BEGIN
                        SELECT DISTINCT status 
                        INTO    l_status
                        FROM    iftbs_otat_details_extgbl
                        WHERE   external_ref_no=p_Wrk_dedtlaut.v_detbs_teller_master__auth.reference_no
                        AND     customer_acc_no=l_account
                        AND     status = 'P';
                    EXCEPTION
                    WHEN OTHERS 
                    THEN
                        dbg('In WOT of '||SQLERRM);
                        l_status := NULL;
                    END;
         -- FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 ITR SFR#31 changes starts        
          WHEN NO_DATA_FOUND 
          THEN
              l_status := NULL;
          -- FCUBS12.0.1.7CITIDDA Rel4 Vol3 Tag4 ITR SFR#31 changes ends
          --l_status:= NULL;
          END;
                    
            END IF; 
                dbg('l_status is '||l_status);  
                dbg('p_Wrk_dedjrnau.v_csvw_contract_ovd__auth(i).ERR_CODE is '||p_Wrk_dedtlaut.v_cstbs_contract_ovd__auth(i).ERR_CODE); 
                
                IF l_eca_flag IN  ('F','L')
                THEN

                    IF (
                            p_Wrk_dedtlaut.v_cstbs_contract_ovd__auth(i).ERR_CODE <> 'IF-ECARQ-01'
                            OR
                            (p_Wrk_dedtlaut.v_cstbs_contract_ovd__auth(i).ERR_CODE = 'IF-ECARQ-01' AND l_status = 'P')
                        )
                    THEN
                        dbg('chk point for ovd in ECA');
                            l_count := l_count + 1;
                        l_tbl_contract_ovd(l_count) := p_Wrk_dedtlaut.v_cstbs_contract_ovd__auth(i);
                    END IF; 
                ELSIF l_eca_flag = 'N'
                THEN    
                    
                    IF (
                            p_Wrk_dedtlaut.v_cstbs_contract_ovd__auth(i).ERR_CODE <> 'IF-OTACK-01'
                            OR
                            (p_Wrk_dedtlaut.v_cstbs_contract_ovd__auth(i).ERR_CODE = 'IF-OTACK-01' AND l_status = 'P')
                        )
                    THEN
                        dbg('chk point for ovd in OT');
                            l_count := l_count + 1;
                        l_tbl_contract_ovd(l_count) := p_Wrk_dedtlaut.v_cstbs_contract_ovd__auth(i);
                    END IF;                 
                
                END IF; 
                    
            dbg('Count here :' || l_tbl_contract_ovd.COUNT);
            END LOOP;

            --IF l_tbl_contract_ovd.COUNT >0 --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5      ITR sfr#98 and 88 changes commented
            --THEN   --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5      ITR sfr#98 and 88 changes commented
                p_Wrk_dedtlaut.v_cstbs_contract_ovd__auth.DELETE;
                p_Wrk_dedtlaut.v_cstbs_contract_ovd__auth := l_tbl_contract_ovd;
            --END IF;  --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5    ITR sfr#98 and 88 changes commented
            
        --FCUBS12.0.1.7CITIDDA REL2 Vol3 Tag5  for handling the ovd msgs starts Ends            
  
    Dbg('Returning Success From Fn_Post_Query..');
    RETURN TRUE;
  EXCEPTION
    WHEN OTHERS THEN
      Debug.Pr_Debug('**',
                     'In When Others of depks_dedtlaut_Custom.Fn_Post_Query ..');
      Debug.Pr_Debug('**', SQLERRM);
      p_Err_Code   := 'ST-OTHR-001';
      p_Err_Params := NULL;
      RETURN FALSE;
  END fn_post_query;

END depks_dedtlaut_custom;
/
