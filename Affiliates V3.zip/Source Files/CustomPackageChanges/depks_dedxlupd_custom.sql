CREATE OR REPLACE PACKAGE BODY depks_dedxlupd_custom AS
     /*-----------------------------------------------------------------------------------------------------
     **
     ** File Name  : depks_dedxlupd_custom.sql
     **
     ** Module     : Data Entry
     **
     ** This source is part of the Oracle FLEXCUBE Software Product.
     ** Copyright ???? 2008,2014 , Oracle and/or its affiliates.  All rights reserved
     **
     **
     ** No part of this work may be reproduced, stored in a retrieval system, adopted
     ** or transmitted in any form or by any means, electronic, mechanical,
     ** photographic, graphic, optic recording or otherwise, translated in any
     ** language or computer language, without the prior written permission of
     ** Oracle and/or its affiliates.
     **
     ** Oracle Financial Services Software Limited.
     ** Oracle Park, Off Western Express Highway,
     ** Goregaon (East),
     ** Mumbai - 400 063, India
     ** India
     -------------------------------------------------------------------------------------------------------
     CHANGE HISTORY

	** Modified By        : RAJESH/ANKUSH
	** Modified On        : 13-MAR-2014
	** Modified Reason    : USER_ID Validation/Value Date Defaulting.
	** Search String      : FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3

	** Modified By        : ANKUSH SAINI
	** Modified On        : 17-MAR-2014
	** Modified Reason    : USER_ID Validation Not Happening For Null Cases..
	** Search String      : FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 IUT1 SFR#21

	** Modfied By           : Debasish
	** Modified On          : 15 FEB 2018
	** Modified Reason      : Changes done as part of "Affiliates V3" to validate "Reserve for Account before Authorisation" 
	** Search String        : FCUBS12.0.1.7CITIDDA Affiliates V3 Changes
      
     -------------------------------------------------------------------------------------------------------
     */


   PROCEDURE Dbg(p_msg VARCHAR2)  IS
      l_Msg     VARCHAR2(32767);
   BEGIN
      l_Msg := 'depks_dedxlupd_Custom ==>'||p_Msg;
      Debug.Pr_Debug('DE' ,l_Msg);
   END Dbg;

   PROCEDURE Pr_Log_Error(p_Function_Id in VARCHAR2,p_Source VARCHAR2,p_Err_Code VARCHAR2, p_Err_Params VARCHAR2) IS
   BEGIN
      Cspks_Req_Utils.Pr_Log_Error(p_Source,p_Function_Id,p_Err_Code,p_Err_Params);
   END Pr_Log_Error;
   PROCEDURE Pr_Skip_Handler(p_Stage in VARCHAR2) IS
   BEGIN
      Dbg('In Pr_Skip_Handler..');
   END Pr_Skip_Handler;
   FUNCTION fn_Post_build_type_structure (p_Source    IN     VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_Addl_Info       IN Cspks_Req_Global.Ty_Addl_Info,
      p_dedxlupd     IN  OUT depks_dedxlupd_Main.ty_dedxlupd,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Post_Build_type_structure..');

      Dbg('Returning Success From Fn_Post_Build_Type_Structure');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others Of depks_dedxlupd_Custom.Fn_Post_Build_type_structure ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Post_Build_Type_Structure;

   FUNCTION Fn_Pre_Check_Mandatory(p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_dedxlupd IN OUT  depks_dedxlupd_Main.Ty_dedxlupd,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN

      IS
       --FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 Starts
       l_user_id detb_upload_excel_extgbl.user_id%type;
       l_maker_id detb_upload_master.maker_id%type;
       l_count number:=0;
       --FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 ENDS
       l_account_class sttm_cust_account.account_class%type;    -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes
   BEGIN

      Dbg('In Fn_Pre_Check_Mandatory');
      --FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 Starts
      dbg(p_dedxlupd.v_detb_upload_excel_extgbl.Branch_Code||'~'||p_dedxlupd.v_detb_upload_excel_extgbl.Source_Code||'~'|| p_dedxlupd.v_detb_upload_excel_extgbl.Batch_No);
      dbg('p_Action_Code : '||p_Action_Code);
      --VAlidating USER FOR Deletion and NEW
      If p_Action_Code in ('NEW','DELETE')
      THEN
        BEGIN
          dbg('Selecting USERID..');
          SELECT User_Id INTO   l_user_id
          FROM   detb_upload_excel_extgbl
          WHERE  Branch_Code = p_dedxlupd.v_detb_upload_excel_extgbl.Branch_Code
          AND    Source_Code = p_dedxlupd.v_detb_upload_excel_extgbl.Source_Code
          AND    Batch_No = p_dedxlupd.v_detb_upload_excel_extgbl.Batch_No;
          dbg('l_user_id : '||l_user_id);
          dbg('Selecting MAKERID..');
          Begin
            SELECT MAKER_ID INTO   l_maker_id
            FROM   Detbs_Upload_Master
            WHERE  Branch_Code = p_dedxlupd.v_detb_upload_excel_extgbl.Branch_Code
            AND    Source_Code = p_dedxlupd.v_detb_upload_excel_extgbl.Source_Code
            AND    Batch_No = p_dedxlupd.v_detb_upload_excel_extgbl.Batch_No;
          EXCEPTION
            When NO_DATA_FOUND then
               dbg('No Records Maintained at Detbs_Upload_Master....');
          END;
          dbg('l_maker_id : '||l_maker_id);
          dbg('Starting Validation');
          --FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 IUT1 SFR#21 Starts
          --If global.user_id not IN (l_user_id,l_maker_id) Then
          If global.user_id NOT IN (l_user_id,nvl(l_maker_id,'$')) Then
             dbg('Operation Not Allowed for Current User');
          --FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 IUT1 SFR#21 Ends
             p_Err_Code   := 'DE-UPLD-004';
             pr_log_error(p_function_id, 'FLEXCUBE', p_err_code, p_err_params);
             RETURN FALSE;
          End IF;
        EXCEPTION
          When NO_DATA_FOUND then
               dbg('No Records Present at Detbs_Upload_Excel_Extgbl....');
        END;
      END IF;

      IF p_Action_Code = 'NEW'
      THEN
        Dbg('In Fn_Pre_Check_Mandatory Action Code : ' || p_Action_Code);
        --Validating Batch Authorization
        select count(1) into l_count
        from actb_daily_log
        where batch_no=p_dedxlupd.v_detb_upload_excel_extgbl.Batch_No
        and Auth_Stat='A';

        If l_count>0 Then
          p_Err_Code  := 'DE-UPL25';
          p_Err_Params := Null;
          pr_log_error(p_function_id, 'FLEXCUBE', p_err_code, p_err_params);
          Return False;
        End IF;

        dbg('Deleting from Detbs_Upload_Excel_Extgbl');
        DELETE FROM detb_upload_excel_extgbl
        WHERE  Branch_Code = p_dedxlupd.v_detb_upload_excel_extgbl.Branch_Code
        AND    Source_Code = p_dedxlupd.v_detb_upload_excel_extgbl.Source_Code
        AND    Batch_No = p_dedxlupd.v_detb_upload_excel_extgbl.Batch_No;

        Dbg('Record Deletd From Detbs_Upload_Excel_Extgbl : '|| SQL%rowcount);
      END IF;
      --FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 Ends
               -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Starts
                for indx in 1 .. p_dedxlupd.v_detb_upload_detail.COUNT loop
                  BEGIN
              DBG('p_dedxlupd.v_detb_upload_detail(indx).account : ' || p_dedxlupd.v_detb_upload_detail(indx)
                  .account);
              select account_Class
                into l_account_class
                from sttm_cust_Account a
               where cust_Ac_no = p_dedxlupd.v_detb_upload_detail(indx).account
                    and a.branch_code = p_dedxlupd.v_detb_upload_detail(indx).account_branch
                    and record_stat = 'O' and auth_stat = 'A'
                    and exists (select 1 from sttb_account b where ac_or_gl = 'A' and b.ac_gl_no = a.cust_ac_no);

              dbg('Account Class : ' || l_account_Class);

              IF instr(cvpks_utils_extgbl.fn_get_param_value('GWPAGEE_ACCCLASS_LST'),
                     l_Account_class) > 0  and p_dedxlupd.v_detb_upload_detail(indx).dr_cr = 'D'

                     THEN
			BEGIN
			      insert into DETBS_RESERVE_DTL_EXTGBL
				(SYSTEM_ID,
				 DATETIMESTAMP,
				 MSG_REG,
				 MSG_TYPE,
				 ACCOUNT,
				 REFERENCE_NO,
				 VALUE_DT,
				 AMOUNT,
				 RESPONSE)
			      values
				('102',
				 to_char(sysdate,'YYYYMMDDHHMISS'),
				 '0',
				 'INT1002',
				 p_dedxlupd.v_detb_upload_detail(indx).account,
				 p_dedxlupd.v_detb_upload_detail(indx).branch_code||p_dedxlupd.v_detb_upload_detail(indx).source_code||p_dedxlupd.v_detb_upload_detail(indx).batch_no||p_dedxlupd.v_detb_upload_detail(indx).curr_no,
				 to_char(global.application_date,'YYYYMMDDHHMISS'),
				 p_dedxlupd.v_detb_upload_detail(indx).amount,
				 null);
			      dbg('Inserted to DE ECA Table ');

		exception
			when dup_val_on_index then
				dbg('Record Already inserted... Ignoring...');
			when others then
				dbg('Failed in Insert or update...'||sqlerrm);
		end;
	END IF;
              commit;

                  EXCEPTION
              WHEN Others THEn
                dbg('Account Class Not Found ' || sqlerrm);
                  END;


                END LOOP;

                -- FCUBS12.0.1.7CITIDDA Affiliates V3 Changes Ends

     Dbg('Returning Success From Fn_Pre_Check_Mandatory..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedxlupd_Custom.Fn_Pre_Check_Mandatory ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END fn_pre_check_mandatory;

   FUNCTION Fn_Post_Check_Mandatory(p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_Pk_Or_Full     IN  VARCHAR2 DEFAULT 'FULL',
      p_dedxlupd IN   depks_dedxlupd_Main.ty_dedxlupd,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN

      IS
   BEGIN

      Dbg('In Fn_Post_Check_Mandatory..');

      Dbg('Returning Success From Fn_Post_Check_Mandatory..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedxlupd_Custom.Fn_Post_Check_Mandatory ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Post_Check_Mandatory;

   FUNCTION Fn_Pre_Default_And_Validate (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_dedxlupd IN   depks_dedxlupd_Main.ty_dedxlupd,
      p_Prev_dedxlupd IN OUT depks_dedxlupd_Main.ty_dedxlupd,
      p_Wrk_dedxlupd IN OUT  depks_dedxlupd_Main.ty_dedxlupd,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Pre_Default_And_Validate..');

      Dbg('Returning Success From fn_pre_default_and_validate..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedxlupd_Custom.Fn_Pre_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Pre_Default_And_Validate;

   FUNCTION Fn_Post_Default_And_Validate (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_dedxlupd IN   depks_dedxlupd_Main.Ty_dedxlupd,
      p_Prev_dedxlupd IN OUT depks_dedxlupd_Main.Ty_dedxlupd,
      p_Wrk_dedxlupd IN OUT  depks_dedxlupd_Main.Ty_dedxlupd,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Post_Default_And_Validate..');

      Dbg('Returning Success From Fn_Post_Default_And_Validate..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedxlupd_Custom.Fn_Post_Default_And_Validate ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Post_Default_And_Validate;

   FUNCTION Fn_Pre_Upload_Db (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_Post_Upl_Stat    IN  VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_dedxlupd IN depks_dedxlupd_Main.Ty_dedxlupd,
      p_Prev_dedxlupd IN depks_dedxlupd_Main.Ty_dedxlupd,
      p_Wrk_dedxlupd IN OUT  depks_dedxlupd_Main.Ty_dedxlupd,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Pre_Upload_Db..');

      --FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 Starts
      if p_Action_Code='NEW' Then
       dbg('Count : '||p_dedxlupd.v_detb_upload_detail.COUNT||'~'||p_Prev_dedxlupd.v_detb_upload_detail.COUNT||'~'||p_Wrk_dedxlupd.v_detb_upload_detail.COUNT);
       If p_Wrk_dedxlupd.v_detb_upload_detail.COUNT>0 then
          For i in p_Wrk_dedxlupd.v_detb_upload_detail.First..p_Wrk_dedxlupd.v_detb_upload_detail.LAST
          LOOP
            p_Wrk_dedxlupd.v_detb_upload_detail(i).upload_stat:=Null;
            If p_Wrk_dedxlupd.v_detb_upload_detail(i).value_date is null
            Then
               p_Wrk_dedxlupd.v_detb_upload_detail(i).value_date:=global.application_date;
            End If;
          END LOOP;
       End If;
      Elsif p_Action_code= 'DELETE' Then
          dbg('Setting G_Skip_Sys to True');
          depks_dedxlupd_main.Pr_Set_Skip_Sys;
      End If;
      --FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 Ends
      Dbg('Returning Success From Fn_Pre_Upload_Db..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedxlupd_Custom.Fn_Pre_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Pre_Upload_Db;

   FUNCTION Fn_Post_Upload_Db (p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_Post_Upl_Stat    IN  VARCHAR2,
      p_Multi_Trip_Id    IN  VARCHAR2,
      p_dedxlupd IN depks_dedxlupd_Main.Ty_dedxlupd,
      p_prev_dedxlupd IN depks_dedxlupd_Main.Ty_dedxlupd,
      p_wrk_dedxlupd IN OUT  depks_dedxlupd_Main.Ty_dedxlupd,
      p_Err_Code       IN  OUT VARCHAR2,
      p_Err_Params     IN  OUT VARCHAR2)
   RETURN BOOLEAN
      IS
      --FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 Starts
      l_count number;
      --FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 Ends
   BEGIN

      Dbg('In Fn_Post_Upload_Db..');
      --FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 Starts
      If p_Action_Code='NEW' Then
         dbg('Updating USERID for New...');
         Update detb_upload_excel_extgbl
          set user_id=Global.user_id
         where Branch_Code = p_dedxlupd.v_detb_upload_excel_extgbl.Branch_Code
          AND    Source_Code = p_dedxlupd.v_detb_upload_excel_extgbl.Source_Code
          AND    Batch_No = p_dedxlupd.v_detb_upload_excel_extgbl.Batch_No;
         dbg('Record Updated : '||SQL%ROWCOUNT);
      Elsif p_Action_Code='DELETE' Then
         dbg('Call For DELETE in MAIN Skiped.. Deleting Only Unprocessed Record From Detail Table..');
         select count(1) into l_count
         From detb_upload_detail
         Where Branch_Code = p_dedxlupd.v_detb_upload_excel_extgbl.Branch_Code
          AND    Source_Code = p_dedxlupd.v_detb_upload_excel_extgbl.Source_Code
          AND    Batch_No = p_dedxlupd.v_detb_upload_excel_extgbl.Batch_No;

         Delete From detb_upload_detail
         Where Branch_Code = p_dedxlupd.v_detb_upload_excel_extgbl.Branch_Code
          AND    Source_Code = p_dedxlupd.v_detb_upload_excel_extgbl.Source_Code
          AND    Batch_No = p_dedxlupd.v_detb_upload_excel_extgbl.Batch_No
          AND (UPLOAD_STAT is NULL OR UPLOAD_STAT = 'E');
         dbg('No Of Records Deleted : '||SQL%ROWCOUNT);
         If l_count=SQL%ROWCOUNT Then
            dbg('Delete From Excel Master As Wel..');
            Delete from detb_upload_excel_extgbl
            Where Branch_Code = p_dedxlupd.v_detb_upload_excel_extgbl.Branch_Code
            AND    Source_Code = p_dedxlupd.v_detb_upload_excel_extgbl.Source_Code
            AND    Batch_No = p_dedxlupd.v_detb_upload_excel_extgbl.Batch_No;
            dbg('Master record Deleted : '||SQL%Rowcount);
         End If;
      End IF;
      --FS_FCUBS_12.0.1.7.0$CITIBK_R4_Vol1-DDA-Tag3 Ends
      Dbg('Returning Success From Fn_Post_Upload_Db..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedxlupd_Custom.Fn_Post_Upload_Db ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Post_Upload_Db;

   FUNCTION Fn_Pre_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd IN  VARCHAR2 ,
      p_dedxlupd IN   depks_dedxlupd_Main.Ty_dedxlupd,
      p_Wrk_dedxlupd IN OUT   depks_dedxlupd_Main.Ty_dedxlupd,
      p_Err_Code          IN OUT VARCHAR2,
      p_Err_Params        IN OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Pre_Query..');

      Dbg('Returning Success From Fn_Pre_Query..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When Others of depks_dedxlupd_Custom.Fn_Pre_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Pre_Query;

   FUNCTION Fn_Post_Query  ( p_Source    IN  VARCHAR2,
                              p_Source_Operation  IN     VARCHAR2,
                              p_Function_Id       IN     VARCHAR2,
                              p_Action_Code       IN     VARCHAR2,
      p_Child_Function    IN  VARCHAR2,
      p_Full_Data     IN  VARCHAR2 DEFAULT 'Y',
      p_With_Lock     IN  VARCHAR2 DEFAULT 'N',
      p_QryData_Reqd IN  VARCHAR2 ,
      p_dedxlupd IN   depks_dedxlupd_Main.ty_dedxlupd,
      p_wrk_dedxlupd IN OUT   depks_dedxlupd_Main.ty_dedxlupd,
      p_Err_Code          IN OUT VARCHAR2,
      p_err_params        IN OUT VARCHAR2)
   RETURN BOOLEAN
      IS
   BEGIN

      Dbg('In Fn_Post_Query..');

      Dbg('Returning Success From Fn_Post_Query..');
      RETURN TRUE;
   EXCEPTION
      WHEN OTHERS THEN
         Debug.Pr_Debug('**','In When others of depks_dedxlupd_Custom.Fn_Post_Query ..');
         Debug.Pr_Debug('**',SQLERRM);
         p_Err_Code    := 'ST-OTHR-001';
         p_Err_Params  := NULL;
         RETURN FALSE;
   END Fn_Post_Query;


END depks_dedxlupd_custom;
/